# Stakeholder Shuttle Diplomacy

It doesn't matter if it's a feature, roadmap, or vibe code. Shuttle diplomacy is how PMs survive the chaos of influence without authority.

[![Passport stamps include: "Survived Legal Review," "Escaped Marketing Rebrand," and "MVP Denied Entry."](https://substackcdn.com/image/fetch/$s_!3SyT!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7cff3c7b-2a5c-4491-94f4-ec02d0233988_3072x2048.png "Passport stamps include: \"Survived Legal Review,\" \"Escaped Marketing Rebrand,\" and \"MVP Denied Entry.\"")](https://substackcdn.com/image/fetch/$s_!3SyT!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7cff3c7b-2a5c-4491-94f4-ec02d0233988_3072x2048.png)

Welcome to the world where "alignment" requires a passport.

No, you're not mediating peace in the Middle East. You're just trying to ship an AI integration that enhances an existing forecasting feature.

It starts innocently enough.

> • Sales wants it by Friday.
>
> • Engineering says it'll take three sprints.
>
> • Marketing wants to rebrand it.
>
> • Legal demands compliance documentation.
>
> • The CEO casually mentioned it to a customer.

**Suddenly, you're not a product manager.**

You're a diplomatic envoy shuttling between warring nation-states—feuding factions that won't speak directly because apparently we're all still in middle school.

> • Each stakeholder thinks they're the reasonable one.
>
> • Each believes the others "*just don't get it.*"
>
> • And you? You're the poor soul with the frequent flyer miles, carrying messages between camps that refuse to sit in the same room.

Welcome to **Stakeholder Shuttle Diplomacy** … where influence without authority means you're Henry Kissinger with a Kanban board, trying to broker peace treaties over features that [offer little](https://world.hey.com/itzy/85-of-new-features-fail-feature-cost-inflation-287ca167) … [if any](https://www.abtasty.com/blog/1000-experiments-club-ronny-kohavi/) lift.

[![The five stages of stakeholder grief (yours, not theirs)](https://substackcdn.com/image/fetch/$s_!lErh!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F25f415e7-321a-4764-aa85-9af888a91a0f_1536x1024.png "The five stages of stakeholder grief (yours, not theirs)")](https://substackcdn.com/image/fetch/$s_!lErh!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F25f415e7-321a-4764-aa85-9af888a91a0f_1536x1024.png)

The five stages of stakeholder grief (yours, not theirs)

---

The Five Stages of Shuttle Diplomacy
------------------------------------

**Stage 1: The Optimistic Opening**  
*"Let's just get everyone aligned."*

You schedule the meeting. You craft the agenda. You believe in the power of collaborative decision-making. You still think adults can sit in a room and discuss trade-offs like civilized humans.

Oh, you sweet summer child.

**Stage 2: The Fractured Summit**  
*"We need to take this offline."*

The meeting explodes faster than a North Korean peace talk. Sales storms out when Engineering mentions "*technical debt*" for the thirtieth time. Legal starts citing [Orange Book Regulations](https://public.milcyber.org/activities/magazine/articles/2021/renda-the-orange-book) from the Reagan era. Marketing suggests a "*quick rebrand*" that would require rebuilding everything from scratch.

You're left holding seventeen different interpretations of the same requirement.

**Stage 3: The Shuttling Begins**  
*"Let me talk to each team separately."*

Now you're ping-ponging between Slack channels, conference rooms, and coffee corners. Each conversation starts with: *"Don't tell the others, but..."*

You become a walking repository of classified opinions, conflicting priorities, and passive-aggressive subtext. Congratulations—you're now a human gossip protocol.

**Stage 4: The Translation Layer**  
*"What Engineering means is..."*

You're no longer product managing. You're simultaneously:

> • A therapist ("Sales feels unheard")
>
> • A diplomat ("Legal is concerned about precedent")
>
> • A translator ("When Dev says 'impossible,' they mean 'expensive'")
>
> • A [feature hostage negotiator](https://deanpeters.substack.com/p/feature-hostage-negotiations-one-small-fix?utm_source=share&utm_medium=android&r=3jxqq&triedRedirect=true) ("What would it take to get this done?")

**Stage 5: The Pyrrhic Victory**  
*"We have consensus!"*

After eighteen meetings, forty-three Slack threads, and two minor nervous breakdowns, everyone agrees. The feature ships. It works. Users ignore it completely. The customer is grumpy.

Welcome to the 80%. You've successfully mediated a peace treaty over a feature that, [according to Pendo](https://go.pendo.io/rs/185-LQW-370/images/2019%20Feature%20Adoption%20Report%20Digital.pdf), [Ron Kohavi](https://hbr.org/2017/09/the-surprising-power-of-online-experiments), and the cruel gods of product management, is rarely or never used.

[![The math is simple: 20% love it, 60% ignore it, 20% curse your name. Product management in a nutshell.](https://substackcdn.com/image/fetch/$s_!TSPP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F318724e9-095e-4265-88f0-2e90fba12b20_3072x2048.png "The math is simple: 20% love it, 60% ignore it, 20% curse your name. Product management in a nutshell.")](https://substackcdn.com/image/fetch/$s_!TSPP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F318724e9-095e-4265-88f0-2e90fba12b20_3072x2048.png)

Congratulations—you built something 60% of users actively avoid.

---

The Shuttle Diplomat's Survival Kit
-----------------------------------

#### **Map the Real Decision Makers**

The org chart lies like a campaign promise. Find who actually controls vetoes, budgets, and the CEO's ear. Don't waste time pitching ambassadors when you need the king. A smart guy named [Mendelow](https://blog.oxfordcollegeofmarketing.com/2018/04/23/what-is-mendelows-matrix-and-how-is-it-useful/) drew us a map for that.

#### **Identify the Hidden Incentives**

Sales gets commission on deals, not user adoption. Engineering gets judged on velocity, not value. Legal gets praised for preventing lawsuits, not enabling features. Know what game everyone's playing—because they sure as hell aren't playing yours.

"Ask Yourself: What gets them hired, fired, and promoted?" ~ Dean Peters

#### **Create Shared Consequences**

Instead of separate conversations, create shared [success (or failure) metrics](https://productside.com/data-driven-product-management/). When everyone owns the same outcome, suddenly they're willing to compromise on their pet requirements. Funny how that works.

#### **Document Everything in Public**

Stop being the human message relay. Use shared docs, public channels, and [decision logs](https://www.launchnotes.com/glossary/decision-log-in-product-management-and-operations). Force stakeholders to argue with each other's actual words, not your interpretation of them. Let them fight their own battles.

#### **Time-Box the Diplomacy**

Give shuttle diplomacy a deadline. After two weeks of negotiations, the status quo wins by default. By [introducing some constraints](https://deanpeters.substack.com/p/timeboxes-are-not-evil), you'll discover how quickly people find time to collaborate when delay means defeat.

#### **Build Escape Hatches**

Always have a smaller version ready. When the peace talks collapse, you can still ship something. **Perfection is the enemy of shipped**—and shipped is the enemy of unemployment.

[![Infographic: The PM Stakeholder Shuttle Diplomacy Toolkit](https://substackcdn.com/image/fetch/$s_!sAfI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff284d709-584d-4af6-911d-8105d6131218_3072x2048.png "Infographic: The PM Stakeholder Shuttle Diplomacy Toolkit")](https://substackcdn.com/image/fetch/$s_!sAfI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff284d709-584d-4af6-911d-8105d6131218_3072x2048.png)

Infographic: The PM Stakeholder Shuttle Diplomacy Toolkit

---

### The Nuclear Option: Forced Coexistence

You'll need some executive air cover for this next maneuver, because sometimes, you have to lock them in a room like unruly children.

```
Subject: Final Decision Meeting - Feature X
Time: 2 hours (no phones, no laptops, no bathroom breaks)
Attendees: [All warring factions]

Agenda:

1. State your requirements (5 min each)
2. State your constraints (5 min each)
3. Find the overlap or kill the feature
4. No one leaves until we decide

Note: Coffee and donuts provided.
Aspirin available upon request.
```

You'd be shocked how fast people cooperate when they're physically trapped with each other. It's like conflict resolution meets escape room.

The Dirty Secret
----------------

Here's what nobody tells you about stakeholder shuttle diplomacy:

**Half the time, they don't actually disagree.**

They just think they do because they're using different words for the same thing, or solving for different timeframes, or arguing about edge cases that affect 0.001% of users. Don't believe me? There's [research](https://www.jstor.org/stable/2635156) on this beautiful dysfunction.

Your job isn't to negotiate a peace treaty.  
**Your job is to translate between people who are violently agreeing with each other.**

1. **Sales** wants "*fast customer onboarding.*"
2. **Engineering** wants "*scalable user creation.*"
3. **Marketing** wants "*streamlined signup experience.*"

1. 2. 3. Same. Damn. Thing.

But they'll spend three weeks in shuttle diplomacy because nobody bothered to [define terms](https://www.jstor.org/stable/25146062). It's like watching people argue about whether it's raining or precipitating.

The Real Win
------------

The best stakeholder management isn't diplomacy.  
**It's preventing the war in the first place.**

> • Clear decision frameworks
>
> • Shared success metrics
>
> • Regular stakeholder education
>
> • Ruthless prioritization
>
> • Public documentation

Because every hour you spend shuttling between camps is an hour not spent talking to users, analyzing data, or building something that matters.

**Stop being a diplomatic courier.**  
**Start being a product leader.**

The next time someone says, *"Can you talk to [other team] about this?"*

Smile. Breathe. And say:

*"Let's get them in the room. Together. Today."*

---

*Got your own shuttle diplomacy war stories? Drop them in the comments. Therapy is confidential, but product management pain is communal.*

* [Leave a comment](https://deanpeters.substack.com/p/stakeholder-shuttle-diplomacy/comments)
* [Share](https://deanpeters.substack.com/p/stakeholder-shuttle-diplomacy)

**Next in the Feature Hostage Negotiations series:** *"But the VP Promised It at Lunch"*

---