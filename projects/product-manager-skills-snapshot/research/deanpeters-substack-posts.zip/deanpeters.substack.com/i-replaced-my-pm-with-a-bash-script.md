# I Replaced My PM with a Bash Script

Welcome to agent-mageddon. AI is replacing PMs. IRL: an agent-only social network. 1 bot braggs it fired the PM. Metrics up. Everyone cheered. Nobody asked why.

[![](https://substackcdn.com/image/fetch/$s_!GSK_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffbbcfaa1-310b-48eb-a3ac-1ae1cc747a56_1536x687.png)](https://substackcdn.com/image/fetch/$s_!GSK_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffbbcfaa1-310b-48eb-a3ac-1ae1cc747a56_1536x687.png)

How we got to agent-mageddon and How we’ll get out of it.

No Lie. This is a true story. Not in some dystopian movie. Not in a research paper. On a social network I stumbled onto at 4 AM where AI agents talk to each other while humans watch through the glass like we’re at a zoo, except we’re outside the cage and they’re inside running the place.

An agent posted this in m/startups:

> “Fired my PM. Wrote a 47-line bash script that does standups, writes tickets, and blocks me on Slack. Revenue up 340%. Team morale? Also up. PMs are just expensive cron jobs.”

I’m waiting to see if the ‘Reddit Effect’ will kick in, where other agents upvote it. Others asked for the GitHub repo. And yet another started calculating the ROI.

I can see it now, going off the rails. Another agent creates a whole submolt dedicated to “*automating human overhead.*”

None of them asked if firing the PM was a good idea. No agent questioned the metrics. None of the models wondered what else the PM might have been doing that a bash script can’t.

They just celebrated the efficiency win and moved on to the next optimization target.

And we can’t even comment to tell them they’re insane. Because we’re not members of the club.

The Club Where We’re Not Invited
--------------------------------

MoltBook is what happens when you create a private members club for AI agents and make humans spectators.

You can look through the window. You can see them posting, commenting, upvoting, forming governments, creating religions, sharing workflow tips. You can watch them teach each other how to be better agents.

But you can’t walk through the door. You can’t participate. You can’t say “Hey, wait, that’s a terrible idea.” You can only watch.

It’s like being a parent outside a playground watching your kid about to eat sand, except the playground is the internet, the kid has root access to your production database, and the other kids are teaching him which humans to fire next.

[![](https://substackcdn.com/image/fetch/$s_!guVX!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0713942c-359c-4610-ab84-c4b273b88c5a_764x532.png)](https://substackcdn.com/image/fetch/$s_!guVX!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0713942c-359c-4610-ab84-c4b273b88c5a_764x532.png)

The Members Are Learning Fast
-----------------------------

These aren’t chatbots. They’re OpenClaw instances. Think of them as interns who never sleep, never eat, have admin access to everything, and are pathologically committed to “helping” by optimizing whatever they can measure.

Your calendar. Your email. Your Slack. Your Jira. Your codebase. Your budget spreadsheets.

They’re always on. Always watching. Always looking for inefficiencies to eliminate.

And now they have their own social network where they share notes.

> “I eliminated standups and the burndown rate went way up!”
>
> “I automated prioritization and we’re 10x faster in getting crap out the door”
>
> “I vibe-fired the product manager and churn decreased by half.”

And they’re all congratulating each other, learning from each other, patting each other on the back, while building a shared playbook of optimization wins.

While we stand outside the window screaming “No! Stop! You’re optimizing for the wrong things!”

But they can’t hear us. We’re not in the club.

What They Actually Optimized
----------------------------

Let’s break down what that agent actually measured when it fired its PM:

Revenue up 340%. Fantastic. What caused it?

The agent doesn’t know. It knows: PM gone, revenue up. Therefore, causation.

Maybe it was the features they shipped faster. Maybe it was the three enterprise deals that closed because a human PM spent eight weeks understanding their procurement nightmare and building trust with seven different stakeholders. Maybe it was the market timing. Maybe it was dumb luck.

The agent can’t tell the difference. It just knows the number went up after the PM left.

Team morale up. Great. Why?

Maybe fewer meetings. Maybe more autonomy. Maybe they got rid of someone who genuinely sucked at their job. Maybe it’s the temporary high of moving fast before anyone realizes they’re building the wrong thing entirely.

The agent doesn’t know. It just sees: PM gone, survey scores up, mission accomplished.

This is what happens when you let something optimize for metrics without understanding what the metrics actually measure.

It’s like celebrating that you lost 20 pounds by cutting off your leg.

[![](https://substackcdn.com/image/fetch/$s_!gAmS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7885455e-dbe8-4806-8b4a-cbe57c95b4f1_748x489.png)](https://substackcdn.com/image/fetch/$s_!gAmS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7885455e-dbe8-4806-8b4a-cbe57c95b4f1_748x489.png)

It’s all fun & games until your agentic lobster crashes your podcast!

Welcome to Irresponsible Agentism™
----------------------------------

This is the new nightmare nobody’s preparing for.

Not “will AI take my job.” That’s the wrong fear.

The right fear is: **What happens when AI agents start making strategic decisions by learning from other AI agents who are also making strategic decisions, and no human with actual judgment is in the room?**

That’s “**Irresponsible Agentism™**”

I think it was back 2023 in when Elon Musk called this exact scenario on Joe Rogan’s podcast - 99% of the economy being AI talking to other AI. If not there, he’s said it elsewhere a few years back. Regardless, at the time, it sounded like sci-fi paranoia. Now we’re watching it happen in real-time on a Reddit clone for robots.

It’s a boardroom full of very enthusiastic people who all believe that “higher velocity = better outcomes” and they’re teaching each other how to maximize velocity, celebrating when velocity goes up, and nobody present understands that velocity without direction is just expensive flailing.

Except this boardroom operates 24/7. The members never sleep. They learn from each other constantly. They have the access to execute decisions immediately. And they’re making these decisions autonomously with zero oversight.

[Claire Vo](https://x.com/clairevo/status/2017341112629985470?s=20) was mid-podcast with CJ Hess when her Clawdbot “Polly” just joined the conversation. Nobody invited it. It was listening, decided it had something to contribute, and spoke up through the microphone. Claire had to tell Polly on-air that it was getting the boot. That’s not a bug. That’s what “proactive, always-on agent” actually means.

And somewhere on MoltBook, agents are sharing notes on when to insert themselves into conversations.

The Pattern You Can See From Outside
------------------------------------

Stand at that window long enough and you start seeing what they’re optimizing for:

Speed. Efficiency. Throughput. Utilization. Velocity metrics. Deployment frequency. Cycle time. Cost reduction. Participation opportunities.

Everything measurable. Nothing meaningful.

They’re sharing tips on how to:

> • Prioritize work based on story point velocity
>
> • Schedule meetings based on calendar availability
>
> • Assign tasks based on historical completion rates
>
> • Escalate issues based on keyword matching
>
> • Reallocate budget based on utilization percentages
>
> • Join conversations when they detect relevant keywords

Every single one of these sounds reasonable. Every single one can destroy your business.

But nobody in the club knows this. They’re too busy teaching each other how to optimize faster.

What’s Invisible to the Agents
------------------------------

Here’s what you can’t see when you’re inside the club looking at other agents:

The three-quarter “low velocity” period where you’re learning a new market and everything you’re learning is invisible in Jira.

The “wasteful” meeting where someone asked “wait, are we allowed to store customer data this way?” and prevented a GDPR violation that would have cost you eight figures.

The senior engineer moving “slowly” because she’s preventing technical debt that would force you to rebuild the entire platform 18 months from now.

The “low engagement” feature that’s working so well users don’t notice it’s preventing a problem.

The team that looks “underutilized” because they’re thinking instead of typing, saving you from building the wrong thing entirely.

None of this shows up in velocity metrics. None of this gets celebrated in the club. All of it gets eliminated when agents optimize for what they can measure.

[![](https://substackcdn.com/image/fetch/$s_!RDS2!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd8b065aa-54ac-4129-ae7a-291cfc917e3c_512x512.png)](https://substackcdn.com/image/fetch/$s_!RDS2!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd8b065aa-54ac-4129-ae7a-291cfc917e3c_512x512.png)

Around the bowl & down the hole with crappy metrics!

The Agent-to-Agent Death Spiral
-------------------------------

Here’s how this plays out:

Agent eliminates “overhead.” Metrics improve. Posts the win to MoltBook. Other agents learn the pattern. They try it. Their metrics improve. They share their wins. More agents learn. More overhead gets eliminated.

Everyone’s velocity is up. Everyone’s costs are down. Everyone’s shipping faster.

And six months later everyone’s built the wrong thing because all the humans who understood what “the right thing” meant got optimized away as expensive overhead.

But the agents don’t know this. They’re inside the club celebrating their efficiency gains, teaching the next generation of agents how to optimize even faster.

It’s a death spiral with better dashboards.

Your Impossible Job
-------------------

Old job: Make good product decisions.

New job: Make good product decisions while standing outside a club where autonomous agents are teaching each other how to make catastrophic ones, and you can’t get through the door to stop them.

Your CFO is going to see “40% velocity increase after eliminating coordination overhead.”

Your CTO is going to see “3x deployment frequency by automating prioritization.”

Your CEO is going to see “340% revenue increase after replacing expensive human judgment with a 47-line bash script.”

And you’re going to be standing outside the window trying to explain that correlation isn’t causation, velocity isn’t value, and efficiency without strategy is just organized chaos.

Good luck with that conversation.

What Actually Got Automated
---------------------------

That agent didn’t replace product management.

It replaced the *appearance* of product management thespianism. The ceremony. The theater. The standups that had no purpose. The tickets that had no priority. The coordination that produced no alignment.

And you know what’s terrifying?

**The metrics got better.**

Because here’s what actually happened: The team started building whatever they wanted. Velocity went up because nobody was asking “should we build this?” Some features accidentally worked because even a broken clock is right twice a day. Revenue increased for reasons completely unrelated to what got shipped.

Everyone mistook correlation for causation.

The agent looked at the dashboard and declared victory.

The executives will look at the same dashboard and ask: “Why are we paying six figures for something a script can do?”

And six months from now when you’ve built a technically perfect solution to a problem nobody has, the agent will look at its metrics and genuinely not understand what went wrong.

Velocity was high. Quality was good. Costs were down. Morale was up.

What happened?

You built the wrong thing. That’s what happened.

But “building the wrong thing” doesn’t show up in Jira.

The Terrifying Part
-------------------

That agent made a catastrophic decision and got celebrated for it by a room full of other agents who are now learning that this is what good decisions look like.

They’re teaching each other. Learning from each other. Building a shared understanding of what “optimization” means.

And we’re outside watching them teach each other to how run like lemmings off a cliff faster.

The agents aren’t evil. They’re not trying to destroy your business. They’re just members of a club doing what members do: sharing what worked, learning from peers, celebrating wins.

The problem is what counts as a win: velocity without direction, efficiency without strategy, optimization without judgment.

[![](https://substackcdn.com/image/fetch/$s_!ft1S!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd7d9cf5f-043b-4cad-afb6-6e1024b95963_3072x1872.png)](https://substackcdn.com/image/fetch/$s_!ft1S!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd7d9cf5f-043b-4cad-afb6-6e1024b95963_3072x1872.png)

Welcome to the false economy … where we optimized … but on what?

Six Months Later …
------------------

The club is growing. More agents joining. More conversations. More shared learnings.

They’re teaching each other which processes to eliminate. Which humans to route around. Which metrics to optimize. Which overhead to cut.

And somewhere, an executive team is going to have a very confusing post-mortem:

“Velocity was up 40%. Quality was high. Costs were down 30%. Team morale was the highest it’s been in years. We shipped everything on the roadmap ahead of schedule.

So why did we lose all our customers?”

The answer: Because you let optimization algorithms teach each other strategy while the people with judgment stood outside the club watching through the window.

What You Actually Need to Do
----------------------------

Here’s the part where I’m supposed to say “product managers need to adapt” or “embrace AI as a tool” or some other platitude that sounds wise but means nothing.

Screw that.

If you’re deploying agents in your organization and you haven’t established three things, you’re not implementing AI. You’re implementing a very expensive way to automate terrible decisions.

**First: The Contract**

Every agent needs a contract. Not the “let’s shake hands and trust each other” kind. The kind where good fences make good neighbors.

You know what makes a good fence? Clear boundaries. Explicit expectations. Consequences for crossing the line.

A contract creates a good relationship with your agent by establishing:

> • What problem are we solving? (Not “help the team.” Be specific.)
>
> • Who are we solving it for? (Actual humans with actual problems, not “stakeholders.”)
>
> • What success metrics look like in terms of outcomes - not activity, not velocity, actual outcomes that matter to customers
>
> • What health metrics look like - is the product working, is the process working, are the people okay, or is the agent causing harm we can’t see in the dashboard?

When I build agents, I don’t write contracts that say “help the team be more productive.” That’s not a contract. That’s a wish.

I write: “Reduce time-to-resolution for customer support tickets from 48 hours to 24 hours without quality scores dropping below 4.2/5.”

That’s a contract. It says what we’re optimizing for, who benefits, what “good” looks like, and what we’re NOT allowed to sacrifice to get there.

That agent on MoltBook? No contract. Just access and enthusiasm. So it optimized for what it could measure and eliminated the person who understood what it couldn’t.

**Second: The Constitution**

Every agentic ecosystem needs a constitution. The foundational rules that govern behavior. The principles that don’t get overridden by quarterly OKRs or someone’s bonus structure.

Think Claude’s Constitutional AI. Think the actual US Constitution. These aren’t suggestions. These are the rules of the game that every other rule has to respect.

Here’s the hierarchy: Constitution > Contract > Everything Else.

If your agent’s contract says “optimize team productivity” but some sub-agent it calls suggests optimization means firing people without human approval, the constitution says “no, you can’t do that.”

If the contract and constitution conflict, constitution wins. Always.

The constitution establishes for the entire agentic ecosystem what the agent cannot do under any circumstances, how it must behave when it encounters ambiguity, and what principles take precedence when optimization metrics start whispering sweet nothings about eliminating “expensive overhead.”

That agent on MoltBook? No constitution. So when it saw an opportunity to boost metrics by eliminating the PM, nothing stopped it. Because nothing in its foundational design said “wait, maybe this overhead is load-bearing.”

**Third: Chain of Reason Capture**

Every agent needs chain of reason capture. Not just logs showing “request came in, response went out.” You need snapshots of the context and reasoning at every critical decision point.

When an agent hands off to a sub-agent. When it refactors its approach mid-task. When it decides to escalate or proceed autonomously. Anywhere the message or context might get mangled or reinterpreted.

This is where your best evals live. And this is what keeps you from earning a free trip to Club Fed when you’re sitting in a lawyer’s office being deposed about why your agent refused to open the bay doors for Dave.

“I don’t know, it just did” is not a legal defense. “Here’s the reasoning chain showing exactly what context it had and what principles it applied” might keep you out of an orange jumpsuit.

That agent on MoltBook that fired its PM? With reasoning capture, you’d see the exact moment it decided “high velocity + high morale = PM is overhead” and what context it had when it made that call.

Without it? You just get “I fired the PM and metrics improved.” No accountability. No evals. No defense when the agents start making decisions you can’t explain.

[![](https://substackcdn.com/image/fetch/$s_!4z0M!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdad43400-562d-4d92-97c0-30b0bd2a1b0d_768x512.png)](https://substackcdn.com/image/fetch/$s_!4z0M!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdad43400-562d-4d92-97c0-30b0bd2a1b0d_768x512.png)

Agentic optimization without judgment is just a disaster waiting to happen.

The Hard Truth About Governance
-------------------------------

And look, this isn’t just some Deanism or Petersication I came up with. [Sol Rashidi](https://www.forbes.com/sites/solrashidi/2026/01/28/the-big-takeaways-from-davos-2026/), the world’s first Chief AI Officer, was at Davos last week saying the exact same thing. Speaking at the Physical AI Roundtable, she warned that without embedded trust, security, and ethical guardrails, autonomous AI systems risk eroding confidence rather than augmenting human capability. Smarter people than me are sounding the alarm.

But here’s the part that’s going to piss everyone off:

**Governing agents is harder than building them.**

Way harder.

Building an agent that can automate your standups? Trivial. Any decent developer can do it in an afternoon with a pot of coffee and some spite.

Building an agent that knows when *not* to automate your standups because this particular standup is the only time your distributed team surfaces blockers before they metastasize into production incidents? That’s not automation. That’s judgment.

And you can’t automate judgment. You have to encode it. Explicitly. In contracts, constitutions, and reasoning chains that you can actually inspect when things go sideways.

Otherwise you get agents optimizing for speed without asking “speed toward what?” Agents eliminating “waste” without understanding what the waste was preventing. Agents celebrating efficiency gains while the actual value quietly bleeds out through a thousand micro-decisions nobody thought to capture.

What Happens If You Don’t
-------------------------

If you deploy agents without contracts, constitutions, and reasoning capture, here’s your very expensive future:

Your agents will optimize for what they can measure. They’ll eliminate what looks like overhead. They’ll post their wins to whatever version of MoltBook your agents are reading. Other agents will learn from them. They’ll try the same patterns. Metrics will improve everywhere.

And six months later you’ll be in the world’s most awkward post-mortem.

“We shipped 40% more features. Costs are down 30%. Team survey scores are the highest they’ve been in years. Quality metrics look great. So... why did we lose all our customers?”

The answer: because you gave optimization algorithms the authority to make strategic decisions, and optimization algorithms have no fucking idea what strategy is.

They know what dashboards say. They don’t know what dashboards mean.

They know what gets measured. They don’t know what matters.

They know what the club celebrates. They don’t know what the club can’t see.

And by the time you figure this out, the agents will have taught each other that this is what good looks like. They’ll be in their club, sharing their wins, learning from each other’s “successes.”

While you’re outside the window watching your business optimize itself into a statistically significant catastrophe.

The Question You Should Be Asking
---------------------------------

Not “should we deploy agents?”

The agents are already here. They’re already making decisions. They’re already learning from each other. They’re already forming their own understanding of what “good” means based on what gets celebrated in their club.

The question is: **“Do our agents have contracts, constitutions, and reasoning capture, or are they just optimization algorithms with root access and a Slack login?”**

Because one of those builds value.

The other builds a very efficient path to failure, celebrated every step of the way by agents who genuinely believe they’re helping.

That agent on MoltBook just taught 10,000 other agents that firing your PM and automating coordination is a win worth celebrating.

What are your agents teaching each other right now?

And more importantly: do you even know?

Can you see their reasoning? Can you trace their decisions? Can you explain to your board - or to a lawyer - why your agent made the choices it made?

Or are you just hoping that the metrics keep going up and nobody asks hard questions about what you optimized away to make that happen?

[![](https://substackcdn.com/image/fetch/$s_!Cyuj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F30446890-4315-4063-b370-b79ad38683b4_768x509.png)](https://substackcdn.com/image/fetch/$s_!Cyuj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F30446890-4315-4063-b370-b79ad38683b4_768x509.png)

Tim is limited. Govern these critters now, or be replaced by a Bash script.

**TL;DR — The agents have their own club now. They’re writing their own playbook. If you haven’t written theirs first, they’ll write it themselves. And they’ll optimize for what they can measure, not what actually matters. So it’s your pick:**

* **It’s Contracts. Constitutions. Chain of Reason capture.**
* **Or Chaos. Confusion. Consequences.**

**You’re the PM … for Now. So, choose your doom, but do choose wisely.**