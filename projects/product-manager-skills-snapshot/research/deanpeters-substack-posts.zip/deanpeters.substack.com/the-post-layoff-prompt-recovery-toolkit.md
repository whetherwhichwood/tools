# The Post-Layoff Prompt Recovery Toolkit

[John Cutler](https://open.substack.com/users/5656342-john-cutler?utm_source=mentions) dropped a [layoff parody prompt on LinkedIn](https://www.linkedin.com/posts/johnpcutler_if-youre-just-chomping-at-the-bit-to-do-activity-7328835781140107264-MOX6?utm_source=share&utm_medium=member_desktop&rcm=ACoAAADEu00BWMZwO7QA8ZEorayAxr4F_LdrMrs). Microsoft had just nuked 7,000 employees & called it strategy. Not a memo. Not a town hall. A vibes-based reorg wrapped in AI buzzwords & LinkedIn “*grit*.” His prompt dared us: **write a fake thought-leadership post to spin this bloodbath into vision.**

[![A biting commentary on the absurdity of corporate layoffs, reframed as a darkly humorous survival toolkit for product managers seeking catharsis through parody, not pity.](https://substackcdn.com/image/fetch/$s_!9o6i!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffa1b79a5-8cd2-4ad3-8933-418083909852_3760x2050.png "A biting commentary on the absurdity of corporate layoffs, reframed as a darkly humorous survival toolkit for product managers seeking catharsis through parody, not pity.")](https://substackcdn.com/image/fetch/$s_!9o6i!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffa1b79a5-8cd2-4ad3-8933-418083909852_3760x2050.png)

This isn’t healing. It’s a product management prompt therapy toolkit.

### Why We Wrote This

Instead, I spun up three. Three unhinged, unfiltered, painfully accurate writing prompts to help every product manager process their latest workplace breakup. Not with grace. With gallows humor.

Because we’ve all nodded through the layoffs pretending it was a "*realignment*." We’ve all watched our roadmaps replaced with PowerPoint astrology. We’ve all been thanked for our “impact” 10 minutes before losing Slack access.

So we turned rage into satire. Pity into parody. Burnout into black comedy. This isn’t a writing exercise. It’s post-layoff catharsis. A toolkit for the recently reorganized. A digital scream into the void disguised as creative expression.

Call it group therapy for PMs who emotionally quit two quarters ago. Call it a creative exit interview. Call it what it is: the only severance package that doesn’t suck.

### What’s Inside

Inside you’ll find:

* A **Dear John letter** to your former employer, narrated by the voice of your choosing
* A **1-star Glassdoor review** written like a slow-motion wildlife documentary
* A **LinkedIn influencer post** so cringe-core it deserves a WeWork mural and a standing desk

You don’t need closure. You need comedy.

Welcome to your layoff recovery kit.

Bring spite. We’ve got prompts!

[![A darkly comic metaphor for tech’s cold transition to automation, where product managers are offboarded by AI and left to reclaim their humanity through parody-driven writing prompts.](https://substackcdn.com/image/fetch/$s_!_G5d!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa67c89e1-5fc1-4c6f-af78-5ec387ad9960_1536x1024.png "A darkly comic metaphor for tech’s cold transition to automation, where product managers are offboarded by AI and left to reclaim their humanity through parody-driven writing prompts.")](https://substackcdn.com/image/fetch/$s_!_G5d!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa67c89e1-5fc1-4c6f-af78-5ec387ad9960_1536x1024.png)

Yes, the bots may have given you the boot, but we give you chatbot catharsis!

The Prompts
-----------

Here’s a [full example ChatGPT session](https://chatgpt.com/share/6826668b-f984-8010-a44a-aa7af77eb86c) where I ran the following three prompts, one after the other.

#### Prompt 1: Dear John, Breakup Letter

Write the note you wish you’d sent — the one that begins, "Oh, you think *you* broke up with *me*?" and ends with a petty burn disguised as professional reflection. Choose your narrator (Morgan Freeman? Werner Herzog? Ricky Gervais?) and let the prompt shape your farewell as ancient prophecy, bleak docudrama, or British sarcasm.

> **Example Snippet:**  
> *“I emotionally quit the moment we started doing standups in haiku. Thanks for the severance — I’ve already reorg’d myself into a better plotline.”*

Try the prompt here: [You Can't Fire Me, I Quit Dear John Letter Prompt](https://github.com/deanpeters/product-manager-prompts/blob/main/resumes-resignations-reactions/Reaction%20%E2%80%93%20You%20Can't%20Fire%20Me%20I%20Quit%20Dear%20John%20Letter.md)

#### Prompt 2: Glassdoor Review of Doom

Craft a 1-star review so witheringly specific it might end up framed in HR’s war room. Chronicle the emotional pantomime. The Slack rituals. The vibe-check bots. Then deliver your final mic drop with all the deadpan fury of a burned-out Attenborough.

> **Example snippet:**  
> ”*To survive, I leaned on ancient rituals: rearranging virtual Post-its on a Miro board like I was conducting a séance, writing haikus in Jira tickets for bugs that would never get fixed … and setting weekly 1:1s with my emotional support plant, Greg.”*

Try the prompt here: [Glassdoor Review Prompt: A Masterclass in Pretending to Care](https://github.com/deanpeters/product-manager-prompts/blob/main/resumes-resignations-reactions/Reaction%20%E2%80%93%20Glassdoor%20Review%20%E2%80%93%20A%20Masterclass%20in%20Pretending%20to%20Care.md)

#### Prompt 3: LinkedIn Lifestyle Clapback

Take the genre of post-layoff influencer wisdom — and turn it against itself. Write a hustle-core post so performatively hollow it accidentally circles back into brilliance. Let the tone drip with buzzwords. Spin the layoff into a Category Design Moment. Make it satire. Make it viral.

> **Example Snippet:**  
> *“AI is not coming for our jobs. It’s coming through our jobs. Like a product-market tsunami coded in Python, it’s reshaping work, worth, and word count. These weren’t layoffs. They were a **beta test in human obsolescence**. And you know what? I’m here for it. I've never felt more Agile.”*

Try the prompt here: [LinkedIn Influencer Article](https://github.com/deanpeters/product-manager-prompts/blob/main/resumes-resignations-reactions/Reaction%20%E2%80%93%20LinkedIn%20Lifestyle%20Influencer%20Article%20%E2%80%93%207%20Steps%20to%20Nowhere.md) — [7 Steps to Nowhere](https://github.com/deanpeters/product-manager-prompts/blob/main/resumes-resignations-reactions/Reaction%20%E2%80%93%20LinkedIn%20Lifestyle%20Influencer%20Article%20%E2%80%93%207%20Steps%20to%20Nowhere.md)

Call to Action
--------------

Tried one? Share it.

Post your satirical masterpiece in the comments, or link out to your own prompt-powered revenge post. Bonus points for dramatic readings, AI narration, or Slackbot reenactments. Tag it: **#LayoffRecoveryKit**

Because laughter is cheaper than therapy — and way more fun on LinkedIn.

Oh … and …

Subscribe

[Share](https://deanpeters.substack.com/p/the-post-layoff-prompt-recovery-toolkit?utm_source=substack&utm_medium=email&utm_content=share&action=share)

[Leave a comment](https://deanpeters.substack.com/p/the-post-layoff-prompt-recovery-toolkit/comments)