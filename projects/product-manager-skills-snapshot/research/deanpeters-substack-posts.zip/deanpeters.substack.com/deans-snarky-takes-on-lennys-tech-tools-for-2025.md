# Dean’s Snarky Takes on Lenny’s Tech Tools for 2025

Intro
-----

[![A satirical ranking of the year’s worst product management trends](https://substackcdn.com/image/fetch/$s_!1tms!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6e88118e-b1f9-4835-8ac9-3195e3f3daaa_3198x1970.png "A satirical ranking of the year’s worst product management trends")](https://substackcdn.com/image/fetch/$s_!1tms!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6e88118e-b1f9-4835-8ac9-3195e3f3daaa_3198x1970.png)

Because some tools deserve a chart—and others deserve a roast.

I love Lenny’s annual ‘**[The state of tech tools in 2025](https://www.lennysnewsletter.com/p/whats-in-your-stack-the-state-of?r=3jxqq&utm_campaign=post&utm_medium=web&showWelcomeOnShare=false)**’ – written by [Noam Segal](https://substack.com/@noamsegal) of the ‘[Disruptive Coach Substack](https://noamsegal.substack.com/)’ – even if it took me nearly 4 months to get around to this analysis of 6,500 tech professionals.

It’s like Comic-Con for product nerds — a full tour of what’s hot, what’s hyped, and what’s quietly holding the world together with duct tape.

Still, I **think perhaps waiting has paid off**, as some of the items on the list remain hot, others not. If nothing else, it is an exercise in demonstrating how fast the AI market is moving and how **much gold turned out to be pyrite.**

But trying to read it straight through the list?  
It’s like drinking from a firehose strapped to a SaaS startup pitch deck.  
After about the 30th chart, my brain staged a coup.

So this year, I played my own home version of **Product Management Mystery Science Theater 3000**:  
Every time I hit a key finding, I blurted out a smart-ass remark before my inner PR filter could kick in.

No disrespect.  
All admiration.  
Just caffeine, raw nerve endings, and survivor sarcasm.

Here’s the result:  
10 key takeaways.  
10 uncensored reactions.  
Buckle up.

[![Lenny brought the stack. I brought the grill. Guess what’s getting skewered?](https://substackcdn.com/image/fetch/$s_!DtDe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4e2e8a29-068c-41b1-8738-9f18b1812efc_3066x2030.png "Lenny brought the stack. I brought the grill. Guess what’s getting skewered?")](https://substackcdn.com/image/fetch/$s_!DtDe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4e2e8a29-068c-41b1-8738-9f18b1812efc_3066x2030.png)

Lenny brought the stack. I brought the grill. Guess what’s getting skewered?

The Top 10 Takeaways, Blurts, and Outburts
==========================================

### 1. AI Is the New Hot Sauce

*"Generative AI exploded across every category."*  
**Blurt:**  
Now every app thinks it’s Gordon Ramsay, shrieking "*Dammit Claude! It’s bloody raw!*" while I'm just trying to reheat last week's user story stew with ChatGPT.

### 2. Data Analytics Is Finally a Grown-Up Table Topic

*"Amplitude, Mixpanel, Looker are now essentials."*  
**Blurt:**  
After twenty years of shipping blindfolded, someone finally screamed, "Maybe we should check if anyone’s even using this junk before we ship another dozen features?"

### 3. Product Roadmaps Finally Found GPS

*"Roadmapping tools like Productboard and Jira Product Discovery are surging."*  
**Blurt:**  
I’m never sad when a poser Gantt chart gets flattened into steaming roadkill, tire tracks and all. Especially when it was masquerading as "agile."

### 4. Linear and Shortcut Are Trying to Make Dev Work Less Sad

*"Linear gaining major ground with engineers escaping Jira."*  
**Blurt:**  
Same carnival, different tent — only now the clowns have cooler logos and vibe-check their Kanban boards before stapling themselves to another release train.

### 5. Figma Owns Design. Full Stop.

*"Figma dominates design collaboration."*  
**Blurt:**  
It’s all fun and games until your team pukes out a 147-screen AI-generated prototype that nobody remembers asking for — and you're left sticking all onto an MVP planning board like you’re playing the scrumball version of pin the tail on the donkey.

### 6. Experimentation Isn't Cute Anymore — It's Required

*"Feature flags, A/B testing, experimentation tools are table stakes."*  
**Blurt:**  
Big bangs are out. Tiny (***I SAID TINY DAMMIT!***) controlled detonations with a limited blast radius no bigger than a WeWork conference room are the only way forward.

### 7. The "All-in-One" Platform Rush Is Back

*"Teams crave consolidated workflows and fewer tabs."*  
**Blurt:**  
Dear God, not another 51-function Copilot-addled Swiss Army knife that folds itself into a sad little meatball and still can’t open a beer without starting a fire.

### 8. AI’s Everywhere — But Actual Productivity Gains Are Rare

*"Everyone's adding AI. Results are... mixed."*  
**Blurt:**  
Woohoo! Twice the crap at ten times the speed — only now it writes its GROKifried footnotes and demands a "***prompts manager***" to babysit it.

### 9. Saving Time Is Still the Oldest Lie in the Book

*"Time-saving tools continue to drive adoption."*  
**Blurt:**  
Save five hours upfront, burn fifty more editing hallucination-drunk PRDs, and sweeping up "smart automations" that accidentally launched a beta to your boss’s boss’s boss.

### 10. Slack, Zoom, Jira ... Sadly … Still Rule the Empire

*"Slack still #1 for communication. Jira still #1 for work tracking."*  
**Blurt:**  
Sure would be a shame if it turns out we just slathered speed-saving glitter and AI hot sauce onto a three-week-old potato salad and called it "the future of work." Kinda like lipstick on a pig, dontcha think?

Final Tip
=========

In 2025, it’s not about how many tools you stack.  
It’s about staying smarter than the stack you built.

Ethan Mollick said it best in *Co-Intelligence*:  
**AI isn’t just speeding up work — it’s quietly causing intellectual atrophy.**

If you’re not thinking harder and sharper, no amount of AI is going to save you.  
You’ll just be the next dummy duct-taping Agentic AI fairy dust onto your SaaS salad and calling it "*innovation*."

Stay sharp. Stay dangerous. Stay human.

---

Want more? **Subscribe, Share, & Comment**! C’mon, smush them buttons, it’ll be fun!

Subscribe

[Share](https://deanpeters.substack.com/p/deans-snarky-takes-on-lennys-tech?utm_source=substack&utm_medium=email&utm_content=share&action=share)

[Leave a comment](https://deanpeters.substack.com/p/deans-snarky-takes-on-lennys-tech/comments)