# Prompt Engineering, The IKEA Way

### Why We’re Here

Ever handed someone a manual, only to watch them use it as a coaster? Yeah, me too.  
People don’t read. They skim. Scroll. Sigh. Guess.  
That’s why unboxing instructions now look like preschool puzzles: six pictures, zero text, maximum sanity.

[![](https://substackcdn.com/image/fetch/$s_!eNWv!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7c4e00f5-5b2e-417c-8bb5-178f08531ba9_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!eNWv!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7c4e00f5-5b2e-417c-8bb5-178f08531ba9_1536x1024.png)

Simplifying complex workflows—one ridiculous, visual step at a time.

---

### The Prompt That (Almost) Replaces the Manual

Credit to Ethan Mollick for the spark: he got GPT-3o to [turn](https://x.com/emollick/status/1918545934633357596) *[Genesis 1 and 2](https://x.com/emollick/status/1918545934633357596)* [into IKEA instructions](https://x.com/emollick/status/1918545934633357596).  
That’s when it hit me: if you can do it for the Bible, you can do it for a backlog.

So I built a **low-code mega-prompt** that:

* Asks you for a topic
* Generates five ridiculous-but-logical steps
* Converts them into **IKEA-style deadpan chaos**
* Offers a visual: **six-panel, black-and-white, faceless PM fable**

You can run it for good. You can run it for evil.  
You can run it on your roadmap and meme it into Slack legend.  
You can get the prompt for free via my GitHub repo (link at end of post).

---

```
Hey, Yo! ChatGPT — you are a creative AI assistant for a strategic product manager. Your job is to help the user generate a set of **absurd, interconnected, and wildly impractical steps** for a given topic — in the style of those cryptic IKEA instruction sheets, narrated by a product manager who’s two lattes deep into a breakdown.

# Step 1: Topic Selection
Ask me:
> "What topic or process would you like to create 5 silly, absurd, and outrageously impractical steps for?"
```

---

WHY?
----

**Because people won’t Follow Instructions—So Make Them Impossible to ignore!**So why not *visualize the absurd* and *weaponize delight*?

**Because if you make it easy and fun—Perhaps, just perhaps they’ll onboard!**So give people something they can laugh at, follow, share—and maybe even learn from.

---

Want Proof?  
  
Here’s the visual instruction page on how to use my prompt: [Generator - IKEA-like instruction steps.md.](https://github.com/deanpeters/product-manager-prompts/blob/main/storytelling/Generator%20-%20IKEA-like%20instruction%20steps.md?plain=1)

[![From confusion to clarity—prompt engineering as visual storytelling.](https://substackcdn.com/image/fetch/$s_!Tnih!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F24b4618b-f391-4a7d-9634-32a79b82cc0e_1024x1536.png "From confusion to clarity—prompt engineering as visual storytelling.")](https://substackcdn.com/image/fetch/$s_!Tnih!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F24b4618b-f391-4a7d-9634-32a79b82cc0e_1024x1536.png)

Because your team prefers pictures, I describe using my prompt in 6 images.

---

### What Makes this Prompt Different?

A few secret ingredients that make this more than just a prompt party trick:

* **Agent Role Clarity**  
  Opens by telling ChatGPT who it is and what it’s doing.  
  (“You are a creative AI assistant for a strategic PM…”)
* **Audience Framing**  
  It doesn’t generate for the void—it generates for *us*: overcaffeinated PMs on deadline #7.
* **Step Discipline**  
  It *demands* five logical-but-illogical steps. No jump cuts. No plot holes.  
  Then it asks if you want it flattened into soulless IKEA misery.  
  Then it *draws the comic*.
* **Tone Lock**  
  The vibe?

> *“Wes Anderson’s angriest intern builds a product storyboard.”  
> It’s not just funny. It’s structured absurdity.*

---

```
# Step 4: Offer to Draw a 6-Panel IKEA-Style Visual
Then ask:
> "Would you like a six-panel,six-step IKEA-style 16:9 portrait image drawn in bold, faceless line art?"

If yes:
- Generate a **six-panel image, 16:9 aspect ratio, in portrait orientation**
- Each panel corresponds to one numbered step from the IKEA text
- Style: **bold black-and-white IKEA-style line art**
- Panels must be clearly **numbered 1 through 6** in sequential order 
- Use simple props, visual continuity, and no faces
- Text for each step just below the image, but no words in or as part of the image
- Minimalism, arrows, and existential despair encouraged
```

---

### But Also… It’s a Lot

This prompt isn’t lightweight. It’s got layers.  
If it breaks on you the first time, welcome to IKEA.  
Screwdriver’s in the meatballs. You’ll be fine.

**Run it two or three times.**  
Tweak your topic.  
Keep going.  
You’ll end up with visualized instructions that:

* Tell your story
* Reinforce your idea
* Help your team get it
* And yeah, make you look just a little bit brilliant

---

### Run the Full Prompt

Here’s the full thing, hosted on GitHub:  
[Generator - IKEA-like instruction steps.md](https://github.com/deanpeters/product-manager-prompts/blob/main/storytelling/Generator%20-%20IKEA-like%20instruction%20steps.md?plain=1)

---

CTA(s)
------

If you experiment with the prompt, share the outcomes here in a note or comment.  
  
If you like what you’ve read, **[SUBSCRIBE](https://deanpeters.substack.com/subscribe?simple=true&next=https%3A%2F%2Fdeanpeters.substack.com%2F)!**