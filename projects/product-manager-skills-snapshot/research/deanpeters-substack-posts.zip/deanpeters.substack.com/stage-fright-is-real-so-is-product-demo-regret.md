# Stage Fright Is Real. So Is Product Demo Regret.

Most product managers get zero demo training, then wonder why their pitch falls flat. Here's what singing opera taught me about landing high-stakes product demos with clarity, confidence, and a backup plan when everything falls apart.

[![It's not a matter of 'if' your demo will fail, but 'when'. You don’t win demos by being flawless. You win by being unforgettable.](https://substackcdn.com/image/fetch/$s_!5gV0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fee52ab6c-f191-44af-9459-77442c8c3d74_1536x1024.png "It's not a matter of 'if' your demo will fail, but 'when'. You don’t win demos by being flawless. You win by being unforgettable.")](https://substackcdn.com/image/fetch/$s_!5gV0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fee52ab6c-f191-44af-9459-77442c8c3d74_1536x1024.png)

You don’t win demos by being flawless. You win by being unforgettable.

Before I was defusing stakeholder sabotage and running on prototype vaporware, I was belting baritone arias in costumes so hot they could double as sauna tents. Yes, worst-kept secret on the internet:

* I sang opera professionally.

And here’s the twist most PMs miss:

**Product demos aren’t software tours. They’re full-blown performances.**

You’re not just pushing pixels. You’re pulling heartstrings. Convincing your audience to believe in a future they haven’t seen yet—and give you their money to get there.

Opera taught me that every show is a gamble. Mics die. Tenors flake. Props vanish. But when the curtain rises, the audience still expects goosebumps.

Sound familiar?

Here’s what stagecraft taught me about running a product demo that doesn’t just survive chaos—but thrives in it.

---

1. Know the User Journey Like You Know the Music
------------------------------------------------

> “How do you get to Carnegie Hall?”  
> By practicing the right damn story. Not the version Legal approved. Not the happy-path fantasy. The one that *lands*.

* **Know the beats = Know their needs.**  
  You’re not the star. The user is. Hit their pain points, show your product solving it, and close with ROI that drops jaws.
* **Rehearse where it squeaks.**  
  If your demo only works in good lighting and full Wi-Fi, congrats—you’ve built an illusion. Take a page from our programmer peers: performance test your performance. Rehearse in real-world conditions where latency is laggy and pressure is high.
* **Don’t rehearse bad habits.**  
  Repetition doesn’t equal improvement if you’re practicing the wrong thing. Record yourself. Watch it back. Cringe. Then fix it. Perfect practice beats painful autopilot and doubling down on dysfunction.
* **Tag in when someone freezes.**  
  Multi-person demo? There’s always one junior PM with flop sweat, locked into the script like it’s Hamlet. Be their understudy. Know their lines. Don't judge them. Don’t let the scene die.
* **Demo to the person who doesn’t want to be there.**  
  If you win them over, everyone else is gravy.
* **Test on people with zero context.**  
  A good rule: if your mom, barista, or that one disinterested stakeholder doesn’t get it—your buyer won’t either.

---

2. Something Will Go Sideways—Play It Like Jazz
-----------------------------------------------

Opera, theater, product demo—it’s live performance, baby. And live means messy. It’s not about avoiding mistakes. It’s about recovering with style.

* **Have backup props.**  
  A screen recording, a Figma fallback, a PDF deck, a napkin sketch—whatever makes the story land when the main act flops.
* **Scout the venue ahead of time.**  
  I used to walk the stage barefoot so I could feel every creaking floorboard. In demo land? That means logging in early, testing screenshare, and pre-muting the rogue Slack channel.
* **Tech crews are sacred.**  
  Thank your AV person. Get there early. Make time to work with them. Bring them cookies. They are the most underappreciated heroes you'll want in your corner when things go sideways.
* **Don’t cold-open. Warm up.**  
  Get your slides in order. Your voice loose. Your mind sharp. No one wants to buy from someone who sounds like a dial-up modem.
* **Design your failure arc.**  
  Have a line you can deliver when everything crashes. Something like: “Let’s pretend the tech isn’t haunted and imagine how this would delight your users...” Then *deliver the story anyway.*
* **NEVER rehearse on the day of the demo!**  
  Skip the last-minute full run-through (*yes, I'm looking at you, former chorus directors*). You’ll drain your best energy and walk on stage sounding like a defragging modem. Save the juice for the live show—channel that pre-demo adrenaline into presence, not panic.

---

[![Be ready for "Alas, poor HDMI ... I knew him, Horatio" moments. Practice so you can command the room ... even when the laptop refuses.](https://substackcdn.com/image/fetch/$s_!a4DW!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8de1a480-b16c-40cb-9411-57e9294cbb3c_1536x1024.png "Be ready for \"Alas, poor HDMI ... I knew him, Horatio\" moments. Practice so you can command the room ... even when the laptop refuses.")](https://substackcdn.com/image/fetch/$s_!a4DW!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8de1a480-b16c-40cb-9411-57e9294cbb3c_1536x1024.png)

Command the room … even when the laptop refuses!

3. Tales from the Pit: Demo Horror Meets Opera Chaos
----------------------------------------------------

### *The Case of the Kidnapped Wagon*

Opera: *Der Mond*. Prop: Wagon. Status: Hijacked by sugar-addled child actors from *Hansel & Gretel*.

Because we’d swapped parts in rehearsal, we could stall and riff long enough for the prop to roll in. The audience never noticed. The conductor did. He aged ten years.

### *The Coat Rack Cluster*

Show: *Cabaret*. My entrance blocked by a rolling costume rack and partially dressed dancers.

Because I’d walked the space earlier, I knew the alternate route and hit my mark. That, friends, is what user experience contingency planning *actually* looks like.

---

4. Show the Why, Not Just the What
----------------------------------

No one cares that your feature has dark mode or integrates with Zapier.

What they care about:

* **Why this solves their actual problem**
* **Why your solution works better than duct tape and spreadsheets**
* **Why this makes them look good and hit their goals**

Don’t sing the whole opera. Hit the aria that makes them weep. And maybe, just maybe, open the budget.

---

Final Bow
---------

When disaster strikes—and it will—you have two options:

1. Freeze like a deer caught between backlog grooming and an executive Q&A.
2. Or channel your inner Bourdain: sleeves rolled up, standing in the steam of a night market, cooking something brilliant with one pot, a fish that's still twitching, and zero apologies.

Whatever you do, don’t telegraph the mistake. Don’t mutter, “*Well, that wasn’t supposed to happen.*” Sell it like it *was* the plan all along. Remember, they don’t know the script. So turn that crash into craft.

Because you don’t win demos by being flawless. You win by being unforgettable.

Start with *why*. End with *hell yes.*

Tell Me Your Tales
------------------

Your worst demo horror. Your biggest save. That time the CEO unplugged the monitor mid-pitch, and you still closed.

Give me your chaos. I’ll give it a curtain call.

---

[Leave a comment](https://deanpeters.substack.com/p/stage-fright-is-real-so-is-product-demo-regret/comments)

Thanks for reading Confessions of a Feature Factory Escapee! Subscribe for free to receive new posts and support my work.

Subscribe