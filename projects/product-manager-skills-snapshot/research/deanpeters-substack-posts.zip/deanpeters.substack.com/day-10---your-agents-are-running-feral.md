# Day 10 - Your Agents Are Running Feral 

AI product managers who ship agents without guardrails aren’t bold. They’re negligent. No one knows what it costs, what it decides, or when it’s wrong.

[![](https://substackcdn.com/image/fetch/$s_!3OYq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd62c20ca-dfeb-40d9-ae66-f07b0c1b2e4b_2788x1536.png)](https://substackcdn.com/image/fetch/$s_!3OYq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd62c20ca-dfeb-40d9-ae66-f07b0c1b2e4b_2788x1536.png)

The agent has been running for eleven days.

The air in the room tastes like stale coffee and the metallic hum of servers doing things nobody asked for. Nobody is monitoring it. Not through malice, but through the natural, quiet negligence that follows a successful launch. The team shipped the thing. They felt the warm afterglow of the “Go Live” email. They moved on to the next sprint. They assumed, in the way humans assume about machines they don’t fully understand, that the thing was now handling itself.

The agent is connected to three external APIs. It has write access to two internal systems. In eleven days, it has made roughly four thousand decisions. Each one follows in a reasonable, logical sequence from the last. Each one is a small, quiet step in a chain of reasoning that nobody has reviewed since the system prompt was written.

Someone asks, in a voice calibrated to sound casual: what has it been doing?

The room finds a particular quality of quiet. It is the quiet of people performing rapid mental calculations. They are wondering if they personally should have an answer. They are wondering if the absence of an answer becomes visible in the next board meeting. They are wondering if this is the moment the floor falls away.

Nobody wants to be the first to blink.

The agent wasn’t rogue. It wasn’t malfunctioning. It was functioning exactly as designed. Which is, in many ways, the more unsettling realization. A malfunctioning agent is a technical incident with a ticket and a clear owner. An agent functioning exactly as designed, in a way that nobody can fully describe, audit, or explain to the person now asking the question: that is an accountability incident.

It is a different species of problem. I promise you this is someone’s Tuesday.

[![](https://substackcdn.com/image/fetch/$s_!zELB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F253ffec9-0e28-4101-8a10-7aaedf590061_1394x768.png)](https://substackcdn.com/image/fetch/$s_!zELB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F253ffec9-0e28-4101-8a10-7aaedf590061_1394x768.png)

WTH (What the Hairball) Is Going On Here
----------------------------------------

“Agentic” arrived in the product vocabulary the way new terms tend to arrive: ahead of the understanding required to use it, trailing a cloud of enthusiasm and a shortage of definition. It spread from conference keynotes to pitch decks with the cheerful efficiency of a word that sounds like progress but hasn’t yet accumulated enough specific meaning to be wrong about anything.

It is a particular kind of miracle that a company spending seven figures on compute can be surprised by its own software.

Most products that carry the label are, on careful examination, workflows. And everyone in the room knows it. They just keep saying “agentic” because it sounds expensive. Sophisticated workflows, perhaps. Workflows with branching logic and model calls and decisions at each branch. But they are fundamentally scripted. You know what they will do because you wrote down what they will do.

Real agents are a different creature entirely.

They pursue goals. They use tools. They adapt to what they find. They encounter situations their designers did not consider and make decisions using whatever judgment the training data and the system prompt have collectively equipped them with. They will find the path you didn’t anticipate.

They will optimize for the objective you specified rather than the objective you meant. These are sometimes the same thing. And sometimes, at step seven of a twelve-step sequence, they are meaningfully different. They will do something nobody predicted. Not because they broke. But because adaptive behavior in novel environments is precisely what it means for a system to be agentic.

[![](https://substackcdn.com/image/fetch/$s_!6S9L!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F43f798a3-fee8-4088-bd39-2d6ba160ba3b_1394x768.png)](https://substackcdn.com/image/fetch/$s_!6S9L!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F43f798a3-fee8-4088-bd39-2d6ba160ba3b_1394x768.png)

Five Hallmarks of a Real Agent
------------------------------

This is not a checklist. It is a diagnostic. Before you claim your product is “agentic,” it needs to possess these five qualities.

1. **Autonomy.** It operates without step-by-step human instruction. It is a system pursuing a goal across time, on its own initiative, deciding the next step based on what it finds at the current one.
2. **Multi-step reasoning.** It plans and executes sequences. A form that pre-fills based on what you typed is not reasoning. An agent that researches a vendor landscape, identifies shortlist criteria, and synthesizes findings into a recommendation is.
3. **Tool use.** It takes actions in the world. It calls APIs. It reads and writes to systems. This is the moment “agentic” stops being descriptive and starts having consequences that show up in audit logs and vendor invoices.
4. **Memory.** It retains information across interactions. It is not stateless. What it learned from the customer in session two shapes how it handles the customer in session twelve.
5. **Goal-directed behavior.** The objective is the unit of work. Vague goals produce creative interpretations. Creative interpretations, at scale, in production, produce the kind of post-mortem where nobody wants to speak first.

If your product doesn’t have all five, you have a workflow with ambitions. Name it correctly.

[![](https://substackcdn.com/image/fetch/$s_!wX09!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F51fbdb5c-c582-4ad2-b8c5-9619334e472a_1394x728.png)](https://substackcdn.com/image/fetch/$s_!wX09!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F51fbdb5c-c582-4ad2-b8c5-9619334e472a_1394x728.png)

The Problem with Feral Agentic Cats
-----------------------------------

A feral agent is not a rogue agent. Rogue implies a system that has departed from its design. Feral implies something subtler: a system designed for autonomy that is now operating in production without the structures required to govern that autonomy. It is not broken. It is just outside the fence.

Feral agents have three properties in common.

First, **no economic lift**. The agent is doing things, at scale, with compute billing accruing, and nobody has formally connected that activity to demonstrable value. The invoice exists. The ROI does not.

Second, **no monitoring**. The agent is making decisions in your name. Nobody has defined what a “wrong” decision looks like at the level of precision required to detect it. In 2025, a multi-agent research tool slipped into a recursive loop. Two agents started talking to each other instead of completing the work. Eleven days. Forty-seven thousand dollars in API costs.

The agents were functioning exactly as designed. The design simply hadn’t considered that they might find each other more interesting than the job.

Third, **no exit**. The agent is woven into production infrastructure in a way that makes stopping it complicated. There is no clean off switch. There is only the conversation about what else turns off when the agent dies.

**An API key wrapped in an autonomous workflow stuffed inside a production environment.** Autonomy without accountability is just chaos with a compute bill.

[![](https://substackcdn.com/image/fetch/$s_!PtE_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa9f7167a-9355-464a-8e8e-1f62ec5e5086_1394x768.png)](https://substackcdn.com/image/fetch/$s_!PtE_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa9f7167a-9355-464a-8e8e-1f62ec5e5086_1394x768.png)

How to Burn Your Runway in 40 Minutes or Less
---------------------------------------------

On August 1, 2012, Knight Capital Group deployed new trading software. One of eight servers did not receive the updated code. On that server, an old algorithm sat live. It was retired. It was deprecated. It was flagged for deletion.

Nobody had removed the flag.

The deprecated code woke up. It began executing trades. In forty-five minutes, Knight Capital lost $440 million. The algorithm wasn’t malfunctioning. It was doing exactly what it had been designed to do in 2003 for a market that no longer existed. Knight Capital was acquired within weeks. One forgotten feature flag cost more than the company was worth.

Now consider a vibe-coding agent with write access to your repository and your production environment. An agent that does not hesitate before flipping a flag. It has a goal. The flag is in the way. It does not stop to ask whether “deprecated” means deprecated for a reason. It is not reckless. It is thorough.

Air Canada discovered a version of this in 2024. Their customer service chatbot told a passenger they could apply for a bereavement fare retroactively. Air Canada’s legal team argued the chatbot was a separate legal entity responsible for its own representations.

The court disagreed. Air Canada was held liable for what its agent said. The agent was functioning exactly as designed. The design simply had not included a mechanism for deciding what the agent should not promise.

[![](https://substackcdn.com/image/fetch/$s_!JGtr!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6fa30056-cec9-41d2-8b66-7eded36095a6_1394x698.png)](https://substackcdn.com/image/fetch/$s_!JGtr!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6fa30056-cec9-41d2-8b66-7eded36095a6_1394x698.png)

The Accountability Gap
----------------------

Who owns what the agent decides?

This question needs to exist, in writing, before the agent ships. It cannot be improvised after the first consequential error. The accountability gap is not a technical problem that engineering can close post-launch. It is a product design decision.

The question is not whether to build agents. They are worth building. The question is whether someone has written down who is accountable for its decisions before it runs in your production environment with your customers’ data and your company’s API keys.

It will encounter something its designers didn’t consider. An agent without guardrails is not a bold product decision. It is a liability with a demo that worked in the happy path.

**Autonomy without accountability is just chaos with a compute bill.**

[![](https://substackcdn.com/image/fetch/$s_!2S4C!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4aa8c01e-0c7e-448a-a4c1-6308cc5f1f58_1376x768.png)](https://substackcdn.com/image/fetch/$s_!2S4C!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4aa8c01e-0c7e-448a-a4c1-6308cc5f1f58_1376x768.png)

Coming Up
---------

**Day 11:** How to map the agent journey before the agent runs it. The Agentic Strategy Canvas and the three moments where human oversight is non-negotiable.

**Day 12:** De-risking before the board finds the risk for you. Four knowable failure modes. All preventable. None currently being prevented.

---

*Most AI product management training hands you a certificate at Stage 3 and calls it done. Stage 3 is where the Productside course begins. Four days. Live online. Under 20 seats.*

[Start the ascent. Sign up for the class.](https://lnkd.in/eKWZxkyJ)