# The Vibe-Code Deluge

Vibe-coding may feel like faster product management, but remember, the market isn’t paying for code.

[![](https://substackcdn.com/image/fetch/$s_!HDqZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F29b81a0a-e547-451e-bf31-9526777e5f44_3512x1998.png)](https://substackcdn.com/image/fetch/$s_!HDqZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F29b81a0a-e547-451e-bf31-9526777e5f44_3512x1998.png)

Before the Question
-------------------

The system is shipping.

Not in the triumphant, launch-day, champagne sense.

In the quiet, relentless, conveyor-belt sense.  
Another build slides out. Then another. Then another.

Each one functional.  
Each one plausible.  
Each one just convincing enough to avoid interrogation.

The logs are clean. The demo works. The metrics look like they belong in a presentation that will receive nods.

Somewhere in that motion, something important has been replaced.

Not broken. That would be merciful.

Replaced with something that also works.

Which is far more dangerous.

Because nothing triggers alarm when everything still compiles.  
Nothing slows down when everything still ships.  
Nothing forces a question when everything resembles progress.

And so the one question that mattered quietly evaporates.

Not answered. Not debated. Not rejected.

Simply never asked.

*Why are we building any of this?*

I. The Collision
----------------

Two numbers sit next to each other in polite disagreement.

They do not argue. They do not explain themselves.  
They simply coexist, which is somehow worse.

**Number one.**

In March 2025, Dario Amodei suggested we were months away from a world where AI writes 90 percent of code. Within a year, perhaps all of it.

By September, he confirmed that, in certain environments, this had effectively happened.

Ninety percent.

A number so large it stops feeling like a statistic and starts feeling like weather.

**Number two.**

Bain & Company, same year, looking at the same phenomenon from the less glamorous side of the building:

The savings have been unremarkable.

Not nonexistent. Not disastrous. Just unremarkable.

A 10 to 15 percent lift in productivity. Time saved that does not seem to convert into anything resembling advantage. Acceleration that fails to arrive anywhere meaningful.

These two numbers should not share a room.

And yet they do.

Like a Formula One engine idling in a suburban driveway.  
Technically impressive. Strategically confusing.

[![](https://substackcdn.com/image/fetch/$s_!VpVe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc799c87f-41b9-4eeb-98e4-3f3c91af9d57_3072x2048.png)](https://substackcdn.com/image/fetch/$s_!VpVe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc799c87f-41b9-4eeb-98e4-3f3c91af9d57_3072x2048.png)

II. The Strange Victory
-----------------------

There is a category of progress that feels indistinguishable from success, at least at first glance.

It comes with charts that slope in the correct direction.  
With demos that behave impeccably under observation.  
With the faint but intoxicating sense that something difficult has just become easy.

We have, undeniably, made code abundant.

Not in the sense that it is free of cost or consequence.  
But in the sense that it is no longer scarce.

You can produce more of it, faster, with less friction, than at any point in history.

This is an extraordinary achievement.

In much the same way that discovering how to manufacture an infinite number of bricks would be an extraordinary achievement.

Provided, of course, that you were ever constrained by a shortage of bricks.

We were not.

The difficulty was never the typing.  
It was the deciding.

We removed the friction from the most visible part of the work and assumed we had removed the difficulty from the work itself.

We solved the bottleneck.

We mistook it for the purpose.

---

III. WTH (What the Hubris) Is Going On Here
-------------------------------------------

Markets are, inconveniently, quite literal about what they reward.

They do not pay for effort. They do not pay for elegance. They have never once paid for the quiet satisfaction of a well-structured repository that ships on time and under budget.

They pay for outcomes.

For fewer problems. For clearer paths. For something that makes an annoying part of reality slightly less annoying in a way that is worth exchanging money for.

Code is simply the mechanism by which those outcomes are delivered.

It is the sheet music, not the performance.

No one leaves the concert humming the notation.

And here is where the arithmetic becomes uncomfortable: developers spend somewhere between 20 and 40 percent of their working day actually writing code. The rest is spent understanding what should be written, arguing about why it should exist, navigating what it must coexist with, and convincing other humans that any of it was a good idea in the first place.

We accelerated the smaller fraction.

We left the larger one entirely untouched, then regarded the result with some confusion when the returns failed to match the ambition.

We have mistaken the medium for the outcome.

[![](https://substackcdn.com/image/fetch/$s_!KtM2!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffed40f79-633d-42ca-a530-5d9631b49023_3072x2048.png)](https://substackcdn.com/image/fetch/$s_!KtM2!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffed40f79-633d-42ca-a530-5d9631b49023_3072x2048.png)

IV. The Disappearing Pause
--------------------------

There used to be a moment in the process that felt like an inconvenience and functioned like a safeguard.

A pause. Not a long one. Not a bureaucratic one. Just a beat, before the building began, in which someone with mild suspicion asked the obvious question out loud:

*Should we do this?*

It was rarely celebrated.

It slowed things down. It forced articulation of ideas that were more comfortable as feelings. It occasionally killed proposals that were very fond of themselves and had prepared remarks.

So, naturally, we engineered around it.

Now you can move from idea to implementation with such speed that the pause feels almost impolite. A sign of hesitation, perhaps. A lack of belief. An unnecessary drag on momentum introduced by someone who has not fully committed to the vision.

And so it disappears.

Not through a grand decision or a policy change, but through a sequence of small omissions, each one individually reasonable, until one day the pause is simply no longer part of the process.

Which is, on a purely mechanical level, impressive.

Because the pause was also the only part of the process that was attempting to determine whether the thing being built should exist at all. Whether there was a market for it. Whether the business could sustain it past the launch quarter. Whether anyone, anywhere, would find their life meaningfully improved by its presence.

We did not automate that question.

We removed it.

**We removed the only step that was protecting us from ourselves.**

> The PM’s job is to be the person who keeps asking it. Not to gatekeep. Not to form a committee about the committee. But to hold the question — does this bet make sense for the market, the margin, and the system we will still be maintaining in 18 months — in a room that has collectively decided the question is inefficient. The pause does not have to be long. It has to exist.

---

V. The Monkey Strategy
----------------------

Into that absence, a new logic quietly installs itself.

It is dressed in more respectable language, of course.

Iteration. Exploration. Learning through shipping. Rapid validation. The democratization of prototyping. And, most recently, vibe coding — a phrase that manages to sound both inevitable and slightly worrying, which is something of an achievement.

But beneath the vocabulary sits a familiar idea:

If we produce enough attempts, something valuable will eventually emerge.

Statistically, this is defensible. Given sufficient time, randomness will produce brilliance. A room full of monkeys, given enough typewriters and patience, will eventually produce Shakespeare.

**WHAT KIND OF BUSINESS STRATEGY IS THAT.**

Because businesses do not operate on geological timescales.

They operate on quarters. On budgets. On the increasingly fragile patience of customers who did not volunteer to be part of a discovery exercise and have several competitors willing to solve their problem more directly.

At Y Combinator’s 2025 cohort, a meaningful percentage of founders reported AI generating nearly all of their code. This is presented as a signal of efficiency. It may also be a signal of amplification — of whatever thinking preceded it. And if that thinking was incomplete, or optimistic in the way that early ideas often are before they encounter the market, then what has been created is not a shortcut to value.

It is a faster way to produce variations of the wrong thing.

Shipping is not solving.  
Generation is not discovery.  
Speed, absent direction, is simply motion.

Hope is not a strategy.

It is the absence of one, expressed enthusiastically.

> The PM’s job here is not to slow the monkeys down. It is to ask, before the room fills up: what does Shakespeare actually look like for this market? What problem are we solving that someone will pay to have solved? What does profitable look like — not at launch, but when the novelty has worn off and the maintenance hasn’t? Those questions are not obstacles to speed. They are the reason speed has a point.

[![](https://substackcdn.com/image/fetch/$s_!ZJKS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbf17518f-eb6c-4795-9d12-67fd44d2e0b4_3072x2048.png)](https://substackcdn.com/image/fetch/$s_!ZJKS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbf17518f-eb6c-4795-9d12-67fd44d2e0b4_3072x2048.png)

VI. The Three Gates (Still There, Still Annoying)
-------------------------------------------------

There remain, stubbornly, three conditions that determine whether a product succeeds.

* It must be valuable enough the customer will pay for it.
* It must be viable enough for us to sustain our business.
* It must be feasible enough to not go broke doing it.

We have made remarkable, genuine, not-to-be-dismissed progress on feasibility. The question of whether something can be built is now, in many cases, answered before it is fully asked. This is a legitimate achievement and it would be churlish to pretend otherwise.

The other two questions, however, have not received the memo.

Does anyone want this badly enough to change their behavior, pay for it, and keep paying for it after the initial enthusiasm subsides?

Can the business sustain this once the support tickets accumulate, the edge cases compound, and the next shiny thing arrives demanding attention and resources?

These questions are not impressed by faster code generation. They do not respond to velocity metrics. They have been asking the same things since long before the current tools existed, and they will continue asking them long after the current tools are replaced by whatever comes next.

We removed the easiest gate.

And congratulated ourselves while still standing outside the building.

**We removed the easiest gate and declared victory at the entrance.**

> The PM’s job is to stand at the other two gates. Not as a bureaucrat. As a navigator. Will the market want this badly enough to pay, switch, and stay? Can the business sustain it past the quarter where it was someone’s priority? These are not philosophical questions. They are the only questions that convert code into revenue. Everything else, however elegantly shipped, is feasibility theater.

---

VII. The Productivity Illusion and the Credit Card
--------------------------------------------------

There is something almost endearing about the way humans assess their own speed.

We feel faster, therefore we assume we are faster. The sensation of productivity and the fact of it have always been loosely related, but the gap has rarely been this well-documented.

Developers report genuine improvements when using AI coding tools. And in a narrow sense, they are correct. Certain tasks complete more quickly. Certain forms of friction are reduced. The individual experience of generating code is, by most accounts, meaningfully better than it was.

But when measured end to end, against the full arc of a change from idea to working system to maintained product, the story grows more complicated.

Outputs require verification. Verification requires understanding. Understanding requires time that the tools did not eliminate — only deferred to a later point in the process, where it costs more and interrupts more. In controlled studies, experienced developers who believed they were significantly faster were, in objective terms, slightly slower.

Not because the tools failed. Because the system around the tools did not change.

We automated the act of writing.  
We inherited the responsibility of reviewing.  
We counted only one side of the ledger.

Then came the other side.

Code that is easy to produce is, almost by definition, easy to overproduce. Structure erodes in small increments. Duplication accumulates without ceremony. Complexity compounds across releases until the system works but requires a specialist to explain it. An MIT professor described this dynamic as a new kind of credit card — you experience the benefit immediately, and the cost arrives later, with interest, and with a tone that implies you should have known better.

The numbers are not subtle: technical debt increases 30 to 41 percent after AI tool adoption. Duplicated code blocks have increased eightfold. Change failure rates are up. Production incidents are up. And nearly half of engineering time is already spent managing the residue of previous decisions.

We have not eliminated that residue.

We have made it considerably easier to generate.

[![](https://substackcdn.com/image/fetch/$s_!p3Bw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa3ec66d0-9c67-4bfc-b950-2183a33e43e6_3072x2048.png)](https://substackcdn.com/image/fetch/$s_!p3Bw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa3ec66d0-9c67-4bfc-b950-2183a33e43e6_3072x2048.png)

VIII. The Cost of Vibes
-----------------------

Prototypes, in isolation, are harmless.

They are small bets, cheap experiments, ways of learning something real before committing to something expensive. This is genuinely good practice, and it would be a mistake to argue otherwise.

The problem is not the prototype.

The problem is the aggregate.

Each experiment introduces a small shift. In user expectation. In system behavior. In the mental model of the team that will maintain it. Each shift is individually reasonable, and few are collectively tracked, because the process of tracking them feels like overhead in an environment optimized for movement.

And so the product begins to resemble a sequence of reactions rather than a coherent strategy. Code is written, deployed, reconsidered, and discarded within weeks. Security edges appear not through negligence but through accumulation. Dependencies become permanent not through design but through inertia — because no one revisited them, because the next iteration was already underway.

Nothing fails dramatically enough to force a reckoning.  
Everything degrades gradually enough to continue.

Every prototype leaves a trace in the system it was testing.

Very few of those traces are accounted for.

**Every prototype changes the system. Most are never accounted for.**

> The PM’s job is to read the bill before it arrives. Not to prevent prototyping — prototyping is exactly how you find out what is worth building. But to track the residue. To ask what this prototype made permanent, what expectation it set, what dependency it introduced into a system someone will still be maintaining long after this sprint is forgotten. The vibe coder ships the idea. The PM figures out what the idea cost the system. One of those jobs compounds silently if nobody does it.

---

IX. The New Competitive Advantage
---------------------------------

When a resource becomes abundant, its value shifts from production to selection.

This is not a new observation. It applies to every input that has ever moved from scarce to plentiful — and the pattern is consistent enough to be treated as a rule rather than a tendency.

Code has crossed that threshold.

The ability to produce it is no longer rare. The tools are available, the friction is low, and the output is, in most cases, functional enough to be plausible. What remains scarce — genuinely, increasingly, measurably scarce — is the judgment about which code should exist.

This creates an inversion that most organizations have not yet fully registered.

The teams that win will not be those who produce the most. They will be those who discard the most, earliest, before the system absorbs the cost and before the user is trained to expect something that was never meant to be permanent.

In an environment saturated with output, restraint begins to look less like caution and more like precision. The ability to say “not this, not yet, not without evidence that it matters” is becoming a more defensible competitive position than the ability to ship quickly — because shipping quickly is, at this point, table stakes.

In a world of infinite output, judgment becomes the scarce resource.

---

X. A Brief Moment of Clarity
----------------------------

At some point, it is worth pausing long enough to ask a slightly uncomfortable question.

What, exactly, are we doing.

We have built a system that dramatically reduces the cost of building. We have used that system, in many cases, to accelerate the avoidance of the harder question of what to build. We are producing more artifacts than at any point in history, and struggling to produce proportionate outcomes.

Volume has increased.  
Value has not kept pace.

Which suggests, rather directly, that the constraint was never where we thought it was.

The engineers are not failing. The tools are performing as designed. The models are generating what they were asked to generate.

The gap — the compounding, expensive, difficult-to-reverse gap — is the absence of someone asking, with some regularity and some authority, whether any of this was worth asking for in the first place.

That has always been a product management question.

It remains one now.

[![](https://substackcdn.com/image/fetch/$s_!n0wV!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc11649d7-f0a0-4f66-b6bd-bdb0036d694c_3072x2048.png)](https://substackcdn.com/image/fetch/$s_!n0wV!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc11649d7-f0a0-4f66-b6bd-bdb0036d694c_3072x2048.png)

XI. The Quiet Conclusion
------------------------

What does it profit a team to generate all the code in the world…

and lose the ability to build something anyone needs?

Or, more precisely, to lose the ability to tell the difference.

There is no model that answers that question on your behalf. There is only a decision, made earlier than most teams are currently making it — before the demo, before the sprint, before the prototype that will quietly reshape the system it was only meant to test.

The decision is simple in form and demanding in practice:

Does this solve a real problem for a real person in a way the business can actually sustain?

That was always the work.

The tools have changed considerably.

The question has not moved at all.

Code is abundant.

Judgment is not.