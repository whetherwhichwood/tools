# If You Give Sales a Screenshot

[![](https://substackcdn.com/image/fetch/$s_!lpYB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8b860911-f7d3-42c6-8e3d-f35d36d3d63d_1200x800.png)](https://substackcdn.com/image/fetch/$s_!lpYB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8b860911-f7d3-42c6-8e3d-f35d36d3d63d_1200x800.png)

**It all began with one innocent screenshot—before the demo decks, the deadline slips, and the midnight Slack pings.** I’m talking about the product manager’s bedtime story I wrote, based on the classic children’s book ‘*[If You Give a Mouse a Cookie](https://amzn.to/4ioFVPi)’* by Laura Numeroff—because its storyline mirrors our daily reality:

* one small request snowballs into a whirlwind of promises, pivots, and PowerPoint.

Only, in with my parody, the mouse wears a suit, the cookie is a feature, and the product manager? Well… they just wanted to ship something simple.

---

0:00

-1:32

Audio playback is not supported on your browser. Please upgrade.

---

If you give Sales a screenshot,  
they’ll ask you for a tale—  
a tale so bright and vivid,  
that their pitches will not fail.

You will give them something glowing,  
a demo, quick and neat.  
They will say, “It needs to function  
all night and not miss a beat.”

Then when you show the clicking,  
they’ll track your every move.  
"Does it go left to rightwards?  
The flow should surely groove."

They’ll ask to film the demo,  
to share with all their crew.  
You’ll send it off at daybreak—  
they’ll ping all afternoon.

“Can it do just one more thing?”  
they’ll ask with shining eyes.  
“Can it float up through cloud-land?”  
as they sell with grander lies.

They’ll book a giant meeting  
and print your lovely deck.  
Then dig into your backlog,  
and shout, “Where is the spec?”

They’ll ask for a test sandbox,  
with data that looks real.  
They’ll ask you for the roadmap,  
and when they can close a deal.

They’ll want a list of features,  
with milestones, big and small.  
They’ll tape it to the whiteboard  
and wave it down the hall.

And if they glimpse your scrum board,  
with features bold and bright,  
They will ask you for a screenshot  
to share it throughout the night.

And if you give that screenshot...  
they’ll ask you for a tale—  
a tale so bright and vivid,  
that their pitches will not fail.

---

[![](https://substackcdn.com/image/fetch/$s_!bn2c!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F20ae4edd-8189-4385-b06c-c09c71a5906c_1200x800.png)](https://substackcdn.com/image/fetch/$s_!bn2c!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F20ae4edd-8189-4385-b06c-c09c71a5906c_1200x800.png)

I’ve got two more in this ‘Broken Bedtime Stories for Product Managers’ series, inspired by Laura Numeroff’s delightfully chaotic trilogy—each reimagined through the weary eyes of a product manager. Keep an eye out for ‘*[If You Give Your Manager an MVP](https://deanpeters.substack.com/p/if-you-give-a-manager-an-mvp)’* and ‘*[If You Pitch a Programmer a Problem](https://deanpeters.substack.com/p/if-you-pitch-a-programmer-a-problem)*,’ plus a few bonus tales from the land of backlog dreams and stakeholder schemes. Pajamas optional, but highly recommended.

---

Thanks for reading Confessions of a Feature Factory Escapee! Subscribe for free to receive new posts and support my work.

Subscribe