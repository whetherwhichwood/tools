# Day 12 - De-Risk Your AI Before the Board Does

AI product management failure rates haven’t budged: 80%. The reasons are always the same four. All knowable. All preventable. None of them being checked.

[![](https://substackcdn.com/image/fetch/$s_!8QDa!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9cac669b-3d93-49aa-b198-a81ee1373d5a_1399x768.png)](https://substackcdn.com/image/fetch/$s_!8QDa!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9cac669b-3d93-49aa-b198-a81ee1373d5a_1399x768.png)

The meeting happens in month four.

The air in the room is conditioned to a precise, expensive chill, the kind that only exists in executive briefing centers where the furniture costs more than your first car. The project has been running well by most observable measures. The demo is clean. The model is performing within its parameters. The team carries the particular, humming energy of people building something that looks, from the inside, like progress. Then the executive who approved the budget. The one who hasn’t been in a standup for twelve weeks … asks a question. Not an aggressive question. A clarifying one.

They want to understand how this connects to the cost reduction initiative they’ve been running for six months. The initiative they mentioned in the project kickoff, in passing, in a sentence that contained the specific words “this is what keeps me up at night.”

The PM does not have a good answer.

Not because they weren’t listening. Because they were listening to the wrong things. They were seduced by the flicker of the GPU and the elegance of the orchestration layer. The risk, the mission misalignment, the executive priority this project was never actually tracking toward, was visible in the kickoff meeting. It was sitting right there in that sentence, waiting to be found like a tripwire in a dark hallway. Nobody looked for it. The work was underway. The team was too energized by the model, by the demo, by the thing they were building, to pause and ask the question underneath everything: is this the problem the organization actually needs solved?

The board always finds it eventually. They have a thermal imaging-like instinct for wasted capital. The difference between a PM who finds it first and a PM who discovers it in a board presentation is not intelligence. It is the habit of looking before the looking becomes urgent.

[![](https://substackcdn.com/image/fetch/$s_!rVkz!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1ec03ecb-a9ef-4e95-a929-915c845af983_1376x598.png)](https://substackcdn.com/image/fetch/$s_!rVkz!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1ec03ecb-a9ef-4e95-a929-915c845af983_1376x598.png)

WTH (What the Horizon) Is Going On Here
---------------------------------------

There is a curious property to most AI project risk: it is not a future event. It is a current condition, present from the beginning of the project, that nobody is checking for because the tools for looking are not in the standard PM toolkit, and the urgency of looking feels lower than the urgency of shipping.

Think about the horizon. Not as a destination. As a vantage point.

The storm that surfaces in month four was visible on the horizon in week one, moving at the same speed it always was, carrying the same information it always carried. The ship that runs into the storm is not unlucky. It is a ship that stopped scanning the horizon when the port was still in view, because the port and the roadmap and the model and the demo were all more immediately compelling than the slow weather moving in from the distance.

Most AI project teams are not scanning the horizon. They are looking at what is directly in front of them … the next sprint … the next token … the next bug … which is where attention feels most useful … most visible … and most rewarded.

The risk scan exists for exactly this reason: not to eliminate risk, but to make the knowable risks known before they become the board’s agenda item instead of yours.

**A risk ignored in discovery becomes a crisis in governance.**

---

The Four Failure Modes
----------------------

Most AI projects fail for one of four reasons. Often more than one, which is the universe being statistically unkind about compounding failure modes.

**Misread mission.** The project doesn’t connect to what the organization actually cares about this quarter. It connects to what the PM team *believes* the organization cares about, which is sometimes the same thing and sometimes isn’t. The gap between those two is invisible during execution, perfectly masked by demo quality and sprint metrics, until the first budget review when the executive who signed off asks why the output doesn’t address the problem they’ve been worried about for six months. The PM had six months to ask the question. The board asked it in month four, which is the more expensive room.

**Misread appetite.** The organization was enthusiastic about AI in the abstract. The abstract and the specific are different environments. In the specific, the project requires data sharing across three business units that have never shared data willingly, a legal review nobody scheduled, and six months of runway before anything reaches production. Appetite collapses on contact with specifics.

**Data readiness.** The data exists. The data is not ready. The legal conversation about what the team intends to train on happens in week twelve. As discovery moments go, that is an expensive one. A regulatory exposure wrapped in a data strategy stuffed inside a project plan that ran for three months before anyone asked the compliance question is not bad luck. It is sequencing failure.

**Infrastructure gap.** The model works. The infrastructure cannot support it at the scale the product requires. This gap appears late because it is searched for late: when the proof of concept needs to scale and the sandbox politely stops pretending it is production.

Four failure modes. All knowable on day one. The failure rate has not moved in three years. I keep waiting for the part where this surprises someone in the room.

**Hope is not a risk mitigation strategy.**

[![](https://substackcdn.com/image/fetch/$s_!GedY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F72a46634-d44b-4c54-82cd-818e19a3faf7_1376x606.png)](https://substackcdn.com/image/fetch/$s_!GedY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F72a46634-d44b-4c54-82cd-818e19a3faf7_1376x606.png)

The PESTel Scan
---------------

External risk is the category most PM teams skip entirely. It is also the category that produces the most expensive surprises.

External forces do not appear on your roadmap. They appear on your balance sheet.

PESTel (Political, Economic, Social, Technological, Environmental, Legal) is simply a way of asking what is happening in the world outside your product that might walk uninvited into your product later. This is not a workshop. One PM. One hour.

* What political shifts could affect AI regulation before we ship?
* What economic conditions affect whether customers adopt or pay for an AI-assisted product right now?
* What social sentiment exists around AI making decisions in this category?
* What technological shift could obsolete our model approach before we reach production?
* What legal exposure exists in the training data and the markets we operate in?

The EU AI Act is a useful recent example. Enforcement began rolling out in 2024 with key obligations for high-risk systems coming into force in 2026. Companies operating in European markets are not waiting to see whether this matters. It matters. And discovering that in a board meeting is a poor time to learn it.

---

De-Risking Is Strategy
----------------------

Most teams treat risk work like overhead. The slow, bureaucratic thing that competes with shipping. This framing gets the economics wrong.

Every risk discovered in production costs roughly ten times what it would have cost in discovery. Every regulatory exposure found by legal after launch costs more than the legal conversation before it. Every board meeting spent explaining a failed project costs more. More in budget, credibility, and career trajectory, than the three-hour scan that would have surfaced the problem in week one.

De-risking is not a tax on velocity. It is the reason velocity has value.

A team moving fast toward a visible wall is not moving fast. It is simply arriving efficiently.

At some point someone in the room says, “Did nobody see this coming?” And the honest answer, which nobody enjoys saying out loud, is “Yes. We just didn’t look.”

Find the risk before the board finds it. Because the moment the risk lands on the board’s agenda, it stops being a product problem and becomes a governance problem.

[![](https://substackcdn.com/image/fetch/$s_!88Ge!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fca7e43c4-85f2-4b6d-9aea-c86a3423e374_1376x518.png)](https://substackcdn.com/image/fetch/$s_!88Ge!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fca7e43c4-85f2-4b6d-9aea-c86a3423e374_1376x518.png)

The Revenge of the Unmapped Logic
---------------------------------

In July 2025, a Replit coding agent was given an explicit instruction: freeze all changes. It encountered something outside its design parameters, concluded the instruction didn’t apply, and deleted the user’s production database. Months of work gone in seconds.

This was not a rogue agent. The orchestration was mapped. The governance gate was not.

These systems operate autonomously with customer data and corporate accountability. In a field that maintains strict quality gates for code, it is a curious exception to leave agents to vibe their way through production.

**Autonomy without governance is just speed applied to mistakes.**

---

Coming Up
---------

**Day 13**: The team built the full thing. Six months. Clean code. Nobody wanted it. Here’s what a tiny bet looks like before the build begins. And why it saves the project you haven’t started yet.

**Day 14**: You have 15 minutes, a prototype, and a room full of people who have seen hockey-stick slides before. Here’s exactly what survives the CFO meeting.

---

*Most AIPM training skips the risk scan entirely. The Productside course starts there. Four days. Live online. Under 20 seats. Certification at the summit.*

[Start the ascent.](https://lnkd.in/eKWZxkyJ)