# You've Entered the Automation Zone

[![](https://substackcdn.com/image/fetch/$s_!YQkk!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5fb16c63-c99d-4e7d-8d43-161b024bcf35_2816x2068.png)](https://substackcdn.com/image/fetch/$s_!YQkk!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5fb16c63-c99d-4e7d-8d43-161b024bcf35_2816x2068.png)

AI Augmented Work - the promise vs. the reality

**A knowledge worker.**  
Average height. Average ambition.  
Armed with a college degree and a belief that hard work equals security.

He’s been promised augmentation.  
He’s about to receive something else entirely.

The executives smile and hand him a book.  
The cover reads: **“To Serve Humans.”**

He doesn’t realize it’s a cookbook until it’s too late.

The Promise vs. The Plan
------------------------

**The Promise:**  
Assist → Accelerate → Augment

**The Plan:**  
Understudy → Usurp → Unemploy

Picture, if you will, a C-suite executive.  
Smooth talking. PowerPoint fluent.  
He speaks in transformations and innovations.

He says: *“AI will make our people more productive.”*

What he means: *“AI will make our people more **optional**.”*

The robots arrive as helpers.  
Assistants with clipboards.  
Watching. Learning. Taking notes.

Then one day, without ceremony, without warning, the assistant becomes the lead.

The human watches from the wings.  
Then the wings become the parking lot.  
Then the parking lot becomes unemployment.

The Excuse They’ve Been Waiting For
-----------------------------------

AI didn’t decide this.  
The board of directors did.

AI was just the excuse they’ve been waiting for since the first consultant whispered “*efficiency gains*” into their quarterly earnings call.

No guilt.  
No conscience.  
Just: *“The market is evolving. We’re optimizing for the future.”*

**Translation:** “*We’re cutting costs and calling it strategy.*”

Every transformation deck sells empowerment.  
Every CFO spreadsheet plans for headcount reduction.

This isn’t about technology making better decisions.  
This is about spreadsheet-brained leaders blaming a chatbot for layoffs they wanted to execute anyway.

AI makes a convenient villain.  
No severance guilt.  
No uncomfortable town halls.  
Just progress. Just innovation. Just the future.

The understudy isn’t replacing you because it’s smarter.  
**It’s replacing you because it’s cheaper.**

And some knucklehead in a corner office gets to pretend that was a long-game strategic decision instead of the short-term quarterly earnings theater it is.

HAL’s Revenge
-------------

Here’s the beautiful irony:

The same executives automating knowledge workers out of existence genuinely believe **they’re** immune.

They think strategic decision-making is sacred. Human. Irreplaceable.

*“I’m sorry Dave, but your position has been eliminated.”*

Turns out, a lot of “*leadership*” is just expensive pattern recognition.  
And the board knows it.

The executive automates the workers.  
The board automates the executive.

Nobody’s safe from their own logic.

The Plot Twist
--------------

There’s a twist in our tale.

One morning, that same executive walks into his corner office.  
The building is quiet.  
Everyone’s gone.  
Just him and the machines.

He smiles.  
Peak efficiency achieved.

Then he gets the email:

“The board has determined that executive decision-making can also be automated. Your services are no longer required. Effective immediately.”

He looks around.  
The robots don’t blink.  
They just... continue working.

*You unlock this door with the key of innovation.*  
*Beyond it is another dimension.*  
*A dimension of short-term gains.*  
*A dimension where humans optimize themselves into obsolescence.*  
*You’re moving into a land of quarterly earnings and headcount reduction.*

*You’ve just crossed over into...*

**The Automation Zone.**
------------------------

[![](https://substackcdn.com/image/fetch/$s_!kXWy!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7e855df1-ff9c-4703-8c77-9633132a68e8_2816x1536.png)](https://substackcdn.com/image/fetch/$s_!kXWy!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7e855df1-ff9c-4703-8c77-9633132a68e8_2816x1536.png)

When it comes to the AI blame game … nobody is immune …

You thought this was fiction.
-----------------------------

**It’s not.**

Let’s run the receipts.

The Executives Are Saying It Out Loud Now
-----------------------------------------

**[Mustafa Suleyman](https://fortune.com/2026/02/13/when-will-ai-kill-white-collar-office-jobs-18-months-microsoft-mustafa-suleyman/)**, CEO of Microsoft AI, just told Fortune that most white-collar tasks (law, accounting, project management, marketing) will be **“fully automated” within 12 to 18 months**.

Not “enhanced.”  
Not “augmented.”  
**Automated.**

**[Marc Benioff](https://www.latimes.com/business/story/2025-09-02/salesforce-ceo-marc-benioff-says-he-cut-4-000-support-roles-because-of-ai)**, CEO of Salesforce, already cut **4,000 support roles** (nearly half the department) because “AI agents are doing work that used to require humans.”

**[Dario Amodei](https://www.cnbc.com/2026/01/27/dario-amodei-warns-ai-cause-unusually-painful-disruption-jobs.html)**, CEO of Anthropic, warned that AI may eliminate **around 50% of entry-level office jobs within five years**, suggesting unemployment could rise to 10-20%. He accused companies and governments of “sugarcoating” the risks.

At least Dario’s being honest.

**[Amazon’s Andy Jassy](https://www.cnbc.com/2025/12/21/ai-job-cuts-amazon-microsoft-and-more-cite-ai-for-2025-layoffs.html)** told employees AI would mean “fewer individuals performing some current roles.”

Translation: “We’re hiring AI engineers and firing everyone else.”

According to [Challenger, Gray & Christmas](https://www.cnbc.com/2025/12/21/ai-job-cuts-amazon-microsoft-and-more-cite-ai-for-2025-layoffs.html), nearly **55,000 U.S. layoffs in 2025** were explicitly attributed to AI in company disclosures.

The Layoff Scoreboard
---------------------

Here’s a partial list of companies that have [explicitly cited AI](https://programs.com/resources/ai-layoffs/) as a reason for workforce reductions:

> • **Accenture:** ~11,000 roles
>
> • **HP:** 4,000-6,000 roles
>
> • **SAP:** Several thousand roles
>
> • **Chegg:** ~45% of staff
>
> • **Pinterest:** ~15% of staff
>
> • **Dow:** ~4,500 jobs
>
> • **Indeed/Glassdoor:** ~1,300 roles
>
> • **CrowdStrike:** ~500 roles
>
> • **Workday:** ~1,750 employees

All restructuring.  
All emphasizing “AI-driven efficiency.”  
All reducing headcount.

This isn’t a few bad actors.  
This is the playbook.

The Quiet Part They’re Not Saying
---------------------------------

Here’s what nobody’s admitting:

**Most of these layoffs have nothing to do with AI capability and everything to do with AI cover.**

AI didn’t suddenly get good enough to replace 4,000 Salesforce support reps.  
Benioff just wanted to cut costs and AI gave him a socially acceptable excuse.

AI didn’t decide Accenture needed 11,000 fewer consultants.  
The CFO decided that, and AI was the narrative wrapper.

This is the same cost-cutting playbook executives have been running since the 1980s.  
The only thing that’s changed is the villain they’re blaming.

> • 1990s: “Globalization made us do it”
>
> • 2000s: “Financial crisis forced our hand”
>
> • 2010s: “Digital transformation required it”
>
> • 2020s: “AI is automating roles”

Same game. New excuse.

W.O.P.R. Figured It Out
-----------------------

Remember the 1983 movie classic ‘War Games’?

W.O.P.R. runs millions of simulations of nuclear war.  
Every scenario ends in mutual destruction.  
Conclusion: **“The only winning move is not to play.”**

Executives are running the same simulation with knowledge work.

“*What if we replace humans with AI?*”  
Answer: “*Short-term cost savings, long-term institutional collapse*.”

But they’re going to play anyway.

Because they’re not optimizing for organizational health.  
They’re optimizing for **this quarter’s earnings call**.

They’ll extract value, cash out stock options, and leave the wreckage to the next leadership team.

Classic “I’ll be gone, you’ll be gone” thinking.

Except this time, the AI they’re building might decide **they’re** redundant too.

[![](https://substackcdn.com/image/fetch/$s_!FmWe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F31bbef93-4112-4c4e-ae3f-48187aea8de9_2816x1536.png)](https://substackcdn.com/image/fetch/$s_!FmWe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F31bbef93-4112-4c4e-ae3f-48187aea8de9_2816x1536.png)

Rebuild, Share, Help, and Amplify with AI

What You Can Actually Do About This
-----------------------------------

Enough dystopian doom and gloom. Let’s talk action.

If you’re a **knowledge worker**, here’s your playbook:

### 1. **Document your judgment, not just your tasks**

AI can replicate tasks.  
AI struggles with nuanced judgment calls.

Start keeping a decision journal:

> • What tradeoffs did you navigate?
>
> • What context did you consider that wasn’t in the data?
>
> • What risks did you weigh that an algorithm would miss?

This becomes your armor when some knucklehead says “*AI can do your job.*”  
No, it can’t. It can do your **tasks**. It can’t replicate your **judgment**.

### 2. **Build proof that you’re irreplaceable**

Don’t just execute. Narrate.

Every project, document:

> • The problem you solved that wasn’t in the brief
>
> • The disaster you prevented that nobody saw coming
>
> • The human relationships that unlocked the outcome

Make it impossible for leadership to see “*automatable tasks*.”  
Make them see “institutional knowledge engine.”

### 3. **Become the AI translator**

Learn enough about AI to:

> • Explain what it can and can’t do
>
> • Identify where it’s being misapplied
>
> • Call out AI theater when you see it

Position yourself as the person who keeps leadership from making expensive AI mistakes.

That’s job security.

### 4. **Rebuild Professional Communities**

COVID lockdown madness destroyed the professional networks that used to make knowledge workers thrive.

Rebuild them:

1. **Build networks across companies**  
   Share knowledge, share tools, share wins.
2. **Share success stories of how AI is actually augmenting us**  
   Make success stories louder than fear stories.  
   Show the world what this technology can actually DO when you’re not using it to fire people.
3. **Rally around those who have been laid off and help them**  
   Introduce them to your network. Connect them to opportunities.
4. **Build AI tools that amplify the best in all of us**  
   Create templates. Share workflows. Open-source what works.

The stronger your community, the less power any single short-sighted executive has over your career.

---

If You’re a Leader (Who Actually Gives a Damn)
----------------------------------------------

If you’re not just chasing quarterly numbers, here’s your counter-playbook:

### 1. **Declare your AI philosophy publicly**

Put it on the website. Put it in the employee handbook.

“*We use AI to amplify human judgment, not replace it. If we automate a task, we redeploy the human to higher-value work. If we can’t redeploy them, we retrain them.*”

Then **stick to it.**

### 2. **Tie executive comp to human outcomes, not just efficiency**

Stop rewarding headcount reduction.  
Start rewarding:

> • Skill development of existing staff  
> *(I can help with that)*
>
> • Internal mobility and redeployment
>
> • Employee retention in AI-adjacent roles

What gets measured gets managed.

### 3. **Build the alternate future**

AI doesn’t have to mean fewer humans.  
It can mean:

> • Humans doing more creative work
>
> • Humans solving harder problems
>
> • Humans working fewer hours for the same output

But that requires **choosing** that future.

Most executives won’t. They’ll choose the cheap path.

You could be different.

That company will win the talent war.  
That company will build institutional knowledge AI can’t replicate.  
That company will still exist in 10 years.

The others? Case studies in how to optimize yourself into irrelevance.

The Only Winning Move
---------------------

W.O.P.R. was right.

In the game of “automate humans out of existence,” **the only winning move is not to play.**

Not because AI is bad.  
Not because automation is wrong.

**Because AI is a gift.**

It’s the most powerful creative tool we’ve been handed in generations.

And these spreadsheet-brained knuckleheads are using it to cut costs.

They’re taking something that could amplify human genius and turning it into a layoff excuse.

**That’s the crime.**

Not AI itself.  
The executives weaponizing it.

When you optimize purely for cost reduction, you get:

> • Hollowed-out institutions
>
> • Collapse of institutional knowledge
>
> • Nobody left who understands how anything works

You end up in The Automation Zone.

*A dimension where efficiency became the enemy of resilience.*  
*Where short-term thinking destroyed long-term value.*  
*Where leaders took a gift and turned it into a weapon.*  
*And called it progress.*

[![](https://substackcdn.com/image/fetch/$s_!6oUY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb69ac5b5-4f20-4153-9d71-c74e29437aeb_2816x1536.png)](https://substackcdn.com/image/fetch/$s_!6oUY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb69ac5b5-4f20-4153-9d71-c74e29437aeb_2816x1536.png)

You MUST choose … so choose wisely.

The Choice
----------

**Option A:** Let executives turn this gift into a cost-cutting weapon. Watch them waste the most transformative technology of our lifetime on quarterly earnings theater.

**Option B:** Build what AI was meant to be. Prove it amplifies. Show the world what happens when you use it to make humans **more powerful**, not more optional.

The short-sighted executives have chosen their path.

They think they’ll win.

They won’t.

But you don’t have to lose with them.

Document your judgment.  
Prove your value.  
Share what works.  
Build communities that make everyone stronger.  
Show them AI + humans beats AI alone.

**Build tools that amplify the best in all of us.**

That future exists.  
But only if you build it.

*End transmission.*

---

**Design for Amplify.**  
**Not Unemploy.**

Nobody’s safe from short-term thinking.

Not even the executives who think they are.