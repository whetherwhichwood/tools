# How to write Guided Generation Prompts

Build AI prompts like you build products: with roles, rules, and reusable scaffolding. This guide shows you how to do it without losing your soul … or at least avoiding outputs that read like Siri after she’s been nipping at the cooking sherry.

[![Images of Bobble-head Dean and Sims 3D Dean](https://substackcdn.com/image/fetch/$s_!Q6By!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbb7e6716-0a7f-4867-af88-354acdf6e7a1_2024x1714.png "Images of Bobble-head Dean and Sims 3D Dean")](https://substackcdn.com/image/fetch/$s_!Q6By!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbb7e6716-0a7f-4867-af88-354acdf6e7a1_2024x1714.png)

Behold: Bobble-head Dean and Sims 3D Dean.

### 🔎 WTF Am I Looking At?

**The banner?** Bobblehead-Me. Sims-Me.

**The method?** Prompts that build things, step by step.

**The point?** This isn’t cosplay—it’s a workflow that works on damn near anything.

**The process?** Something I'm calling **Guided Generation Prompting**.

**The prompts?** They're in the [/prompt-generators](https://github.com/deanpeters/product-manager-prompts/tree/main/prompt-generators) and [/storytelling](https://github.com/deanpeters/product-manager-prompts/tree/main/storytelling) directories of my GitHub repo.

---

🧰 WTF Is Guided Generation Prompting?
-------------------------------------

A **Guided Generation Prompt** is a structured prompt that turns an AI assistant into:

* A collaborator with contextual memory
* A facilitator with a structured flow
* A content creator that actually finishes things

It’s not just for text. You can use the same flow to generate slides, dashboards, visuals, roadmaps, and yes—even PRDs from old screenshots.

---

🧠 Why You Should Give a Fig
---------------------------

These prompts give you leverage. Step-by-step, they help you generate:

* 🧩 GTM messaging you actually want to share
* 📬 Launch emails that don’t read like hostage notes
* 📈 TAM/SAM/SOM searches that don't suck
* 🧠 Reverse Engineer PRDs from ancient artifacts
* 🎯 Visual storyboards that sell your product’s “why”
* 🧾 Forms that adapt to the user’s context
* 🧑‍🏫 Workshop guides, checklists, and rituals
* 🧱 And yes—visual builds like Sims characters, dashboard mockups, and custom action figures

If it’s repeatable and generative, this structure makes it better.

---

### 🪝 Step 1: Anchor with an Artifact

> Start with: A screenshot. A scrap. A sketch. A canvas. A cursed PowerPoint.

Examples:

* Glorious headshot
* Roadmap snapshot
* Biz Case template
* TAM/SAM/SOM structure
* AP Style Press release
* Screenshot of a Miro board with rage scribbles

You’re saying:

> *“Reverse-engineer this. Make it useful.”*

---

### 🧑‍🎓 Step 2: Assign the AI a Role and a Mission

> Give the AI a job. Give it a user to help.

**Role examples:**

* “Gemini you are a roadmap facilitator.”
* “Claude you write product update haikus.”
* “ChatGPT you generate visuals like a Sims stylist.”

**User scenarios:**

* “Helping a PM prep for a board meeting.”
* “Helping a new hire understand our launch plan.”
* “Helping me make sense of this mess.”

Skip this and you’ll get boilerplate nonsense. Or worse—corporate word salad. Ground the AI with a mission.

---

### 🔀 Step 3: Ask One Smart Question at a Time

> One question at a time. Like a good wizard or a bad therapist.

The AI doesn’t need everything at once. It needs:

* A clear sequence
* The ability to use memory or prior context
* Examples that evolve with each new answer

> **IMPORTANT! Guide the user. Don’t overwhelm them.**

What this looks like:

1. Ask for the artifact or problem
2. Suggest a few interpretations
3. Offer examples drawn from context (uploaded file, memory, or structure)
4. Confirm before output

**Bonus:** Instruct the AI Assistant to ***adapt its examples*** based on each answer.   
That’s what makes it feel collaborative, as each question is asked (one at a time).

---

### ✍️ Step 4: Define the Output Format with Tildes

> Backticks scream code. Tildes whisper clarity.

Model the output structure in markdown, like this:

```
~~~markdown
# Slide Title
## Subtitle

- Pain Point
- Big Idea
- Suggested Action
~~~
```

This signals polish. The AI mirrors what you show.

Pro tip: include a real example in your prompt.   
The more concrete your model, the smarter the mimic.

---

### 🎨 Step 5: Get Weirdly Specific About Style

> Treat the rendering instructions like you would a good Figma handoff.

Include:

* Layout & spacing
* Labels & ordering
* Tone & voice
* Emojis: yay or nay
* Visual styling (*e.g. “Kelly green gradient, soft shadow”*)

Be specific. The AI will fill in the gaps—with defaults you may not like.

> Don’t just tell it what—tell it how.

* Want emojis? Say so *(or be like me, say hell no!).*
* Want bold titles, 2-line blurbs, in the style of P.G. Wodehouse.
* Kelly green gradient backgrounds with soft shadows?

Spell it out. The Assistant ain’t a mind reader!

---

### 🚀 Step 6: Nudge the Next Move

After the output, *don’t stop*.

Prompt the user to repurpose it:

> “Want this turned into a workshop slide, executive memo, or onboarding doc?”

Momentum matters. Push the next iteration.

If you start getting a '*ClippyGPT*' vibe—like it's chirping useless suggestions or defaulting to corporate mush—go back to Step 5.

[![The nearly-famous PM Action Figure Dean](https://substackcdn.com/image/fetch/$s_!zvBY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6589c293-d6b9-4253-9e54-b574f35aae56_1940x2940.png "The nearly-famous PM Action Figure Dean")](https://substackcdn.com/image/fetch/$s_!zvBY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6589c293-d6b9-4253-9e54-b574f35aae56_1940x2940.png)

The nearly-famous PM Action Figure Dean

---

### 🧽 What Are These, Again?

Not “*prompt templates.*”

Not “*question trees.*”

And if you say “*prompt journeys*” I will throw a Miro board at you.

#### These are '**Guided Generation Prompts'**

* They have a role
* They follow a flow
* They are context-aware
* They deliver structure

Use them. Remix them. Teach them.

---

### 🔧 Starter Prompt Template

Give this to ChatGPT, Claude, Gemini, or drop each step into LangFlow:

```
# Generator – [Your Prompt Title]

## Context:
Hello AI. You are a [role – e.g., strategic brief builder, TAM estimator, ritual designer].

You are helping a user [goal – e.g., write a 1-pager, generate a story map, summarize feedback].

Ask the following questions one at a time, adapting your examples using uploaded artifacts or past responses.

---

## Questions:
1. What are we building?
2. What artifact or inspiration are we starting from?
3. Who’s the audience?
4. What decision or action are you hoping to spark?
5. Any layout, tone, or visual preferences?

---

## Output Format:
~~~
# [Output Title]

- Insight 1
- Supporting Point
- Action Step or Summary

[Include layout, emoji, and formatting details as needed.]
~~~

---

## Final Step:
“Would you like this as a one-pager, a PDF, or a slide?”
```

OR … copy one of my Guided Generation Prompts from my [Github Repo](https://github.com/deanpeters/product-manager-prompts/blob/main/storytelling/Generator%20-%206%20Scene%20Visual%20Product%20Storyboard%20Narrative.md?plain=1) and do this:

```
{CONTEXT}

... insert a copy and paste of the raw code of one of my prompts ...

{QUESTION}
Please refactor this gloriously written guided generation prompt by Dean Peters for writing storyboards and have it generate PRD prompt based on the ISO 29148 StRS and BRS requirements standards.
```

---

### 🧪 Bonus Challenge: Promptception

Take that **starter template** above. Now hand it to ChatGPT.

Say:

> “Act as a prompt design assistant. Turn this meta-template into a Guided Generation Prompt by asking me smart questions.”

Now answer them. Boom. You just built your own scaffold. Welcome to recursive productivity.

Also… make it visual. Or a badge. Or a role card. Your choice.

---

### 🧠 What About Agentic AI?

Here's the fun part: these prompts aren’t just chat-ready. When broken into separate steps, they *thrive* in agentic AI tools like these:

* 🧠 LangFlow
* 🪄 Dust
* 🧩 Tiledesk
* 🧰 Your no-code Frankensoft agent running in Replit

Whether you’re chaining agents, building workflows, or prototyping decisions—these prompts flex.

They’re IKEA instructions for AI. Just with less existential dread and way fewer leftover parts.

---

### The Code

I’ve put together a free, open-source library of AI prompts specifically for product managers. Built this for PMs who are tired of AI giving them vibes instead of value.

* A collection of prompts to help with real product work: interviews, roadmaps, story writing, market scans, and more
* Designed for ChatGPT, Claude, Gemini—whichever AI intern you're training this week
* Includes a prompting style guide to keep things useful (and a little less weird)

Not just for speeding up tasks—it's about thinking better, not just faster for PMs trying to do the job, not just look busy.

* <https://github.com/deanpeters/product-manager-prompts>

You'll find examples of the Guided Generation prompts in both the [/storytelling](https://github.com/deanpeters/product-manager-prompts/tree/main/storytelling) and [/prompt-generators](https://github.com/deanpeters/product-manager-prompts/tree/main/prompt-generators) directories.

---

### TL;DR

Stop treating prompts like search queries. Start treating them like low-code products.

If you want better AI output, design better inputs.

* Give the AI a role
* Guide the user one step at a time
* Structure the output like a product deliverable

🛠️ Now go build something weird, useful, and worth reusing.

[Share](https://deanpeters.substack.com/p/how-to-write-guided-generation-prompts?utm_source=substack&utm_medium=email&utm_content=share&action=share)