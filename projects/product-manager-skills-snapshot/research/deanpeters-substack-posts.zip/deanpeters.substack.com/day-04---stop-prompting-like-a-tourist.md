# Day 04 - Stop Prompting Like a Tourist

AI product managers live and die by their prompts. “Write me a user story” is not a prompt. It’s a prayer. And prayers are a fragile operating model.

[![](https://substackcdn.com/image/fetch/$s_!pTWL!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feb781721-c1c4-4576-b482-fd30c2a19027_1284x789.png)](https://substackcdn.com/image/fetch/$s_!pTWL!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feb781721-c1c4-4576-b482-fd30c2a19027_1284x789.png)

Two people walk into a great restaurant. One a typical tourist. One a touring chef.

The tourist points at the menu. “*I’ll have the thing with the sauce. The good one.*” The waiter brings whatever’s easiest to serve up. It’s fine.

The chef leans forward. “*Protein at 130 internal. Acid on the side. No salt until I see it.*” The kitchen serves up the culinary experience our intrepid cuisinier was actually seeking.

Same kitchen. Same pantry. Same model. Completely different outcomes.

The variable isn’t the restaurant. It’s the quality of the ask.

Most AI prompting is still the tourist… or maybe I should say pedestrian. It wants the good one. It hopes the kitchen understands what that means. It likely gets “good” being passed off as great.

Hope is not a strategy.

---

WTH (What the Hallucination) Is Going On Here
---------------------------------------------

Prompting used to be treated like a clever trick. Add a role. Add a goal. Sprinkle in “be concise.” Watch magic happen.

That era is over.

Since DeepSeek shook the table last year, “modern reasoning” stopped being a premium feature and became table stakes across all foundational models. These systems are not just fancy autocomplete. They search. They reason in steps. They call tools. They retrieve. They cite. They remember. They spend tokens while they do it.

When your prompt is vague, you are not just risking mediocre output. You are widening the search space when you should be narrowing its focus. The model spreads its attention across every plausible interpretation of what you might have meant. The more interpretations in play, the flatter the answer landscape. The flatter the landscape, the closer “wrong but confident” sits to “right.”

You are asking the model to guess what you meant, and then paying for the guesses in tokens and hallucinations because of your diluted intent.

The model is not confused. It is operating inside the boundaries you failed to define.

If you cannot explain why it reasoned the way it did, then don’t be surprised if you get vibe-fired ... or in the worst case scenario, a paid getaway to Club Fed.

[![](https://substackcdn.com/image/fetch/$s_!xey3!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd5b95972-0511-4c81-aad5-74f46ede1c36_1141x729.png)](https://substackcdn.com/image/fetch/$s_!xey3!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd5b95972-0511-4c81-aad5-74f46ede1c36_1141x729.png)

Prompting Is Time Discipline
----------------------------

A precise prompt takes longer to write.

It forces you to clarify the user, the constraints, the tradeoffs, and what “good” means in this moment. That thinking would have happened eventually. Prompt discipline just moves it earlier.

Ten minutes of clarity upstream saves fifty minutes of arguing with the assistant downstream. It saves you tokens and frustration.

If you find yourself correcting the model three times in a row, that is not iteration. That is deferred thinking. The kind of cognitive offloading that leads to intellectual atrophy.

Craft is cheaper than rework.

---

Prompting Is Cost Discipline
----------------------------

* Every ambiguous instruction increases reasoning depth.
* Every missing constraint increases exploration.
* Every tome dump muddies signal with noise and calls it “thoroughness.”
* Every undefined output format forces the model to generate broadly, then regenerate when you say, “that’s not what I meant.”

Multiply that inside research loops. Multiply it inside coding sessions. Multiply it inside chained workflows.

Sloppy prompting at scale is optimism with a compute budget.

You do not see it in the first interaction. You see it on the invoice.

Prompting Is Reasoning Design
-----------------------------

The best prompts today do not just ask for output. They shape how the model thinks.

They specify:

* What perspective to adopt.
* Who the target audience might be.
* What data to privilege.
* What to ignore.
* What tradeoffs to surface.
* What format makes the output operational.

They deliberately leverage what the model can already do:

* Search.
* Retrieve internal documents.
* Cite clickable sources.
* Ask for structured output.
* Call tools through connectors.

It’s 2026. Prompting is no longer clever phrasing. It is designing the reasoning environment.

And good reasoning environments include guardrails, not just instructions.

The prompt is not a request. It is standing guidance the system will follow until you replace it.

[![](https://substackcdn.com/image/fetch/$s_!yG4I!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff19fa6f6-98bd-4890-9dc4-7f9b3b63fab5_4200x1876.png)](https://substackcdn.com/image/fetch/$s_!yG4I!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff19fa6f6-98bd-4890-9dc4-7f9b3b63fab5_4200x1876.png)

Prompting Has Grown Up
----------------------

* In a single chat window, a weak prompt wastes time.
* In a research task, it wastes insight.
* In a coding session, it wastes precision and frustration.
* In a system connected to agents and coding tools, it wastes money.

Prompting is not a UX flourish. It is upstream of velocity, cost control, and reliability.

If you are leading AI product work, it is not optional craft. It is table stakes.

If you are creating agents, it is not a nice to have. It is an economic survival skill.

---

Coming Up
---------

Day 05: Individual prompt discipline does not scale if every PM operates inside a private session silo. Context is not “more information.” It is shared guidance.

Day 06: AI synthesizes customer research at speed. It also fabricates at speed. Clean output is not validated output.

---

*Most AI product management training teaches you how to use the tool. The Productside course teaches you how to design the system around it. Stage 3 is where most programs stop. Stage 3 is where we begin. Four days. Live online. Under 20 seats. Certification at the summit.*

[Start the ascent. Sign up for the course.](https://lnkd.in/eKWZxkyJ)