# Day 09 - More Data Won’t Save You

AI product management runs on data quality, not volume. Your hundred-million-record pile isn’t a strategy; it’s just an expensive place for your model to hide.

[![](https://substackcdn.com/image/fetch/$s_!1Kj2!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb26e19bd-bcd0-455f-841b-8b4bdf57bf3a_1377x768.png)](https://substackcdn.com/image/fetch/$s_!1Kj2!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb26e19bd-bcd0-455f-841b-8b4bdf57bf3a_1377x768.png)

The data team said the data was good. They meant it was complete. A hundred and forty million records. Clean schema. No obvious nulls. Reasonable documentation. An impressive number, stated with the confidence of people who have spent considerable time making a large thing look organized. It was the kind of number you put on a slide to make a board of directors feel like the future is under control.

What they did not say, because nobody asked: forty percent of the records were from a customer segment that no longer exists. The remaining sixty percent were collected with a methodology that changed eighteen months ago in a way that makes pre-change and post-change records structurally incompatible with each other. The model trained on all of it. The model shipped. The model produced outputs that were precisely calibrated to customers the company used to have, for problems the company used to solve.

Nobody caught it until users started flagging the recommendations as wrong. “Wrong but confident” is the data quality failure mode. It is not the only one, but it is the one with the most interesting post-mortems.

---

WTH (What the Hogwash) Is Going On Here
---------------------------------------

Volume became a proxy for readiness, and this happened in the way that most category errors happen: gradually, and then with great enthusiasm.

The logic was seductive: more data meant more signal, more signal meant better models, better models meant better products. The logic is not wrong exactly. It is incomplete in a way that becomes expensive at scale. More data is more signal only if the data is the right kind of signal. If it is stale, biased, structurally inconsistent, or collected for a purpose that does not match the current use case, more of it is just more of the same problem.

You cannot volume your way out of a data quality problem. You can only scale it, which is a very efficient way to make a small mistake into a large one.

[![](https://substackcdn.com/image/fetch/$s_!wAor!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7096b9bd-a6e2-4d3d-a3be-a1c7e5295ce1_2752x1070.png)](https://substackcdn.com/image/fetch/$s_!wAor!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7096b9bd-a6e2-4d3d-a3be-a1c7e5295ce1_2752x1070.png)

The Four Dimensions That Actually Matter
----------------------------------------

Data readiness is not one thing. It is four things, and most PM teams interrogate none of them before a model starts training.

**Quality.** Is the data accurate? Is it labeled correctly? Are there systematic errors in how it was collected? Quality problems produce confident wrong outputs. The model is wrong in the direction of the error, consistently. That is worse than random wrong because it is harder to detect and easier to trust.

**Freshness.** Is the data current enough to be representative? Customer behavior changes. Market conditions change. A model trained on pre-pandemic data producing recommendations for a post-pandemic world is not a model failure. It is a freshness failure that feels like a model failure until someone looks at the timestamp.

**Bias.** Does the data represent the population you are building for, or the population you historically served? Those may be very different groups. Bias in training data becomes bias in product output. This is not a data science problem. It is a PM problem because the PM defines what the product should do for whom.

**Compliance.** Is the data legal to use for this purpose? Not in theory. In practice. Under the regulations that apply to your company in the markets where you operate. Data that is legal to collect is not automatically legal to train a model on.

[![](https://substackcdn.com/image/fetch/$s_!98Sf!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe3b166bc-63c0-4b4a-9d6e-1496ab76e30a_2752x1536.png)](https://substackcdn.com/image/fetch/$s_!98Sf!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe3b166bc-63c0-4b4a-9d6e-1496ab76e30a_2752x1536.png)

Not Ready vs. Unfit
-------------------

Here is the distinction most teams miss, and the most expensive one to miss late.

“Not ready” is a timing problem. The data exists, it is the right kind of data, and it needs work. Cleaning. Labeling. Enrichment. Normalization. Given time and resources, it becomes usable.

“Unfit” is a structural problem. The data exists, but it cannot be made into the kind of data the model needs for this use case. The collection methodology is wrong. The population is wrong. The labels are systematically off in a way that cannot be corrected by engineering work alone.

A data pile wrapped in clean schema stuffed inside a pipeline nobody has audited is not data readiness. It is data theater.

---

How to Bungle $0.5 Billion Dollars
----------------------------------

Zillow Offers. The algorithm was “perfect.” It looked at historical housing prices and saw a straight line to the moon. The team had data—mountains of it—and they were confident. Then a global pandemic happened. The market shifted. The world changed.

The model, trained on a world that stopped existing on a Tuesday in March, kept buying houses at prices the post-lockdown market wouldn’t touch. And yet, in a room full of people with advanced degrees, we just... kept clicking ‘train’.

By November 2021, the bill arrived: a $569 million write-down. Zillow Offers was shuttered. The data was accurate, complete, and clean. It just wasn’t current.

**Stale data is a time bomb with a polished UI.**

[![](https://substackcdn.com/image/fetch/$s_!zxUY!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd13d6ff8-a8f3-4092-960b-8173652881b3_2752x1536.png)](https://substackcdn.com/image/fetch/$s_!zxUY!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd13d6ff8-a8f3-4092-960b-8173652881b3_2752x1536.png)

Why This Is a PM Problem
------------------------

The data scientist’s job is to build the best possible model with the data they are given. They are very good at this. They are not positioned to question whether the data they were given is appropriate for the use case the PM defined.

The PM defined the use case. The PM owns the alignment between the use case and the data. When the model produces biased outputs because the training data underrepresented a customer segment, the data scientist did their job. The PM did not do theirs.

Data fluency is not SQL. It is knowing how to ask the right questions before anyone starts building. It is knowing that “the data is clean” is not a complete answer to any question that matters.

---

Coming Up
---------

Day 10: Agents are not automation. They make decisions. At speed. Without checking in. Here is what happens when nobody thought about guardrails before the agent went live.

Day 11: How to build agentic products that do not go rogue. The map, the canvas, and the three moments where human oversight is non-negotiable.

Most AI product management training hands you a certificate at Stage 3 and calls it done. Stage 3 is where the Productside course begins. Four days. Live online. Under 20 seats.

[Start the ascent. Sign up for the class.](https://lnkd.in/eKWZxkyJ)