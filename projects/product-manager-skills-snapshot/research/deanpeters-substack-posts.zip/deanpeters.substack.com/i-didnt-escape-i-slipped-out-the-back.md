# I Didn’t Escape. I Slipped Out the Back.

Subscribe

It didn’t start with a breakdown—it started with a backlog.
-----------------------------------------------------------

Let me be clear: I didn’t leave the feature factory in a blaze of glory.  
There was no resignation speech. No triumphant Medium post.  
Just a whisper of burnout, a backlog full of should-haves, and a sticky note on my desk that said:  
***“Hope … is not … a strategy.”***

That was the moment I realized:   
I wasn’t managing products. I was managing stakeholder anxiety.

I wasn’t prioritizing outcomes:  
I was shoveling roadmap roadkill left behind by the last **‘HiPPO**’ stampede.

And while I had the title, the skills, the frameworks (God help me, I had SO many frameworks)…  
I didn’t feel like a product leader.  
I felt like the **Jira-Slinging Ticket Monkey** in the organizational organ grinder circus.

[![](https://substackcdn.com/image/fetch/$s_!gE7E!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc515a940-c493-4bbf-b80c-8d87862e20f8_600x600.png)](https://substackcdn.com/image/fetch/$s_!gE7E!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc515a940-c493-4bbf-b80c-8d87862e20f8_600x600.png)

---

Why This Substack?
------------------

Because maybe you’ve been there too:

* That quiet dread before backlog grooming.
* The gallows humor that sneaks into every retro.
* The fake grins in launch meetings—when you know you’ve just shipped a beautiful lie.

Maybe you've been gaslit by the roadmap, trampled by a ‘**RHiNO**’ or ‘**ZEbRA**’, or stuck salvaging what’s left after the **seagull manager** swoops in and poops on your sprint goals.

You wonder: *“Is it me?”*  
*“Am I the blocker?”*  
*“Why does this feel less like product leadership and more like **corporate cosplay?**”*

If those questions haunt your 1:1s, congratulations—you’re not broken. You’re just **paying attention.**

I’ve spent **30 years** in and around this chaos: 20 as a PM, 10 as a coder.  
If I haven’t done it, I’ve watched it explode spectacularly in the next cube over.

Early in my career, I got tapped to lead **skunkworks teams**—the ones too weird, risky, or high-stakes for anyone else to touch. We built quietly, iterated furiously, and delivered things that actually worked.

Later, I became a **smokejumper**—the one parachuted into **burninating** projects and flaming products. The guy called when roadmaps were on ablaze and morale was in ashes.

[![](https://substackcdn.com/image/fetch/$s_!fozk!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb9829c61-0459-453b-9332-9a389d0bebb1_600x600.png)](https://substackcdn.com/image/fetch/$s_!fozk!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb9829c61-0459-453b-9332-9a389d0bebb1_600x600.png)

I helped teams other people had written off. The "*difficult ones*." The "*hopeless ones*." And together, we didn’t just survive—we **shipped**. Some of those products are still out there, delighting customers, long after the initial chaos faded.

I didn’t escape with swagger—I slipped out the back, carrying every scar, story, and strategy I could.

I was doing **AI before it was fashionable**, building language models and data tools back when we still called it "that weird algorithm thing."

I’ve built teams that shipped brilliant stuff *and* stayed sane. The kind of teams that got me pushed out of a perfectly good plane and into fires when others ran out of oxygen.

[![](https://substackcdn.com/image/fetch/$s_!0TNk!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb64c2ce3-5aef-449f-af6c-3d565c510baf_402x600.png)](https://substackcdn.com/image/fetch/$s_!0TNk!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb64c2ce3-5aef-449f-af6c-3d565c510baf_402x600.png)

Eventually, I stopped fixing. I started teaching.

Now, I send the ladder back down—armed with survival skills, dad jokes, and a deep belief that **product management should not require emotional hazard pay.**

I built this substack for all of us still dodging feature factory fallout and dreaming of something better.

---

What Happens Next?
------------------

I don’t have all the answers.  
But I do have stories. Parodies. Lessons. Mistakes.  
I’ve got a few battle-tested tools, and a lot of jokes that shouldn’t work—but somehow still land.

This won’t be a listicle newsletter.  
This won’t be another saccharine “be the change” leadership blog.  
This certainly won't be another ChatGPT-generated "7 Tips I Stole from Marty Cagan's Last Book"

This will be the truth—told sideways.  
Wrapped in satire, delivered with compassion, and seasoned with just enough cynicism to be healthy.

So if you’ve ever chased three rabbits and caught none...  
If you’ve ever sung a sad little internal song during standup...  
If you’ve ever felt like you’re in a circus trying to tame the dangerous animals of product management …  
If you’ve ever wondered whether product management was supposed to feel like this—

**You’ve found your people.**

---

Thanks for reading Confessions of a Feature Factory Escapee! Subscribe for free to receive new posts and support my work.

Subscribe