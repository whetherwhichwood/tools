# Day 07 - You're Playing the Wrong AI Game

AI product management has four playing fields. Most teams pick the wrong one. They celebrate the launch. By Q3 they’re rebuilding. Here’s how to stop that.

[![](https://substackcdn.com/image/fetch/$s_!1p8S!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F65e39a7f-924f-4af3-b99d-dcf3859272cc_2784x1536.png)](https://substackcdn.com/image/fetch/$s_!1p8S!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F65e39a7f-924f-4af3-b99d-dcf3859272cc_2784x1536.png)

Picture the quarterly review, three months after launch, with the particular quality of fluorescent light that seems to exist only in rooms where someone is about to explain why the numbers look the way they look. The demo had been flawless. The stakeholders had done the nod. That slow, generous cadence of people who have decided this is probably a thing that will work and would like to return to their other commitments. The engineering was clean. The model performed within its parameters. The team celebrated on a Friday afternoon with the specific satisfaction of people who have shipped something real.

Then the Q3 metrics arrived, and the adoption metrics told a different story.

The customers who were supposed to hand over control to the automation didn’t trust it enough to do that. Not because the automation was broken. It wasn’t. The workflows that were supposed to be eliminated were still running in parallel, maintained by people who had decided, quietly and without announcement, that they would continue to do the thing the AI was supposed to do for them, because they didn’t yet believe the AI would do it correctly. The AI was executing its job with precision and confidence. The job, it turned out, had been defined for a customer relationship that didn’t yet exist.

This is a pattern. It has a name. “You were playing the wrong game.”

---

WTH (What the Haphazard) Is Going On Here
-----------------------------------------

Most teams pick their AI playing field the way a group of eight people picks a restaurant when nobody can agree on what they want. Someone suggests something. Nobody objects with quite enough conviction to change the direction. The suggestion hardens into a plan. Later, when the food arrives and turns out not to be what several people in the group would have chosen under conditions of, say, actual deliberation, there is a collective and politely generous agreement that perhaps more time should have been spent on the front end of this particular decision.

The difference is that a wrong restaurant choice costs you ninety minutes and a pasta nobody wanted. A wrong AI playing field costs you a quarter, a roadmap that needs rebuilding, and the very specific kind of board conversation where someone says “we need to revisit the strategy” in a way that does not sound like what it actually is.

There are four playing fields. They have always existed, lurking unnamed beneath every AI product decision made in the last three years, waiting for someone to write them down in a place where a product team might find them before the work begins. Most teams step onto the wrong one not because they thought carefully about the options and chose badly, but because nobody told them there were options, which is, in a discipline that prides itself on discovery and user research, a remarkable oversight to have maintained at this scale.

Three years into an AI product boom, and most teams still pick the playing field by whoever spoke first and nobody contradicted. I am trying to find the optimistic read on that. I have not found it.

[![](https://substackcdn.com/image/fetch/$s_!EIgk!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdd440d6f-5ace-49d4-aaa0-f6c4b180f371_2752x1536.png)](https://substackcdn.com/image/fetch/$s_!EIgk!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdd440d6f-5ace-49d4-aaa0-f6c4b180f371_2752x1536.png)

The Four Fields
---------------

### **Automate.**

The game where AI removes humans from the loop entirely. Not faster, not better-assisted. Gone. The human used to do the thing that was so tedious, dangerous, or robotic it needed to be automated. Now the machine does the thing. Nobody reviews it. It runs. This game is won when the task disappears so completely that the people who used to do it have moved on to something more interesting, and the old workflow recedes from memory the way a bad commute recedes once you move closer to the office.

The trust threshold for Automate is the highest of the four. A customer who hands something over entirely. Something with weight, something with consequence, something they’ve been doing themselves for years and have developed real opinions about. That customer needs to believe, deeply and before anything goes wrong, that the system will handle it correctly. That belief is not a feature you can ship. It is infrastructure you have to earn, over time, through demonstrated reliability in situations with real stakes.

Klarna found this in public. In early 2024, their AI agent was handling two-thirds of all customer service interactions, with the company projecting $40 million in annual savings. The technology worked. The metrics looked extraordinary. By 2025, the CEO was telling journalists: “We focused too much on efficiency and cost. The result was lower quality, and that’s not sustainable.” The customers who most needed a human, the ones with complicated disputes and the particular desperation of a problem that doesn’t fit a script, had encountered a system optimized for volume. The trust infrastructure hadn’t been built. The automation had been.

### **Streamline.**

The game where AI accelerates a workflow without removing humans from the decision. The human still does the thing, but faster, with better information, with less friction in the middle of a familiar process. This game is won when the same person finishes the same job in half the time and trusts the result more than they trusted it before, because the AI surfaced something they would otherwise have missed, and the thing it surfaced turned out to be true.

The failure mode here is confusing speed with value. Faster-but-wrong is not a win. The customer still makes the judgment call at the end, which means the AI’s job is not to decide. Its job is to set up the human’s decision so well that the right answer feels obvious.

GitHub Copilot has been playing this field since 2021. Developers report productivity gains of around 55%. The AI completes the line, surfaces the pattern, catches the edge case. The engineer still owns the architecture, the design decision, the final merge. That is not a limitation of the product. That is the product.

### **Generate.**

The game where AI produces outputs that didn’t exist before the session started. Content, code, analysis, recommendations, reports. Things a human prompted and a model produced and someone then has to decide whether to use. This game is won when the quality of what the AI generates meets or exceeds what the human was producing themselves, and the human’s job becomes editing rather than originating.

The failure mode is mistaking generation for judgment. The model can generate. It cannot know whether what it generated is appropriate for this customer, in this context, facing this specific decision at this specific moment in their relationship with your product. That remains a human problem, regardless of how convincing the output looks.

### **Suggest.**

The game where AI augments human decisions without trying to replace them. The human still decides. The AI surfaces, flags, recommends, pattern-matches across a volume of data no analyst could hold simultaneously, and then hands the enriched picture back to the person who still owns the outcome. This game is won not when the AI is right, but when the human makes better decisions faster because of what the AI surfaced, and because they have learned, through accumulated experience, to trust what it surfaces enough to act on it.

Grammarly has thirty million daily active users. Every one of them decides whether to accept the suggestion. The AI surfaces the correction. The writer still owns the page.

Suggest is the field most teams should be playing when they’re not yet ready for Automate. It builds the trust infrastructure that Automate requires. Teams that skip Suggest and jump directly to Automate discover, in their Q3 reviews, that they built for a level of customer trust that didn’t exist yet.

---

What Field Mismatch Actually Costs
----------------------------------

Build an Automate product when your customers needed Suggest, and watch the parallel process emerge. Klarna ran this experiment at scale. Their AI agent replaced 700 human agents, handled two-thirds of customer interactions, and projected $40 million in savings. Nobody disputes the efficiency gains were real. What emerged alongside them was something quieter: the customers with the complicated problems, the ones who needed judgment rather than speed, began routing around the automation the way water finds low ground. Not through feedback forms. Not through formal objection. Through the patient frustration of people who have decided the system is not going to help them. By 2025, Klarna was rehiring humans. A field assumption wrapped in a product requirement stuffed inside a planning cycle nobody questioned until the satisfaction scores arrived is not a technical failure. It is a trust failure that was always going to happen, because nobody checked whether the trust prerequisite existed before building the product that required it.

Build a Generate product when the real need was Streamline, and the AI produces outputs nobody asked for. The workflow didn’t need new content. It needed less friction around the content it already had. The feature ships. The customers route around it with the patient efficiency of people who have found the faster path. In the post-mortem, someone will say the users “didn’t understand the value.” They understood it. It wasn’t the value they needed.

Build a Streamline product when Automate was the only thing that would move the economics, and the AI saves someone thirty seconds per task. In a workflow where that task happens twice a week, thirty seconds is not a product. It is a rounding error in a quarterly business review where someone expected a different kind of number.

Fast is not a strategy. Fast in the wrong direction is a faster failure.

[![](https://substackcdn.com/image/fetch/$s_!ySm8!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2fcdae38-3cda-4112-b57f-220d59a32a14_2540x895.png)](https://substackcdn.com/image/fetch/$s_!ySm8!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F2fcdae38-3cda-4112-b57f-220d59a32a14_2540x895.png)

Two Questions Before You Build
------------------------------

There are two questions. They take thirty minutes. Run them before the field assumption hardens into a building decision, before the team falls in love with the product they imagine building.

1. **First**: does the customer want the human out of the loop, or do they want the human better-informed? This tells you whether you’re heading toward Automate and Generate, or toward Streamline and Suggest.
2. **Second**: does the value come from the output the AI produces, or from the decision the output enables? This tells you whether the AI is doing the work or setting up the work.

Two questions. The quarterly review is much longer.

One more worth asking before either of those: who is already playing this field well in an adjacent industry? Not to copy their features. To understand what their customers learned to trust, and how long it took. The field you are about to enter already has a playbook somewhere. Finding it before the project starts is substantially cheaper than discovering it exists six months after launch.

---

Coming Up
---------

Day 08: The difference between Accidental AI and AI-First. Three forms. One skip. Your competition already knows which one it is.

Day 09: More data is not a data strategy. It is a larger version of the same problem. Here’s what data readiness actually looks like.

---

*Most AIPM training teaches you to pick a field and build. The Productside course teaches you to pick the right field first. Four days. Live online. Under 20 seats. Certification at the summit.*

[Start the ascent. Sign up for the class.](https://lnkd.in/eKWZxkyJ)