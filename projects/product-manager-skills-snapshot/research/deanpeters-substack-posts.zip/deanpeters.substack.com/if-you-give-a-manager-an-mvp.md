# If You Give a Manager an MVP

[![](https://substackcdn.com/image/fetch/$s_!ftpX!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdd346ccb-c67d-462c-8751-85d27d1f5ecf_1536x1024.png)](https://substackcdn.com/image/fetch/$s_!ftpX!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fdd346ccb-c67d-462c-8751-85d27d1f5ecf_1536x1024.png)

**It all began with one modest MVP—before the roadmap rewrites, the legal reviews, and the sprint-zero standups.** This is the bedtime story I wrote for product managers everywhere, loosely inspired by Laura Numeroff’s ‘*[If You Give a Moose a Muffin](https://amzn.to/44lrLLe)’*—because that story isn’t just about snacks, it’s about scope:

* *give a manager a taste of possibility, and they’ll want the whole buffet.*

Only in this version, the moose wears a blazer, the muffin is your prototype, and the product manager? They just wanted to validate a simple idea before everything spiraled.

---

0:00

-1:46

Audio playback is not supported on your browser. Please upgrade.

---

If you build a simple MVP,  
just to validate a hunch—  
management will spot it quickly,  
and demand a full-scale launch.

When you say, “*It’s just for testing,*”  
with data points in mind,  
they will call it “*nearly finished*,”  
leaving validation behind.

And when you show the prototype,  
they will forward it to Sales.  
“*This looks ready for our clients!*”  
as your roadmap quickly flails.

Then, engineering will raise concerns,  
about scaling and technical debt.  
“We should refactor the backend first,”  
though no users have seen it yet.

“*Where is the infrastructure?*”  
they will ask with furrowed brow.  
“*We need sprints of platform building,*”  
for a product unproven now.

Sales will jump into the fray then,  
with a wishlist 10 miles long.  
“*Our clients need these features*,”  
though your research proves them wrong.

Then Legal will demand reviews,  
for compliance not yet due.  
They will block your simple testing,  
with requirements difficult and new.

Marketing will need a name,  
and a tagline they can share.  
Then they will post a launch date,  
while your team pulls out their hair.

And chances are quite certain,  
as your MVP grows and grows,  
you’ll be building version 2.5,  
before version 1 even shows.

And if you try another MVP…  
the cycle starts anew.  
You’ll build a simple prototype,  
and they’ll demand a full-scale debut.

---

[![](https://substackcdn.com/image/fetch/$s_!Y9AQ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F21bdaaa8-ceda-45c6-ae09-53ddfc030ed6_1200x800.png)](https://substackcdn.com/image/fetch/$s_!Y9AQ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F21bdaaa8-ceda-45c6-ae09-53ddfc030ed6_1200x800.png)

This story is the second in my *Broken Bedtime Stories for Product Managers* series, a loving parody of Laura Numeroff and Felicia Bond’s wonderfully chaotic trilogy. In this version, “*minimum*” became mythical and “*viable*” became a mandate. But don’t worry—the bedtime saga doesn’t end here. Enjoy post numero uno in this series, ‘*[If You Give Sales a Screenshot](https://deanpeters.substack.com/p/if-you-give-sales-a-screenshot)*.’

**~~Still to come~~ Update**: *[If You Pitch a Programmer a Problem](https://deanpeters.substack.com/p/if-you-pitch-a-programmer-a-problem),* along with a few bonus fables from the fabled land of Jira, Gantt, and gently weeping roadmaps. Cozy slippers encouraged. Scope creep inevitable.

---

Thanks for reading Confessions of a Feature Factory Escapee! Subscribe for free to receive new posts and support my work.

Subscribe