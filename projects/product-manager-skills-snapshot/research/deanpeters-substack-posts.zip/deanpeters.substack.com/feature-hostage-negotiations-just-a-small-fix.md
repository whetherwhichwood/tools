# Feature Hostage Negotiations: Just a Small Fix

[![1 tiny feature request. 2 weeks of chaos. QA's crying, the roadmap’s burning, & you're holding the duct tape. Welcome to Feature Hostage Negotiations.](https://substackcdn.com/image/fetch/$s_!XgrR!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F121a81de-242d-430d-a701-561c9314de51_3900x2048.png "1 tiny feature request. 2 weeks of chaos. QA's crying, the roadmap’s burning, & you're holding the duct tape. Welcome to Feature Hostage Negotiations.")](https://substackcdn.com/image/fetch/$s_!XgrR!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F121a81de-242d-430d-a701-561c9314de51_3900x2048.png)

*1 tiny feature request. 2 weeks of chaos. QA's crying, the roadmap’s burning, & you're holding the duct tape. Welcome to Feature Hostage Negotiations.*

It starts like this:  
A Slack ping.  
No subject.  
Just:

> *“Quick Q—can we add a tiny toggle?”*

Tiny toggle.  
Like it’s a Lego brick.  
Like it won’t sink the release raft if you step on it wrong.  
Like we’re not duct-taping technical debt under the dashboard and praying no one lifts the hood.

---

This, friends, is a **Feature Hostage Negotiation situation**.  
You’re not building a button.  
You’re paying ransom with your roadmap.  
And worse—they don’t even *know* they’re holding it, your team, and you hostage with their ‘just one small thing’ of an ask.

**Why?**  
Because we never showed them the cost.  
Not the real cost.  
Not the gut-punch price tag with teeth.

[![The cost of “just a button” is everything you didn’t plan for.](https://substackcdn.com/image/fetch/$s_!SLJO!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc0e0de10-37dc-4823-9840-cbb80b646467_1536x1024.png "The cost of “just a button” is everything you didn’t plan for.")](https://substackcdn.com/image/fetch/$s_!SLJO!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc0e0de10-37dc-4823-9840-cbb80b646467_1536x1024.png)

One “tiny feature” away from setting the entire sprint on fire.

---

You know what they *think* it costs?

* “One dev day.”
* “No impact.”
* “Shouldn’t take long, right?”

You know what it *actually* costs?

* **Three broken tests.**
* **One pissed-off QA.**
* **Two extra sprints for retroactive edge-case coverage.**
* **A product manager mainlining caffeine while rewriting the release notes to justify it all.**

And by the time you’re explaining this with your voice cracking in Sprint Review, it’s too late.

---

**So here’s the play:**  
Don’t educate in the crisis.  
Such a plea has no leverage.  
Educate in the calm.

When things are green, releases are smooth, and no one’s breathing fire—**that’s when you show your team what one “quick fix” really costs**:

* Diagram it.
* Post-mortem it.
* Name it like a storm.
* Print it on a mug if you have to:

> *“This Is What That Button Cost Us.”*

Because stakeholders aren’t evil.  
Let me say this again: 99% of our stakeholders are not evil jerks trying to make your life miserable.  
They’re just unaware.  
And unawareness is a luxury they can afford—until you make the cost tactile.  
Until you send the invoice.

So next time someone says:

> *“It’s just a small ask…”*

You smile.  
You breathe.  
And you say:

> *“Cool. Want the receipt?”*

---

Meanwhile, in the Real World…
-----------------------------

Shout-out to [@Sohaddader](https://substack.com/@sohaddader) for naming the storm. Her post ‘**[Stakeholder Storm, When Everyone Wants Everything, Now](https://open.substack.com/pub/sohaddader/p/stakeholder-storm-when-everyone-wants?r=3jxqq&utm_campaign=post&utm_medium=web&showWelcomeOnShare=false)**‘ reminded me that every “just a small feature” kicks off a Rube Goldberg machine of pain:

* **Dev:** “That means two weeks. Backend and frontend.”
* **Design:** “We need new components, flows, and user validation.”
* **QA:** “When it breaks, it breaks *everything*.”
* **PM:** *Googling stress management between meetings and mainlining coffee.*

> **There is no “just” in product.**  
> Every “small ask” has a full-sized impact.

---

[![The first in a series of Feature Hostage Negotiation posts.](https://substackcdn.com/image/fetch/$s_!4NZD!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7e92886e-4716-4fe7-a978-0265c0c83627_1536x1024.png "The first in a series of Feature Hostage Negotiation posts.")](https://substackcdn.com/image/fetch/$s_!4NZD!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7e92886e-4716-4fe7-a978-0265c0c83627_1536x1024.png)

The first in a series of Feature Hostage Negotiation posts.

This Was Just the First Feature Hostage Situation
-------------------------------------------------

Welcome to the **Feature Hostage Negotiations** series—a mini (maybe not so mini) exploration of those moments when well-meaning requests hijack your roadmap, sanity, and sprint velocity. I’m not sure when I’ll post another F.H.N. feature, but I’m sure I will.

**Some typical F.H.N. scenarios:**

* *“Let’s Just Ship It and Fix It Later”*
* *“The VP Promised It at Lunch”*
* *“The Feature’s Already in the Deck”*
* *“But the Intern Built It in Figma”*
* *“Why can’t we just Vibe Code this?”*

Got your own hostage tale? Drop it in the comments. Names optional. Therapy mandatory.

[Leave a comment](https://deanpeters.substack.com/p/feature-hostage-negotiations-one-small-fix/comments)

Like what you’re reading? A subscription would do me a solid.

Subscribe

A share would be downright friendly of ya!

[Share](https://deanpeters.substack.com/p/feature-hostage-negotiations-one-small-fix?utm_source=substack&utm_medium=email&utm_content=share&action=share)