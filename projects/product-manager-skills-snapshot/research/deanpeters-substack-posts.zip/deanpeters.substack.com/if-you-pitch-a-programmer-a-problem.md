# If You Pitch a Programmer a Problem

It all began with a simple problem statement—before engineering ambushed us with a surprise chatbot, the unplanned refactor, and the Friday night “quick deploy” that broke three things no one asked for.

[![Coder & PM -> If you pitch a programmer a problem, expect cookies, unit tests, and unintended features by Friday.](https://substackcdn.com/image/fetch/$s_!iTJr!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe1f337fe-2068-4adf-bdf9-417d813002c1_1536x1024.png "Coder & PM -> If you pitch a programmer a problem, expect cookies, unit tests, and unintended features by Friday.")](https://substackcdn.com/image/fetch/$s_!iTJr!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe1f337fe-2068-4adf-bdf9-417d813002c1_1536x1024.png)

If you pitch a programmer a problem, expect cookies, unit tests, and unintended features by Friday.

This is another bedtime story for product managers, inspired by Laura Numeroff’s *[If You Give a Pig a Pancake](https://amzn.to/3Q64yey)*—because if you’ve ever wandered into the **Problem Space**, only to be drowned out by **Solution Speech**, you know how this ends:

* *Give a programmer a problem… and suddenly you're five months deep into a scalable platform that's still three months from delivery.*

In this one, the programmer’s a penguin, the pancake is your neatly framed user pain smothered in solutionism syrup, and the product manager?  
They just wanted to talk about the problem—before the codebase gained sentience.

---

0:00

-2:06

Audio playback is not supported on your browser. Please upgrade.

---

If you pitch a programmer a problem,  
they’ll nod, and then they’ll ask,  
"*But what about the edge cases?*"  
and start a brand new task.

You’ll mention pains and context,  
and share the user's day—  
but they’ll already be busy  
rebuilding the oauth their way.

You’ll walk them through a journey map,  
with insights deep and raw.  
Yet somehow they’ll rewrite the login  
with custom regex law.

You’ll highlight risky assumptions—  
the kind that need a test.  
But they’ll shout, “*Let’s add AI!*”  
as if that solves the rest.

You’ll nudge them with some JTBDs,  
with gains still undefined.  
Engineering builds export tools  
no user cares to find.

You’ll recap early interviews—  
the pain points sharp and clear.  
Still, they'll tweak the queueing logic  
for problems that aren't near.

You’ll post your Opportunity Tree,  
and beg for discovery.  
Yet they will build a chatbot next—  
it’s “*sentient*,” allegedly.

You’ll try again to steer things back  
to actual user needs.  
But soon they’ll ship an Easter Egg  
with blockchain-powered feeds.

You’ll point again to roadmap goals,  
and ask, “*Does anyone actually needs this?*”  
But they will ship a Friday beta  
and call it “*product genius*.”

You’ll say, “*We’ve launched no POC yet—  
just shipping would be fine*.”  
Yet engineering will architect  
a planet-scale pipeline spine.

And just when you’ve lost all your hope—  
mid-pivot, drained and dry...  
they’ll blink and say, “*Should we have asked  
what people want—and why?*”

So you'll pitch programming a new problem,  
they’ll nod, and then they’ll ask,  
"*But what about the edge cases?*"  
and start a brand new task.

---

The moral of the story?
-----------------------

**Problem-first thinking is a noble path… right up until someone opens VS Code.**

In this tale, the programmer didn’t mean harm. They meant well. They meant scale.

But they still solved the wrong problem—beautifully, efficiently, and without ever looking at a single user.

And the product manager?  
Well… they just wanted to stay in the Problem Space a little longer.

Before the chatbot.  
Before the blockchain.  
Before the penguin rebuilt the auth flow. Again.

---

Epilogue
--------

This is the third tale in my Laura Numeroff-inspired trilogy of cyclical product chaos—**Broken Bedtime Stories for Product Managers**. The others are:

* [If You Give Sales a Screenshot](https://deanpeters.substack.com/p/if-you-give-sales-a-screenshot)
* [If You Give a Manager an MVP](https://deanpeters.substack.com/p/if-you-give-a-manager-an-mvp)

At some point, I’d love to parody:  
**Goodnight Moon**, **Green Eggs and Ham**, **Where the Wild Things Are**, and *Caps for Sale*—all through a product lens.

But for now, I’m off to teach other topics—with the usual mix of strategy, satire, and sticky notes.  
  
**Suggestions welcome.**

Thanks for reading Confessions of a Feature Factory Escapee! Subscribe for free to receive new posts and support my work.

Subscribe