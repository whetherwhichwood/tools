# Day 06 - The Customer Signals AI Gets Wrong

AI product managers can now synthesize 1,000 interviews in minutes. They can also hallucinate a customer pain point that doesn’t exist. Know the difference.

[![](https://substackcdn.com/image/fetch/$s_!BQnX!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feae458e9-be17-416f-aa5a-64d9cd1419e0_1398x768.png)](https://substackcdn.com/image/fetch/$s_!BQnX!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Feae458e9-be17-416f-aa5a-64d9cd1419e0_1398x768.png)

The research looked solid.

Forty-seven customer interviews. A hundred and twelve support tickets. The digital equivalent of napkins covered in angry handwriting from customers who had finally run out of patience. Three rounds of user testing. Weeks of listening, probing, asking one more question when the first answer felt a little too neat.

The sort of pile that makes a team feel they have done the real work.

Someone fed the whole thing into Claude.

Eight minutes later the synthesis appeared. Five themes arranged with the calm authority of a document that had been properly formatted, the insights lined up in tidy rows as if they had politely organized themselves while nobody was looking.

The room relaxed. Finally. Clarity. Two months later they discovered something awkward. One of those themes had never existed.

Not slightly wrong. Not loosely interpreted. **Invented!**

No customer even came close to saying the thing that now sat comfortably in the middle of the roadmap, radiating the quiet authority of a bullet point and a bold heading.

And yet there it was.

Which is a long time to build something nobody asked for.

WTH (What the Haze) Is Going On Here
------------------------------------

AI is spectacular at seeing patterns. Feed it enough transcripts and it will begin to detect shapes in the data the way a seasoned chef can glance at a refrigerator full of ingredients and start mentally assembling dishes.

But pattern detection has a blind spot.

It cannot tell the difference between signal and resemblance.

Human researchers carry the nuances of the research with them. They remember the interview that contradicted everything else. The quote that sounded perfect but didn’t capture the sarcastic smirk. The pregnant pause in a customer’s voice when a question drifted close to something real.

Those moments matter.

They are the loose threads that keep you from weaving a story that never actually happened.

Models do not remember pauses. They remember probabilities.

Two quotes lean the same direction. A third politely tilts in agreement. The synthesis connects the dots with the serene confidence of a system that assumes the dots were meant to connect.

The document looks finished. The thinking might not be.

[![](https://substackcdn.com/image/fetch/$s_!oFsa!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fedccc959-cbf8-475e-b898-2da4f9b75525_2752x1451.png)](https://substackcdn.com/image/fetch/$s_!oFsa!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fedccc959-cbf8-475e-b898-2da4f9b75525_2752x1451.png)

When the Radar Lies
-------------------

Meteorologists solved this problem years ago.

Weather radar sweeps enormous volumes of sky, translating movement in the atmosphere into patterns that bloom across the screen like watercolor storms. It can see rain bands forming hundreds of miles away, track the curling arms of hurricanes, and watch thunderstorms roll across the plains with the patient attention of a machine that never gets bored.

Radar also sees birds.

Huge migrating flocks cross the beam and light up the display exactly where a thunderstorm might appear. The shapes look convincing. The motion is real. The radar is doing exactly what it was designed to do.

It detected movement.

Customer research synthesized by AI behaves in much the same way. The model scans the transcripts the way radar scans the sky, noticing motion in the data and translating it into patterns that appear meaningful from a comfortable distance.

Sometimes it’s rain. Sometimes it’s geese. The model does not know the difference. From thirty thousand feet everything looks like weather.

Which is why roadmaps built from thirty thousand feet sometimes end up chasing birds across the sky.

---

Speed Is Not Insight
--------------------

None of this means AI synthesis is a bad idea. In fact the speed it offers borders on miraculous. What once required days of careful reading can now happen in minutes, leaving teams free to run broader research and ask deeper questions.

The speed is useful. Mistaking speed for certainty is dangerous.

Human researchers remember turbulence. They remember the quote that refused to behave, the interview that punctured the tidy narrative forming on the whiteboard.

Those moments of friction are often where the real insight lives.

AI smooths the sky.

The synthesis arrives clean, confident, and beautifully organized, the textual equivalent of a radar screen showing orderly bands of rain sweeping neatly across the map.

Clean output is not validated insight. It is simply clean output.

And clean output has a way of persuading busy teams that thinking has already been done.

[![](https://substackcdn.com/image/fetch/$s_!tqlw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0107ef4f-2579-40df-b9f7-e70c3d230e4d_2752x1536.png)](https://substackcdn.com/image/fetch/$s_!tqlw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0107ef4f-2579-40df-b9f7-e70c3d230e4d_2752x1536.png)

Synthetic Signals Are Still Signals
-----------------------------------

Once you start looking for it, the pattern shows up everywhere.

### The $4b Synthetic Boondoggle

IBM’s Watson for Oncology is a famous example. IBM poured roughly four billion dollars into the broader Watson Health effort that this system sat inside. On paper it looked revolutionary: AI assisting oncologists with treatment recommendations.

In practice it was closer to what critics later called “MSK-in-a-box.” The system was trained primarily on data and practices from Memorial Sloan Kettering, which meant the model learned a very particular slice of oncology and quietly assumed the rest of the world practiced medicine the same way.

Inside that bubble the recommendations looked impressive.

Outside it the cracks showed quickly. Different hospitals. Different patients. Different treatment histories. In some cases the system even suggested treatments that oncologists considered unsafe or simply wrong.

The radar had learned one storm system.

And then it started seeing that storm everywhere.

Radar calibrated to one storm system tends to see that storm everywhere.

### The Synthetic Patient Problem

Synthetic data can create similar illusions. MITRE’s Synthea project, for example, is an open source simulator that generates realistic looking but entirely synthetic patient histories across diseases, demographics, and treatment paths. The records look like real electronic health records, but they are generated from clinical guidelines and public statistics rather than actual patient files.

In theory, something like Synthea could have helped systems such as Watson for Oncology. A large configurable synthetic population can be used to stress test recommendations, expose institutional bias, and surface unsafe treatment suggestions before the model ever reaches a hospital.

But simulators do not fix organizational problems.

They cannot correct overhyped product claims, poor clinical explainability, or the absence of real world trials that earn doctors’ trust.

It is a clever and necessary tool based on sanitized human data.

But synthetic populations inherit the assumptions used to generate them.

If those assumptions are narrow the simulated weather system can look perfectly coherent while bearing only a passing resemblance to the sky outside the laboratory.

### Focus Groups With Imaginary People

Simulated research panels have their own version of the mirage. Tools like Microsoft’s TinyTroupe can generate interview personas that answer questions with just enough personality to feel plausibly human.

But if those personalities are not grounded in real survey cohorts or behavioral data the system is effectively reading weather patterns from characters that never existed.

A focus group composed entirely of imaginary people will confirm almost anything.

Very efficiently.

### The Phantom Factory Problem

Industrial AI runs into the same trap. Feed a model the JSON specification of an IIoT device and it can generate anomaly scenarios all afternoon, complete with tidy failure modes and persuasive diagnostic suggestions.

Without synthetic IIoT or SCADA data grounded in adjacent time series captures of analogous machines, loads, and failure conditions those anomalies are simply storms in a simulated sky.

They look impressive.

Until you step outside.

[![](https://substackcdn.com/image/fetch/$s_!3aG_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6af0fe08-469a-415d-9298-fa6457c7b039_1355x1536.png)](https://substackcdn.com/image/fetch/$s_!3aG_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6af0fe08-469a-415d-9298-fa6457c7b039_1355x1536.png)

The Why Question
----------------

This is where Jobs-to-be-Done earns its keep.

Customers describe symptoms. They talk about friction, frustrations, and the features they believe might fix things. Beneath those statements sits the actual job they are trying to accomplish, the quiet gravity pulling all the noise into orbit.

It is not that customers or stakeholders are trying to be annoying. Solution speak is simply the only language most people have for describing a problem. They reach for features the way a tired traveler reaches for directions, hoping someone else knows the road.

The role of the product manager is translating solution speak into problem statements.

Ask why.

Then ask why again, gently but more precisely.

Then once more, from a slightly different angle, until the conversation stops orbiting the solution and finally lands in the problem space.

Insights that survive three rounds of why tend to carry real rain with them. The others dissolve quickly, like clouds that looked impressive on radar but vanish the moment you step outside.

That is when you return to the transcripts and ask the only question that actually matters. Because feeding raw transcripts into a chatbot that already leans toward solution speak is a very efficient way to manufacture agreement.

Which human actually said this?

If you cannot find them, the radar saw birds.

---

How to Use AI for Customer Research Without Getting Fooled
----------------------------------------------------------

Run the synthesis.

Absolutely run the synthesis.

But then trace key insight back to its source, following the chain from theme to quote to transcript to the actual human voice that produced it.

Not a spot check. Every key insight.

Ask the model to cite the interviews behind each theme. If it cannot produce them treat the signal as unverified. If the citations collapse under inspection the storm was imaginary.

Yes, this takes longer.

It is still dramatically faster than building a product around a thunderstorm that turns out to be migrating wildlife.

Because eventually someone will ask the question every product leader asks when the numbers begin to smell slightly wrong.

“*Which customer said this?*”

If the answer is “*none of them,*” the meeting ends early.

[![](https://substackcdn.com/image/fetch/$s_!E9GL!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0969a174-77c7-493e-b477-2e017792cdb6_2752x1536.png)](https://substackcdn.com/image/fetch/$s_!E9GL!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0969a174-77c7-493e-b477-2e017792cdb6_2752x1536.png)

Coming Up
---------

Day 07: Most AI product teams are playing on the wrong field. There are four. Picking the wrong one explains most of Q3 rebuilds.

Day 08: The difference between AI-shaped products and AI-first products. Your competition figured out which one wins. That gap is already widening.

---

*Most AIPM training teaches you to use AI for customer research. The Productside course teaches you to use it without getting fooled by it. Four days. Live online. Under 20 seats. Certification at the summit.*

*[Start the ascent. Sign up for the course.](https://lnkd.in/eKWZxkyJ)*