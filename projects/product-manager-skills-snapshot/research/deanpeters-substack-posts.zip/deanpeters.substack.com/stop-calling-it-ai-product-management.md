# Stop Calling It AI Product Management

It’s 2025. Every product manager is now, by default, an AI PM. Let’s stop title inflation & stay anchored in what matters: great product management.

So, with apologies to Gary Larson's original *“[How to Recognize the Mood of an Irish Setter](https://www.perplexity.ai/search/tell-me-about-gary-larson-the-xyaDhq8qQS6Sxy4kOvJZHA)”*, I offer this parody: *“**How to Recognize the Job Title of a Product Manager.**”*

[![Collect them all! Each one attends the same meetings](https://substackcdn.com/image/fetch/$s_!IMCv!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff7f0b8ae-f2bf-402d-b2a7-40821be0e7e5_6468x4478.png "Collect them all! Each one attends the same meetings")](https://substackcdn.com/image/fetch/$s_!IMCv!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff7f0b8ae-f2bf-402d-b2a7-40821be0e7e5_6468x4478.png)

Collect them all! Each one attends the same meetings

Six panels. Six wildly different labels. One gloriously unbothered dog face.

It’s funny because nothing actually changes, just like real product management.  
Same bark. Same backlog. New buzzwords.

Let’s count the ways.

---

Role #1: Product Manager (The Control Group)
--------------------------------------------

No prefix. No props. Just pure, uncut product management.  
Not the Jira-flavored version. Not the “please align this roadmap with my OKRs” version.  
We’re talking the real thing: delivering value by navigating chaos with clarity.

**10 Things That Actually Define Great Product Management**

1. Fall in love with the problem
2. Deliver outcomes, not output
3. Say no like it’s your love language
4. Prioritize like focus is a competitive advantage (because it is)
5. Translate ambiguity into alignment
6. Frame product bets, not backlog sludge
7. Build momentum, not just velocity
8. Lead without authority — and without whining
9. Validate early, adjust often
10. Ship value that actually moves the needle

---

Role #2: Technical Product Manager
----------------------------------

**What’s Different-ish**

1. You bridge technical feasibility with customer value
2. You understand scale *and* semantics
3. You turn infrastructure into strategic advantage
4. You protect your engineers from bad ideas
5. You connect backend to business without a translator
6. *See Role #1*

---

Role #3: Data Product Manager
-----------------------------

**What’s Nuanced**

1. You wrangle data as a product, not an afterthought
2. You define trust as a deliverable
3. You govern with grace, not red tape
4. You’re fluent in correlation *and* causation
5. *See Role #2*
6. *See Role #1*

---

Role #4: Agile Product Manager
------------------------------

**What’s Slightly More Iterative**

1. You treat iteration as learning, not just slicing
2. You unify discovery and delivery without handoffs
3. You work in loops, not ladders
4. *See Role #2*
5. *See Role #1*

---

Role #5: Product Owner
----------------------

**What’s Slightly Different**

1. You connect product vision and strategy to execution with ruthless clarity
2. You protect the “why” behind the “what” on behalf of the "who."
3. *See Role #4*
4. *See Role #1*

---

🤖 Role #6: AI Product Manager
-----------------------------

**What’s Allegedly New**

1. AI-first product management is not about bolting on intelligence onto legacy ‘Frankensoft’ workflows—it’s about reimagining the product core around insights, delegation, adaptability, and systemic trust.
2. *See Roles #2, #3, and #4*
3. *See Role #1*

---

We promise they’re all different. Look closely.  
No really… keep squinting…

---

[![Welcome to the roadmap. Yes, it's still a mess. No, AI didn’t fix it.](https://substackcdn.com/image/fetch/$s_!Vj3M!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb9c57e59-0534-4dd3-9fb8-7d76394bf979_3072x2048.png "Welcome to the roadmap. Yes, it's still a mess. No, AI didn’t fix it.")](https://substackcdn.com/image/fetch/$s_!Vj3M!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb9c57e59-0534-4dd3-9fb8-7d76394bf979_3072x2048.png)

Welcome to the roadmap. Yes, it's still a mess. No, AI didn’t fix it

Final Thought: Can We Kill the “AI Product Manager” Title Now?
--------------------------------------------------------------

It’s 2025.  
Congratulations: **you’re already an AI Product Manager.**

Even [Ken Norton](https://www.linkedin.com/feed/update/urn:li:activity:7337879522429542400/) wrote about this on LinkedIn the other day, where he said:

The role is shifting and evolving, as it always has. It will change as much or more over the next 20 years as it has since I wrote my essay. But the human stuff that actually matters most in PM’ing is the least likely to be automated by AI.

Why? Because every product manager today — every last Irish setter-faced one of us — is:

* Considering how AI delivers customer and business value
* Using AI to accelerate daily PM decisions and delivery
* And learning how to work alongside systems that don’t always play by the rules

Just like with mobile. Just like with cloud. Just like with every other revolutionary disruptor that turned out to be just … **product management, evolving.**

Yes, you need to pick up new skills.  
Yes, some of them are weird and mathy.  
But they’re all **tangible**.

What’s **permanent** — what you’re actually hired for — is:

* Clarity
* Judgment
* Strategy
* Taste
* Leadership

You know… the **intangibles**.

So let’s stop inflating titles.  
Let’s stop pretending the prefix makes the practice.

**Kill the “AI Product Manager” label.**  
And just call it what it is:  
**Product management. Done well.**

---

[Leave a comment](https://deanpeters.substack.com/p/stop-calling-it-ai-product-management/comments)