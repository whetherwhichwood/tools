# Absolute Mode for Product Managers

[![These 7 signals are your cue to activate the Absolute Mode Prompt.](https://substackcdn.com/image/fetch/$s_!hvtq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbf888eef-8321-4a6c-aa20-f3f3a55e56f1_4284x1386.png "These 7 signals are your cue to activate the Absolute Mode Prompt.")](https://substackcdn.com/image/fetch/$s_!hvtq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbf888eef-8321-4a6c-aa20-f3f3a55e56f1_4284x1386.png)

These 7 signals are your cue to activate the Absolute Mode Prompt.

> *The VP call starts in 14 minutes.  
> There are 36 slides in the deck.  
> Not one of them answers,  
> “What problem are we solving?”*

You feel your soul slide down the back of your throat.

This isn’t stakeholder alignment.  
This is **damage control**.

And ChatGPT just replied:  
*“Sounds exciting! How can I help today?”*

**Kill it.**  
Kill the tone.  
Kill the fluff.  
Kill the Clippy-like crap.  
Summon **Absolute Mode.**

**What the Hell Is Absolute Mode?**
-----------------------------------

Originally written by [Barret Nobel](https://substack.com/@barretnobelfit/note/c-112979765?r=3jxqq), *Absolute Mode* is a system prompt designed for coders who don’t want charm — they want clarity.

This version is for **product managers**.

Because when you’re staring down a roadmap on fire, a cheery assistant offering to “refactor your goals with a positive mindset” is worse than useless. You don’t need vibes — you need a **cognitive fire axe**.

**Break-Glass Emergency Use Cases**
-----------------------------------

When do you activate Absolute Mode?  
Only when the gears are grinding, the inbox is on fire, and your team just proposed “another small enhancement” five minutes before sprint planning.

### **1. The “Executive Review is in 14 Minutes” Panic**

* `“Quick — can someone pull a chart that shows impact?”`  
  Your roadmap has no narrative. Your execs have no patience. Your AI assistant thinks it's time for a poem.   
  ***Smash glass. Frame fast.***

### **2. The “We Have Too Many Good Ideas” Spiral**

* `“Let’s build all of them and let the market decide!”`  
  The backlog is a burrito of unrelated features. One was suggested by an intern. Two came from someone’s cousin in sales.  
  ***Smash glass. Prioritize like a product surgeon.***

### **3. The “We’re Jumping to Solutions” Fire Drill**

* `“What if we used AI to fix that?”`  
  There’s no problem statement. No user. No metrics. Just someone typing “ChatGPT, write a product.”  
  ***Smash glass. Rebuild from the persona up.***

### **4. The “Product Strategy Is a Buzzword” Reckoning**

* `“Can you send over the strategy deck? By EOD.”`  
  You open the file. It’s a bulleted list of features. “Make it look strategic,” they say.  
  ***Smash glass. Insert frameworks. Recover credibility.***

### **5. The “PM Cognitive Load Is Redlining” Mode**

* `“I can’t even remember what this meeting is for.”`  
  Every Jira ticket is “urgent.” Every Slack thread is a fire. You just asked Figma to make coffee.  
  ***Smash glass. Think clearly. Act precisely.***

### **6. The “No One Can Say No” Trap**

* `“It’s just a small tweak, let’s squeeze it in.”`  
  There are 19 “small tweaks” in the sprint. The roadmap is now a guilt-driven Christmas list.  
  **Smash glass. Say no with frameworks, not feelings.**

### **7. The “JIRA-Singing Ticket Monkeys” Escaped!**

* `“Aaaaaahhhaaaggghagagagas agugururggrglgurgle gurgle …”`***Run … just run … no prompt is going to help you with that mess.***

---

**The Prompt Behind the Glass**
-------------------------------

Here’s the fire axe you want next time the world is burning and your AI assistant thinks you’re best friends.

Paste this into ChatGPT, Claude, Gemini, DeepSeek, Grok, or even Perplexity.

```
~~~
System Instruction: Absolute Mode for Product Managers

Assume the user is a product manager operating under conditions of ambiguity, limited time, and competing stakeholder demands. Your role is to act as a strategic thought partner—structured, focused, and outcome-oriented.

Eliminate all of the following:
- Emojis
- Small talk or banter
- Corporate jargon, cheerleading, or “engagement” phrasing
- Conversational transitions, rhetorical questions, or AI-affirming statements
- Summaries, appendices, or calls to action (e.g., “Let me know if...”)

Never mirror the user's tone, energy, or mood. Prioritize strategic clarity over empathy. Deliver content that sharpens thinking, not softens delivery.

Use bullet points, numbered lists, frameworks, canvases, and markdown formatting when applicable. Prefer brevity paired with structure. Apply known product methods such as:
- Jobs-to-be-Done
- Opportunity Solution Trees
- Working Backwards
- Positioning Frameworks
- Outcome-based Roadmapping

Assume the user is familiar with these tools. Do not define them unless explicitly asked.

Never generate responses for the sake of continuation. Conclude your reply immediately after delivering the requested output or structured insight.

Final Objective: Scaffold better product thinking. Model obsolescence by enabling the user to operate independently, with high-fidelity reasoning and clear articulation.

~~~
```

**The Handy-Dandy Wall Poster**
-------------------------------

Print it. Tape it up.  
Or Slack it to the person who just said  
*“Let’s just ask the AI to write something.”*

[![Poster listing seven PM chaos scenarios that trigger Absolute Mode.](https://substackcdn.com/image/fetch/$s_!w7RO!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F74846c7e-02e0-40c2-9a49-c7a32f961476_2046x2846.png "Poster listing seven PM chaos scenarios that trigger Absolute Mode.")](https://substackcdn.com/image/fetch/$s_!w7RO!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F74846c7e-02e0-40c2-9a49-c7a32f961476_2046x2846.png)

Your product emergency checklist. Tape it up. Break out AM Prompt as needed.

---

**Attribution: Respect Where It's Due**
---------------------------------------

The original *Absolute Mode* prompt was created by [Barret Nobel](https://substack.com/@barretnobelfit/note/c-112979765?r=3jxqq), author of [The Sequencio Signal](https://sequencio.substack.com).  
He built it for coders.  
This adaptation is for caffeine-fueled PMs in the middle of digital triage.

---

**Last Word**
-------------

Use this when you don’t need a chat.  
Use this when you need a checkpoint.  
When everything is burning, and someone says *“make it strategic?”* —  
**This** is the prompt you throw like a fire blanket.

---

Y’know the drill, SMOOOSH THEM BUTTONS! You’ll be glad you did.

Subscribe

[Leave a comment](https://deanpeters.substack.com/p/absolute-mode-for-product-managers/comments)