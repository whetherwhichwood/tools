# Dig like an Arms Merchant – Deal like a Peacemaker

**Everyone else is foaming at the mouth over “AI solutions.”**  
You’re the one asking the only question that matters:

> *“What’s the right thing to build?”*

And right now? That question gets you **blank stares**, a pile of half-baked LLM demos, and a backlog full of “Can we do ChatGPT for \_\_\_\_\_?”

Welcome to the modern Platform Product Manager reality—where your job isn’t just enabling builders.

It’s **keeping the entire ecosystem from imploding.**

[![Platform Product Managers: Dig like an arms merchant but deal like a peacemaker](https://substackcdn.com/image/fetch/$s_!mABw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5976d188-34d7-4133-a19a-11cbbab65122_3320x1536.png "Platform Product Managers: Dig like an arms merchant but deal like a peacemaker")](https://substackcdn.com/image/fetch/$s_!mABw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5976d188-34d7-4133-a19a-11cbbab65122_3320x1536.png)

Platform Product Managers: Dig like an arms merchant but deal like a peacemaker

---

You’re sitting in the middle of a civil war.
--------------------------------------------

Anyone who has taken one of my product management classes at Productside has indelibly imprinted in their brains the ‘Deanism’:**“*****Hope is not a Strategy.*****”**

This is true for those glory hounds managing business model products … and yes, for you in-the-trenches, platform product managers dealing with the operating model.

My suggestion? As someone who has fought in both camps?

**Dig** like an arms dealer   
… but …  
**Deal** like a peacemaker  
… and …  
**Build** the platform no one else can see  
… yet.  
  
Take, for instance, the emerging conflagration between **vibe coding** and **horizontal** **platformism**.

On one side: **Vibe Coders.**  
The chaotic good hackers of the org. Shipping AI stuff faster than IT can say “SOC 2.” They’re validating problems, discovering magic, lighting fires.

On the other: **Platform Purists.**  
The architects. The compliance-obsessed. The ones who believe nothing is real until it passes a design review and hits five 9s of uptime.

And you? You’re the poor soul holding the rope while both sides tug like it’s a zero-sum game.

---

Dig Like an Arms Dealer
-----------------------

The best Platform PMs don’t start with “what’s our roadmap?”  
They start with:

* *Where’s the friction?*
* *Who’s fighting?*
* *What rockets, missiles, and plowshares are they already reaching for?*

You’re not here to worship the roadmap.  
You’re here to mine for **underground demand** hiding in the dysfunction.

---

Deal Like a Peacemaker
----------------------

Once you’ve mapped the battlefield, it’s not about selling better weapons.

It’s about **designing the bridge.**

In the case of our example, the real value is in platforms   
that let vibe coders experiment *without blowing up infra,*  
and let platform teams govern *without strangling innovation.*

You're not here to pick sides and win their fights.  
You're here to **end it by building something both sides can win with.**

[![Most orgs pick a side, speed or scale. Your opportunity lies in bridging both.](https://substackcdn.com/image/fetch/$s_!6a9T!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F91411783-a774-439f-b13b-ccd448f53a54_1536x1024.png "Most orgs pick a side, speed or scale. Your opportunity lies in bridging both.")](https://substackcdn.com/image/fetch/$s_!6a9T!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F91411783-a774-439f-b13b-ccd448f53a54_1536x1024.png)

Most orgs pick a side, speed, or scale. Your opportunity lies in bridging both.

---

The Hidden Gold
---------------

Everyone's chasing the [24% of market share left](https://www.categorypirates.news/p/a-beginners-guide-to-category-design)[1](https://deanpeters.substack.com/p/dig-like-an-arms-merchant-deal-like#footnote-1-161802350) in AI vibe coding & platform tools  
But that’s just product pyrite.

The *actual* opportunity is bigger:  
**Be the bridge. Own the category. Define how the game is played.**

Because in this new era, it’s not the fastest or the cleanest that win.  
It’s the ones who **design the peace.**

It’s the one who builds a Marshall Plan-like platform where an organization can produce faster, save more money, and remain compliant and safe at scale

---

The Payoff
----------

So what happens when you stop picking sides—and start building the bridge?

You get a platform where **both camps do what they do best**—without sabotaging each other.

**Again, for example, with our Platform Purists vs. Vibe Coder Conundrum:**

### Vibe coders?

They still move fast.  
They still chase sparks.  
They still drop half-working magic into Slack at 2 AM.

But now, they vibe inside a **system that protects the rest of the org**.  
They get **fast feedback** on what flops—without waking up infosec or blowing up cost centers.  
They learn [which 80% of ideas suck](https://www.lennysnewsletter.com/p/the-ultimate-guide-to-ab-testing), and they learn it **faster**.[2](https://deanpeters.substack.com/p/dig-like-an-arms-merchant-deal-like#footnote-2-161802350)

### Platform purists?

They stop rewriting every prototype from scratch.  
They stop running security reviews on napkin sketches.  
They stop fighting vibe with bureaucracy.

Instead, they get to **scale the ideas that proved their worth**—  
with **less Sturm und Drang than a Wagnerian opera.**  
Because the foundation’s built.  
Because the architecture knows how to flex.  
Because the platform does what **AI and computers do well**—so **humans can do what they do well.**

### Bottom Line?

Be the product manager who builds a platform where an organization can produce faster, save more money, and remain compliant and safe at scale — with a combination of vibe coding validation that can be scaled by the platform team if not thrown away.

**And if thrown away** — which is always an option — can at least be used to scaffold the more scalable platform replacement.

---

[![Good PMs design for the feature. Great PMs design for the Conflict.](https://substackcdn.com/image/fetch/$s_!v436!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc650edcf-ad28-4563-85ce-71d4790b0762_1536x1024.png "Good PMs design for the feature. Great PMs design for the Conflict.")](https://substackcdn.com/image/fetch/$s_!v436!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc650edcf-ad28-4563-85ce-71d4790b0762_1536x1024.png)

**TL;DR: You’re not a backlog babysitter. You’re a battlefield cartographer.**

You didn’t just build a layer.  
You built **alignment.**You built **collaboration.**  
You built **leverage.**  
You built the thing that lets two factions thrive without killing each other.

That’s not a compromise.  
That’s a category.  
That’s Platform Product Management!

---

Want More Like This?
--------------------

If you’re a Product Manager trying to keep your sanity while shipping something real, then …

**Subscribe** for sharp, tactical, hype-resistant takes on product strategy, AI alignment, and building the bridges no one else sees.

Subscribe

Because someone’s got to build the products and platforms that actually work.  
Might as well be you.

[1](https://deanpeters.substack.com/p/dig-like-an-arms-merchant-deal-like#footnote-anchor-1-161802350)

[A Beginner's Guide To Category Design](https://www.categorypirates.news/p/a-beginners-guide-to-category-design): How To Create A Category For Yourself And Your Business — [Lochhead🏴‍☠️](https://open.substack.com/users/137548733-lochhead?utm_source=mentions)

[2](https://deanpeters.substack.com/p/dig-like-an-arms-merchant-deal-like#footnote-anchor-2-161802350)

[The ultimate guide to A/B testing](https://www.lennysnewsletter.com/p/the-ultimate-guide-to-ab-testing) | [Ronny Kohavi](https://open.substack.com/pub/ronnykohavi) (Airbnb, Microsoft, Amazon) — [Lenny Rachitsky](https://open.substack.com/users/1849774-lenny-rachitsky?utm_source=mentions)