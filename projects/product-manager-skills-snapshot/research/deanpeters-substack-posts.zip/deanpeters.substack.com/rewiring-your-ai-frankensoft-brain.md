# Rewiring your AI Frankensoft Brain

A cautionary tale of building AI Frankensoft: How one PM's retrofit strategy bolted-together a seven-limbed beast that confused customers and killed conversions.

[![**Alt text description:**  A two-tone, vintage-style illustration of a stitched-together AI robot labeled “Frankensoft.” The robot is crudely assembled with visible seams and wires sparking from its joints. Its limbs are labeled: “CHATBOT” (head), “AUTO-COMPLETE” (right arm), “SMART TAGS” (left arm), and “Q3 DEADLINE” (right leg). The title at the top reads “Rewiring Your AI Frankensoft Brain,” and the subtitle at the bottom says “How Smart Organizations Rethink, Instead of Retrofit AI.” The overall style echoes Saul Bass-era film posters, with a flat, bold color palette and distressed textures.](https://substackcdn.com/image/fetch/$s_!aB0x!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe11112fb-ae02-468a-889f-45d315960085_3776x2128.png "**Alt text description:**  A two-tone, vintage-style illustration of a stitched-together AI robot labeled “Frankensoft.” The robot is crudely assembled with visible seams and wires sparking from its joints. Its limbs are labeled: “CHATBOT” (head), “AUTO-COMPLETE” (right arm), “SMART TAGS” (left arm), and “Q3 DEADLINE” (right leg). The title at the top reads “Rewiring Your AI Frankensoft Brain,” and the subtitle at the bottom says “How Smart Organizations Rethink, Instead of Retrofit AI.” The overall style echoes Saul Bass-era film posters, with a flat, bold color palette and distressed textures.")](https://substackcdn.com/image/fetch/$s_!aB0x!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe11112fb-ae02-468a-889f-45d315960085_3776x2128.png)

Don’t let AI FOMO force you into a Frankensoft Feature Factory Frenzy

*Below is the story of Sarah, a Senior AI Product Manager. And the story of how she bolted-together an AI monster that nearly consumed both her and her company.*

I Built My First AI Frankensoft on a Tuesday
--------------------------------------------

*I wish this were fiction. It’s not. Here’s how I stitched and sewn and stapled-together an AI monster.*

The Slack message arrived at 2:47 PM, right as I was finally making progress on our Q3 roadmap.

> *"Sarah, quick question. Can we add AI to the user onboarding flow? Saw a demo at the conference yesterday. Should be straightforward."*

**‘Should’ be straightforward.**

Famous last words from a VP who'd never shipped software but had strong opinions about "*staying competitive.*"

Six months later, I was maintaining seven different AI features that contradicted each other, confused our users, and cost more than our entire customer support team. Our "smart" onboarding flow had a 23% abandonment rate – worse than the "dumb" version it replaced.

I had built a monster. And the worst part? I thought I was being strategic.

---

[![**Alt text description:**  A retro, two-tone illustration shows a corporate meeting gone wrong. On the left, a balding executive confidently presents a glowing tablet with a rising chart, saying, “It should be straightforward.” Behind him is a flip chart with a similar line graph. On the right, a disheartened product manager sits with a coffee mug in hand and a blank, frustrated expression—her hair and chair are literally on fire. The illustration satirizes unrealistic AI expectations and burnout, using a Saul Bass-inspired style with bold lines and distressed textures.](https://substackcdn.com/image/fetch/$s_!7Tpg!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4de3b11f-b72d-4b40-98b5-2864600d7a98_2048x2048.png "**Alt text description:**  A retro, two-tone illustration shows a corporate meeting gone wrong. On the left, a balding executive confidently presents a glowing tablet with a rising chart, saying, “It should be straightforward.” Behind him is a flip chart with a similar line graph. On the right, a disheartened product manager sits with a coffee mug in hand and a blank, frustrated expression—her hair and chair are literally on fire. The illustration satirizes unrealistic AI expectations and burnout, using a Saul Bass-inspired style with bold lines and distressed textures.")](https://substackcdn.com/image/fetch/$s_!7Tpg!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4de3b11f-b72d-4b40-98b5-2864600d7a98_2048x2048.png)

So it begins … “just add AI to what we’ve got” … “should be simple!”

The Seduction Begins
--------------------

It started innocently enough. We had a successful SaaS platform. 50,000+ users. Steady growth. Happy customers who actually paid their bills on time.

Then our biggest competitor launched an "AI-powered" feature that generated massive press coverage. Suddenly, our board meetings shifted from celebrating wins to explaining why we didn't have AI.

*"Everyone's using AI now,"* the CEO said, sliding a TechCrunch article across the conference table. *"We need to catch up."*

**I knew better. Really, I did.**

Ten years of product management had taught me that following competitors rarely creates competitive advantage. But the pressure was real, the timeline was tight, and I convinced myself this would be different.

The fatal mistake came when I asked the wrong question: *"How can we add AI to our product?"* instead of, "***What customer problems could AI uniquely solve?***"

That question set everything in motion. Once you start with "How can we add AI?" you inevitably start retrofitting intelligence onto systems that weren't designed for it.

---

[![**Alt Text:** A retro-style blueprint illustration of an assembly line labeled "AI FEATURES," where mismatched robot parts labeled “Tagging Leg” and “Notification Torso” are being pieced together. A sweating product manager reluctantly stamps the torso with a “SHIPPED” tag while holding a clipboard. Electric sparks fly from the robot, suggesting dysfunction or haste.](https://substackcdn.com/image/fetch/$s_!Xfdu!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff70a6120-1727-4014-8467-c7216507aa8a_2048x2048.png "**Alt Text:** A retro-style blueprint illustration of an assembly line labeled \"AI FEATURES,\" where mismatched robot parts labeled “Tagging Leg” and “Notification Torso” are being pieced together. A sweating product manager reluctantly stamps the torso with a “SHIPPED” tag while holding a clipboard. Electric sparks fly from the robot, suggesting dysfunction or haste.")](https://substackcdn.com/image/fetch/$s_!Xfdu!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff70a6120-1727-4014-8467-c7216507aa8a_2048x2048.png)

Yes, it’s easy to fire up the Frankensoft Feature Factory, but is it good business?

Building the Monster, One Feature at a Time
-------------------------------------------

Our first AI feature seemed harmless: smart auto-complete for user profiles. The engineering team could build it in two weeks. Marketing loved the "AI-powered" messaging. Sales could finally say we had machine learning.

It worked. Sort of. The AI would suggest completions based on similar user profiles. Sometimes it was helpful. Sometimes it suggested that "Sarah Johnson" worked at "Johnson & Johnson" because, well, algorithms aren't great with irony.

But it shipped. Leadership was happy. So we kept going.

Next came "intelligent notifications" – AI that would predict when users needed reminders. Then "smart categorization" that automatically tagged content. Then a chatbot that could answer basic questions.

Each feature worked in isolation. Each one made logical sense. Each one got approved because the last one had shipped successfully.

What I didn't see … what nobody saw … was how these features created a Jekyll and Hyde user experience. The auto-complete AI thought Sarah was a pharmaceutical executive. The notification AI reminded her about software features she'd never used. The categorization AI tagged her content based on the auto-complete assumption. And the chatbot confidently answered questions using data from all three systems.

Users started complaining about the product "feeling weird" and "acting inconsistent." Our cloud costs doubled. Our support tickets tripled. Onboarding completion rates dropped.

We had built a system with seven different AI brains, each one slightly smarter than the last, none of them talking to each other.

[![**Alt text description:**  A minimalist, vintage-style illustration shows a worried-looking man holding a mirror. Reflected back at him is a speech bubble that says, “It feels disconnected.” Above the image, bold text reads “THE CUSTOMER FEEDBACK MIRROR.” The artwork uses a distressed blue-and-beige palette in the style of Saul Bass, capturing the sobering moment when a user surfaces product incoherence caused by poorly integrated AI features.](https://substackcdn.com/image/fetch/$s_!8y7L!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4066bcc2-b89c-476e-9e53-39cb741288d5_2048x2048.png "**Alt text description:**  A minimalist, vintage-style illustration shows a worried-looking man holding a mirror. Reflected back at him is a speech bubble that says, “It feels disconnected.” Above the image, bold text reads “THE CUSTOMER FEEDBACK MIRROR.” The artwork uses a distressed blue-and-beige palette in the style of Saul Bass, capturing the sobering moment when a user surfaces product incoherence caused by poorly integrated AI features.")](https://substackcdn.com/image/fetch/$s_!8y7L!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4066bcc2-b89c-476e-9e53-39cb741288d5_2048x2048.png)

What’s worse than no AI? AI that breaks the customer’s trust!

The Moment of Truth
-------------------

The wake-up call came during a customer interview. I was trying to understand why our new AI features had such low adoption rates.

> *"It feels like the product doesn't know me,"* the customer said. *"Like there are multiple people trying to help me, but they've never met each other. It's confusing. I’m not sure I can trust it."*

That's when it hit me. We hadn't made our product smarter. We had made it schizophrenic.

Each AI feature was optimizing for its own metrics without considering the overall customer experience. The auto-complete wanted higher accuracy. The notifications wanted higher engagement. The categorization wanted better precision. The chatbot wanted faster response times.

Nobody was optimizing for customer value. Nobody was thinking about how these systems worked together. **We had built AI Frankenstack – a collection of intelligent parts that created an unintelligent whole.**

I spent the next three months in what I now call "Frankensoft recovery." Turning off features. Rebuilding workflows. Explaining to leadership why "adding AI" hadn't created the competitive advantage they expected.

It was the most humbling experience of my product career. And the most valuable.

What I Learned About Prevention
-------------------------------

The companies that avoid FOMO-Fueled AI Bolt-On Features (FOMO/FABoF) don't have better AI. They have better questions.

* Instead of *"How can we use AI?"* they ask, "***What customer problems resist traditional solutions?***"
* Instead of measuring AI feature adoption, they measure whether AI changes customer behavior in meaningful ways.
* Instead of treating AI like a feature enhancement project, they treat it like a business model expansion opportunity.

The difference isn't subtle. It's the difference between building intelligence that serves your product strategy and building product features that happen to use AI.

Take Notion's recent AI integration. They didn't add AI to existing features. They identified a specific customer job ("*I want to write better content faster*") and used AI to create an entirely new workflow. The AI isn't bolted onto Notion – it's woven into the experience in a way that makes the whole product more valuable.

That's what I should have built. That's what you should build.

[![Understood. Here's a revised version that lands in the middle—descriptive but concise:  **Alt text:** A person sits at a retro control panel surrounded by five AI-readiness questions, each connected to gauges and charts. Text at the bottom reads: “How Smart Organizations Rethink.” Style matches vintage Saul Bass poster design.](https://substackcdn.com/image/fetch/$s_!MVYZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb07a6627-ca05-40de-b844-9372b1ab3728_2048x2048.png "Understood. Here's a revised version that lands in the middle—descriptive but concise:  **Alt text:** A person sits at a retro control panel surrounded by five AI-readiness questions, each connected to gauges and charts. Text at the bottom reads: “How Smart Organizations Rethink.” Style matches vintage Saul Bass poster design.")](https://substackcdn.com/image/fetch/$s_!MVYZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fb07a6627-ca05-40de-b844-9372b1ab3728_2048x2048.png)

AI offers new opportunities, provided we think differently

The AI Frankensoft Prevention Framework
---------------------------------------

Before you build any AI feature, ask yourself six questions. If you can't answer them clearly, you may find yourself trying to tame a Frankensoft monster of our own making:

1. **What problem does this solve that non-AI solutions can't?**   
   If your answer is "it's smarter" or "it's faster," you're in retrofit territory. AI should unlock new customer value, not just optimize existing workflows.
2. **How does this change what customers can accomplish?**   
   The goal isn't making existing tasks marginally better. It's making impossible tasks possible.
3. **What breaks if the AI breaks?**   
   This reveals whether you've built intelligence as a core system or a decorative feature. If your product works fine when AI is offline, the AI probably isn't creating real value.
4. **Would customers pay specifically for this intelligence?**   
   The ultimate validation. If customers won't pay for the AI capability separately, you may have built expensive complexity instead of valuable intelligence.
5. **How do we measure AI impact on customer outcomes, not AI activity?**   
   Don't track how often people use your AI features. Track how AI changes what they accomplish.
6. **Does this AI decision align with our overall product strategy?**   
   Each AI feature should reinforce your core value proposition, not fragment it.

These aren't just product questions. They're strategic frameworks that force you to think about AI as a business transformation tool, not a feature enhancement kit.

The Choice Every Product Manager Faces
--------------------------------------

Here's what I wish someone had told me on that Tuesday afternoon when the Slack message arrived:

The pressure to "*just add AI*" never stops. Your competitors will ship AI features. Your board will ask why you don't have machine learning. Your sales team will request "something with artificial intelligence" for their demos.

**The temptation to retrofit will always be there because retrofitting feels faster, safer, and more manageable than rethinking your entire approach.**

But companies that rethink create categories. Companies that retrofit create complexity.

The choice isn't whether to use AI. It's whether to use it strategically rather than tactically.

Stop asking how to make your existing product smarter. Start asking what becomes possible when intelligence is built into the foundation instead of bolted onto the surface.

Your customers … and your career … will thank you for it.

[![**Alt text description:**  A stylized, vintage-control-panel illustration poses the question “BUILD OR BOLT?” at the top. A hand hovers over a glowing lever with two labeled options: “RETHINK AI FROM FIRST PRINCIPLES” on the left and “JUST ADD AI FEATURE” on the right. The bolt-on option is surrounded by chaotic sparks and indicators showing mixed results: “SUPPORT COSTS ↓,” “CONVERSION ↓,” and “USED BY COMPETITOR.” The glowing lever implies temptation, while the panel’s design evokes classic cockpit or sci-fi interfaces, rendered in a two-tone Saul Bass-inspired style.](https://substackcdn.com/image/fetch/$s_!IV4-!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faf46c232-efa2-4952-9c88-a24ca619ead1_2048x2048.png "**Alt text description:**  A stylized, vintage-control-panel illustration poses the question “BUILD OR BOLT?” at the top. A hand hovers over a glowing lever with two labeled options: “RETHINK AI FROM FIRST PRINCIPLES” on the left and “JUST ADD AI FEATURE” on the right. The bolt-on option is surrounded by chaotic sparks and indicators showing mixed results: “SUPPORT COSTS ↓,” “CONVERSION ↓,” and “USED BY COMPETITOR.” The glowing lever implies temptation, while the panel’s design evokes classic cockpit or sci-fi interfaces, rendered in a two-tone Saul Bass-inspired style.")](https://substackcdn.com/image/fetch/$s_!IV4-!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faf46c232-efa2-4952-9c88-a24ca619ead1_2048x2048.png)

Yes, adding “yet another chatbot” is expedient, but is it good business?

The monster I built taught me that the most expensive AI isn't the one that fails to launch. It's the one that launches successfully and creates years of customer confusion, technical debt, and strategic drift.

Don't bolt-together my monster. Build something better.

---

[Leave a comment](https://deanpeters.substack.com/p/rewiring-your-ai-frankensoft-brain/comments)

*Got your own Frankensoft war story? Share it in the comments. Therapy is encouraged. Names won’t be changed to protect the innocent.*