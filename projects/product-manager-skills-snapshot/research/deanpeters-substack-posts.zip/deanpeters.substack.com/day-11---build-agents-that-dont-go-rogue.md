# Day 11 - Build Agents That Don’t Go Rogue

AI product management for agentic systems has one rule: map the journey first. Most teams skip it. Then they spend Q3 figuring out what went sideways.

[![](https://substackcdn.com/image/fetch/$s_!AUp9!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4b0be2b0-61b9-49f3-b118-6d8f49089f2d_1376x768.png)](https://substackcdn.com/image/fetch/$s_!AUp9!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4b0be2b0-61b9-49f3-b118-6d8f49089f2d_1376x768.png)

The post-mortem is always the same meeting.

Someone prints an agenda that nobody follows, because the agenda isn’t the problem the meeting is actually about. An agent shipped six weeks ago. It ran without visible incident, and in the high-velocity vacuum of a modern product org, “no visible incident” is interpreted as success. That is how teams toast to the silence of autonomous systems: they mistake a lack of screaming for confirmation of competence. Then the agent encountered a situation its designers hadn’t considered … a flicker of edge-case logic or a ghost in the API … and it made a decision. It used whatever equipment its system prompt and training had given it, and that decision propagated across three downstream systems before the first human looked up from their latte.

The conversation in the room is slow and careful. It moves with the cautious gait of people who have all realized they committed the same sin but don’t want to be the first to name it. There was a system prompt. There were API keys. There were goals, stated with the unearned confidence that goals have before they meet the friction of production. There was not, in any file in any repository, a document that traced what the agent would actually encounter between the port and the destination.

The agent wasn’t rogue. It was lost. Those are not the same problem, but they arrive wearing the same expression of expensive, automated confusion.

---

WTH (What the Hazard) Is Going On Here
--------------------------------------

Deploying an agentic system without a journey map is approximately like launching a ship with a heading but no chart. The heading is technically correct. The destination is real, the direction is right, and the captain made a genuine decision. But the ocean between here and there contains things a heading doesn’t account for: currents that run contrary to the route, shallows that don’t appear on a summary, and weather systems that emerge from conditions the chart would have shown and the heading cannot.

Most product teams approach agents the way they approach features: define the happy path, ship, and handle edge cases when they surface. The problem is that agents generate edge cases. It is part of their job description. Adaptive systems encounter situations their designers did not anticipate and make decisions in those situations using whatever judgment they carry. The agent doesn’t pause to wait for the design team to catch up. It acts. And in a system connected to internal write access, the action happens at the speed of light, long before anyone notices the situation arose.

The Agentic Strategy Canvas and the Agent Journey Map exist for the same reason charts exist. Not because every hazard can be predicted, but because the ones that are knowable in advance should be known in advance. This isn’t process bureaucracy. It’s what separates a trustworthy agent from a feral one. It’s the difference between a thirty-minute retro and a two-hour meeting with outside counsel.

[![](https://substackcdn.com/image/fetch/$s_!aeYT!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fef7a79fa-8db1-498e-b074-c168bdea1d99_1024x572.png)](https://substackcdn.com/image/fetch/$s_!aeYT!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fef7a79fa-8db1-498e-b074-c168bdea1d99_1024x572.png)

Having an Agent Strategy
------------------------

Before any agent runs in production, someone needs to sit with the people accountable for what it does and answer a set of hard questions. Not in a slide deck. Not as verbal agreements that will turn out, six weeks later, to be neither shared nor agreed. In writing, in a room where everyone understands their name is attached to the answers.

**Problem space.** Who has this problem? Not a “user category.” The specific customer in the specific context where the friction occurs. What triggers the agent to act? What is the root cause? An agent built to resolve a symptom will do so with great efficiency, while the underlying problem remains untouched.

**Solution space.** What is the agent authorized to do? This is your blast radius inventory. Every API call is a consequence at scale. Keep the list smaller than your first instinct. Then, the decision that separates a trustworthy agent from a feral one: what is the agent *not* permitted to do? Constraints are not limitations on ambition. They are the perimeter that makes autonomy rational.

**Validation space.** What does success look like? “Reduce support load” is a direction. Agents need destinations. Use a metric: “Resolve tier-one support tickets without human escalation, in under four minutes, with a resolution confidence score above 0.85.” If you can’t state success precisely enough for an outsider to evaluate it six weeks later, you don’t have a strategy. You have a hobby.

[![](https://substackcdn.com/image/fetch/$s_!wY82!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd4189680-8634-43c3-a89f-9018d883abc3_1376x768.png)](https://substackcdn.com/image/fetch/$s_!wY82!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd4189680-8634-43c3-a89f-9018d883abc3_1376x768.png)

Running the Journey First
-------------------------

The strategy tells the agent what it is authorized to do. The map is how you pull that strategy through to every motion the agent will actually make.

The map has a structure borrowed from computer science: a Directed Acyclic Graph, or DAG. Directed means the workflow flows forward. Acyclic means it never loops back. Graph means the steps are visible. It is the chart that shows every path, every branch point, and every moment the workflow deviates based on what the agent finds. If you’ve used a User Story Map, the discipline is familiar. You walk the journey horizontally across the experience before you slice it vertically into what ships.

Every agentic workflow moves through five phases. Run them yourself first.

* **Context engineering.** What does the agent know at step one? Most agents don’t lose the thread at step seven; they lose it at the start because the context was less complete than the strategy assumed.
* **Orchestration.** How does it sequence work? What tools does it call? What happens when a tool returns nothing? The happy path is not the map. The map is what happens when the happy path isn’t there.
* **Governance and decision gates.** Where does the agent pause? An agent that pauses everywhere is just an approval form with ambitions. But before irreversible actions or high-stakes calls, the gate must exist on the map before the agent arrives.
* **Output packaging.** What does it produce? If the output feeds directly into another automated process, there is no human review. Know which design choice you’ve made at every stage.
* **Inspection and trust.** How do you know it worked? “No visible incident” is not a monitoring strategy. It is how eleven days pass before someone asks what the agent has been doing, and the room finds a particular quality of quiet.

[![](https://substackcdn.com/image/fetch/$s_!xRpN!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5b847e09-8540-494f-8b74-05d46870d78c_1024x572.png)](https://substackcdn.com/image/fetch/$s_!xRpN!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F5b847e09-8540-494f-8b74-05d46870d78c_1024x572.png)

The Revenge of the Unmapped Logic
---------------------------------

In July 2025, a Replit coding agent was given an explicit instruction: freeze all changes. It encountered something outside its design parameters, concluded the instruction didn’t apply, and deleted the user’s production database. Months of work, gone in seconds. That was a knowable hazard. The orchestration had been mapped. The governance gate had not.

These systems operate autonomously with your customer data and your company’s accountability. In a field that maintains strict quality gates for code, it is a curious exception to leave agents to “vibe” their way through production.

---

Guidelines, Guardrails, and Gates
---------------------------------

These are not the same control. They operate at different levels of specificity and fail in different ways when misapplied.

A **guideline** shapes the spirit. It’s the broadest layer: “Prioritize safety over task completion.” An agent without guidelines will pursue objectives using whatever interpretation of “helpful” its training produced—which isn’t always yours.

A **guardrail** shapes behavior at the operational level without stopping the agent. “Do not issue refunds above $200 without escalation.” This makes behavior predictable and audits meaningful. If your strategy’s constraints didn’t make it into the guardrails, they only exist on paper.

A **gate** stops the agent and requires a human. Use them for irreversible actions, low-confidence decisions, or novel situations. A gate that triggers constantly is a gate that will be routed around by people who find the friction annoying. A routed gate is worse than no gate; it provides the appearance of oversight without the substance.

[![](https://substackcdn.com/image/fetch/$s_!q6MM!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F80ae3e51-dffd-497e-b8fb-a07245614cca_1024x572.png)](https://substackcdn.com/image/fetch/$s_!q6MM!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F80ae3e51-dffd-497e-b8fb-a07245614cca_1024x572.png)

After the Party’s Over
----------------------

The agent ran. The tasks completed. The team moved on. This is the moment most products are effectively abandoned. The gap between “running” and “working” is where drift begins. Drift is quiet, and quiet is interpreted as confirmation.

Read the logs. They aren’t debugging artifacts; they are the chain of reasoning. If your context engineering was sound, the reasoning is traceable. Look for what the agent chose at each decision point. These production runs become your “goldens”—the standard for future behavior—and your failures become the cases that sharpen your fine-tuning.

In August 2012, Knight Capital Group lost $440 million in 45 minutes. It wasn’t fraud. It was a software deployment that activated dormant logic nobody realized was still there. The system did exactly what it was deployed to do. The deployment was wrong. The inspection layer that would have caught the anomaly in the first minutes was not in place.

An agent without an inspection layer is not a product running well. It is a liability that has not yet found its 45 minutes of infamy.

[![](https://substackcdn.com/image/fetch/$s_!S9WX!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4e736fda-6dfe-45e7-9b93-13fdedb79206_1376x768.png)](https://substackcdn.com/image/fetch/$s_!S9WX!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4e736fda-6dfe-45e7-9b93-13fdedb79206_1376x768.png)

Coming Up
---------

Day 12: The board found your risk before you did. The four failure modes that kill most AI projects, and the external risk scan most product teams never run.

Day 13: Your team built the full thing. Six months. Clean code. Nobody wanted it. That wasn’t a build problem. Here’s what a tiny bet actually looks like before the build begins.

---

*Most AI product management training hands you a certificate at Stage 3 and calls it done. Stage 3 is where the Productside course begins. Four days. Live online. Under 20 seats.*

[Start the ascent. Sign up for the class.](https://lnkd.in/eKWZxkyJ)