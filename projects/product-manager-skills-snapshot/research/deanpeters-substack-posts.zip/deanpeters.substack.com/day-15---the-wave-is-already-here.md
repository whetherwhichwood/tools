# Day 15 - The Wave Is Already Here

AI product management is defining who leads and who follows for the next decade. You’ve had 15 days. The ones who act on it win. Time to decide.

[![](https://substackcdn.com/image/fetch/$s_!Shgw!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F582f82aa-5549-4413-927a-bae9cb397b0c_2754x1536.png)](https://substackcdn.com/image/fetch/$s_!Shgw!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F582f82aa-5549-4413-927a-bae9cb397b0c_2754x1536.png)

Hokusai painted *The Great Wave* in 1831. What he painted was not a catastrophe. It was the moment before: the boats still on the surface, the wave fully formed and arching overhead, the mountain in the background patient and permanent and entirely unconcerned with what happens next. The fishermen in the boats are not panicking. They are not debating whether the wave is real. They are paddling, which is the only response to a fully formed wave that contains any useful information about the outcome.

The AI wave is fully formed. The fishermen still debating whether it exists are the ones who will discover it retrospectively. They will see it in the postmortem. They will see it in the meeting that tries to explain what happened between Q1 and Q4 when the competitive gap finally showed up on the charts.

**The only remaining question is what you do with your paddle.**

[![](https://substackcdn.com/image/fetch/$s_!aHn8!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbb3079dd-4cf7-41c3-a0fd-413e03b4cadf_1341x574.png)](https://substackcdn.com/image/fetch/$s_!aHn8!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbb3079dd-4cf7-41c3-a0fd-413e03b4cadf_1341x574.png)

WTH (What the Halibut) Is Going On Here
---------------------------------------

Fifteen articles. Fifteen H-words. Each one named something the field was carrying around without language for it.

What the Heck started the series in the only place it could start: with the question nobody had answered. What the Hubris named the gap between the title and the discipline. What the Haste explained what AI amplifies when you skip the most important step. What the Hallucination caught the prayer masquerading as a prompt. What the Hoarding named the anxiety disguised as thoroughness. What the Fabrication caught the customer pain point nobody actually has. What the Haphazard named the product team that picked its playing field the way a group of eight people picks a restaurant. What the Hack called out the dotted lines on the whiteboard. What the Hogwash called the data pile a strategy and watched it nod in agreement. What the Havoc named the agent running in production that nobody could describe. What the Hazard traced the journey before the ship left port. What the Horizon found the storm before it found the project. What the Heroics named the six-month build nobody validated. What the Hockey Stick named the slide that ends careers.

And now: **What the Halibut.**

The halibut is a flatfish. It spends its life on the ocean floor, eyes migrated to one side of its head during development. It is a creature that began as one thing and became something else through the ordinary pressure of adapting to the environment it actually lives in. This is not a parable about transformation as aspiration. It is a description of what adaptation looks like when it is not optional: gradual, structural, permanent, and entirely unremarkable to the organism that has completed it.

The PM who started reading this series at Stage 2 is now at Stage 3. Or further, depending on what they did with the fourteen days before this one. **The adaptation is the job.** The wave does not wait for the adaptation to feel comfortable.

[![](https://substackcdn.com/image/fetch/$s_!BSqJ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fea83327f-a503-4bba-8367-92ffaf3018df_1342x667.png)](https://substackcdn.com/image/fetch/$s_!BSqJ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fea83327f-a503-4bba-8367-92ffaf3018df_1342x667.png)

The Data Is Already In
----------------------

Stop worrying about whether AI will replace you. It is a waste of metabolic energy. The role of the AI product manager has already been dismantled and reassembled while you were checking your sprint velocity.

The research is no longer speculative. A 2025 arXiv study on how PMs delegate work to generative AI found the role is already shifting from artifact production toward orchestration, judgment, and accountability. The work is moving up a layer. Less typing. More governing. Less document worship. More socio-technical choreography.

If you are waiting for a memo that officially changes your job description, you have missed the point. **The role changed the moment the first token entered your workflow.** You are now a designer of business impact who happens to use software to deliver it.

Hope is not a strategy. Neither is nostalgia.

[![](https://substackcdn.com/image/fetch/$s_!6WNB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0c14bdc0-f734-4b6a-831a-c8d2e2b1292c_1350x655.png)](https://substackcdn.com/image/fetch/$s_!6WNB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0c14bdc0-f734-4b6a-831a-c8d2e2b1292c_1350x655.png)

The Arc
-------

**[Day 01](https://open.substack.com/pub/deanpeters/p/day-01-wth-is-ai-product-management?r=3jxqq&utm_campaign=post&utm_medium=web)** said the game changed. Most people are still playing the old one, and the scoreboard does not consult their self-assessment.

**[Day 02](https://open.substack.com/pub/deanpeters/p/day-02-the-ai-pm-skills-nobody-teaches?r=3jxqq&utm_campaign=post&utm_medium=web)** named the five gaps. The ones hiding behind the busy calendar, the prompt library, and the imposter syndrome that hadn’t been named yet.

**[Day 03](https://open.substack.com/pub/deanpeters/p/day-03-stop-solving-the-wrong-problem?r=3jxqq&utm_campaign=post&utm_medium=web)** said AI amplifies whatever you point it at. Including the wrong problem, at scale, with better formatting and a faster release cycle.

**[Day 04](https://open.substack.com/pub/deanpeters/p/day-04-stop-prompting-like-a-tourist?r=3jxqq&utm_campaign=post&utm_medium=web)** said the prompt is not a prayer. It is standing guidance the system will follow until you replace it. You are paying for the guesses.

**[Day 05](https://open.substack.com/pub/deanpeters/p/day-05-context-engineering-is-a-team?r=3jxqq&utm_campaign=post&utm_medium=web)** said context is not more information. It is shared guidance. Without it you don’t have AI adoption. You have parallel experiments calling themselves a strategy.

**[Day 06](https://open.substack.com/pub/deanpeters/p/day-06-the-customer-signals-ai-gets-wrong?r=3jxqq&utm_campaign=post&utm_medium=web)** said clean output is not validated output. The hallucination risk lives inside the research report.

**[Day 07](https://open.substack.com/pub/deanpeters/p/day-07-youre-playing-the-wrong-ai-game?r=3jxqq&utm_campaign=post&utm_medium=web)** said there are four playing fields and most teams are on the wrong one. This is a decision made in a conversation nobody thought to have before the build began.

**[Day 08](https://open.substack.com/pub/deanpeters/p/day-08-accidental-ai-vs-ai-first?r=3jxqq&utm_campaign=post&utm_medium=web)** said the dotted lines on the whiteboard are not a strategy. The market, when it arrives, will have opinions.

**[Day 09](https://open.substack.com/pub/deanpeters/p/day-09-more-data-wont-save-you?r=3jxqq&utm_campaign=post&utm_medium=web)** said you cannot volume your way out of a data quality problem. You can only scale it.

**[Day 10](https://open.substack.com/pub/deanpeters/p/day-09-more-data-wont-save-you?r=3jxqq&utm_campaign=post&utm_medium=web)** said the agent running for eleven days without monitoring is not bold. It is a liability with a demo that worked in the happy path.

**[Day 11](https://open.substack.com/pub/deanpeters/p/day-11-build-agents-that-dont-go?r=3jxqq&utm_campaign=post&utm_medium=web)** said the agent wasn’t rogue. It was lost. Those are not the same problem.

**[Day 12](https://open.substack.com/pub/deanpeters/p/day-12-de-risk-your-ai-before-the?r=3jxqq&utm_campaign=post&utm_medium=web)** said the risk was visible in week one. The board found it in month four.

**[Day 13](https://open.substack.com/pub/deanpeters/p/day-13-tiny-bets-beat-titanic-assumptions?r=3jxqq&utm_campaign=post&utm_medium=web)** said the team executed well. That was the problem. The Titanic was also a remarkable engineering achievement.

**[Day 14](https://open.substack.com/pub/deanpeters/p/day-14-your-cfo-aint-buying-it?r=3jxqq&utm_campaign=post&utm_medium=web)** said the CFO has one question, and the hockey stick is not an answer to it.

This is the arc: fluency, then craft, then strategy, then execution, then business case. Each stage requires the one before it. The PMs who are winning are not smarter than the ones who aren’t.

**They built the arc in the right order.**

[![](https://substackcdn.com/image/fetch/$s_!lOXb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F04f726fc-af46-4083-80b0-ce0df2691f11_1339x733.png)](https://substackcdn.com/image/fetch/$s_!lOXb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F04f726fc-af46-4083-80b0-ce0df2691f11_1339x733.png)

The Efficiency Trap
-------------------

Productside has trained thousands of product managers, and more recentlhy, hundreds in the area of AI product management. The number is not the interesting thing. The pattern is.

The PMs who went through the AI training and reported meaningful career outcomes shared a trait: many started at Stage 2 or Stage 3. That is exactly where the Efficiency Trap lives. It is invisible. It is comfortable. It feels very much like progress.

The trap is invisible because it feels like competence. You can draft faster. Summarize faster. Prototype faster. You feel sharper because the machine is making you faster. Then you walk into a room that requires judgment, economics, risk fluency, and strategic sequencing, and suddenly the speed evaporates like gin in August.

**Activity is not a KPI.**

The PMs who didn’t close the gap are still at Stage 3. The gap between Stage 3 and Stage 5 is not a gap in talent. It is a gap in frameworks, practice, and the willingness to treat AI product management as a discipline with a curriculum rather than a set of tools with a learning curve.

That is the part organizations keep trying to skip. And for the love of all that is holy, they keep acting surprised when the skipping part becomes the expensive part.

[![](https://substackcdn.com/image/fetch/$s_!C_tg!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F07502fe1-a5bb-4727-936f-e49bb4177d20_1340x562.png)](https://substackcdn.com/image/fetch/$s_!C_tg!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F07502fe1-a5bb-4727-936f-e49bb4177d20_1340x562.png)

The Decision
------------

One decision separates the PMs who lead AI from the ones who spend the next two years catching up.

The wave Hokusai painted in 1831 is not waiting for the boats to finish deciding. The mountain in the background is patient. The wave is not. The fishermen still afloat are the ones with paddles moving. Not because they control the sea. Because they understand the moment they are in.

The ascent from Stage 3 to Stage 5 is four days. Live online. Under 20 seats. Led by people who built the curriculum around what those rooms actually require.

Fifteen days. The wave is already here.

There is one more H-word. It was behind every one of them.

Hakawati.

The hakawati is the storyteller, the one who carries truth in through the side door while everyone thinks they came for the entertainment. The truth wrapped in a good story travels further. It lands in a different part of the body than the truth delivered as a report.

That is what this has been. Fifteen days. One hakawati. One long look at the sea before it breaks over the bow.

**The wave is already here. Paddle or become a case study.**

[![](https://substackcdn.com/image/fetch/$s_!mmxI!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6d01d6d4-5610-4782-a416-6a9756660e02_1344x664.png)](https://substackcdn.com/image/fetch/$s_!mmxI!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6d01d6d4-5610-4782-a416-6a9756660e02_1344x664.png)

**Your turn.**
--------------

*Most AI product management training considers Stage 3 the finish line. The Productside course considers it the starting line. Four days. Live online. Under 20 seats. Certification at the summit.*

[Start the ascent. Sign up for the class.](https://lnkd.in/eKWZxkyJ)