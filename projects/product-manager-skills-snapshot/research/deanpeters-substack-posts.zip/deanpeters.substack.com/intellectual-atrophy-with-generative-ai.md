# Intellectual Atrophy with Generative AI

**At first, we laughed when AI hallucinated. Now we ask it to think for us.** What began as a party trick has become a prosthetic for cognition—a frictionless, context-free oracle that never sleeps, never doubts, and never makes you work too hard for an answer. But here's the rub: every time you click “regenerate,” a tiny piece of your intellectual muscle quietly withers.

[![In a future where the prompt replaces the premise, and completion supplants contemplation, the only thing more efficient than the machine is the mind it no longer needs to replace.](https://substackcdn.com/image/fetch/$s_!8aN7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc83b26ab-e166-4e34-aa93-7fec4e5c0042_1668x848.png "In a future where the prompt replaces the premise, and completion supplants contemplation, the only thing more efficient than the machine is the mind it no longer needs to replace.")](https://substackcdn.com/image/fetch/$s_!8aN7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc83b26ab-e166-4e34-aa93-7fec4e5c0042_1668x848.png)

At first, we laughed when AI hallucinated. Now we ask it to think for us.

The Evidence of Atrophy
-----------------------

If this sounds alarmist, good. The data’s already rolling in, and it's not just coming from tin-foil hat Twitter. Brains are getting flabby, and we’ve got the receipts.

**Ethan Mollick**, Wharton professor and one of AI’s most forward-thinking voices, put it bluntly:

> *“As soon as the AI model is good enough, everyone tends to fall asleep at the wheel. They stop paying attention to what the AI can do and can’t do, and they don’t check the results.”*  
> — Ethan Mollick, July 2024, [MIT Sloan School](https://mitsloan.mit.edu/ideas-made-to-matter/how-to-tap-ais-potential-while-avoiding-its-pitfalls-workplace)

Mollick’s not alone. The research is piling up like unread Terms of Service agreements—only this time, they all say the same thing: your brain's on cruise control, and nobody’s watching the road.

* **Microsoft & Carnegie Mellon (2025):** Found that workers who most trusted GenAI tools were *least* likely to question the output. Over time, they stopped evaluating, analyzing, or correcting. They just accepted. — [LiveScience summary](https://www.livescience.com/technology/artificial-intelligence/using-ai-reduces-your-critical-thinking-skills-microsoft-study-warns)
* **SBS Swiss Business School (2025):** Reported a **-0.75 correlation** between AI reliance and critical thinking skills. Frequent users admitted a creeping sense of mental dependency. — [Phys.org coverage](https://phys.org/news/2025-01-ai-linked-eroding-critical-skills.html)
* **King’s College London (2024):** Longitudinal studies showed that students using AI for weeks at a time began to *lose higher-order thinking skills* unless guided by intentional scaffolding. — [Study PDF](https://kclpure.kcl.ac.uk/portal/files/317698194/gonsalves-2024-generative-ai-s-impact-on-critical-thinking-revisiting-bloom-s-taxonomy.pdf)

The technical term for this trend? **Cognitive offloading.** First you hand off the task. Then the problem. Then the thinking. And before long, it’s not just the work you’ve outsourced—it’s your judgment.

[![**Alt text:** Illustrated book cover featuring a smiling sloth hanging from a tree branch beneath the title “Intellectual Atrophy with Generative AI – Outsourcing One's Mind One Prompt at a Time,” authored by Aldous Huxley as part of the satirical series “Dystopian AI for Product Managers.”](https://substackcdn.com/image/fetch/$s_!pzP7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F789c92a1-caf4-4a8d-9a54-07cac2534ef3_2480x3508.png "**Alt text:** Illustrated book cover featuring a smiling sloth hanging from a tree branch beneath the title “Intellectual Atrophy with Generative AI – Outsourcing One's Mind One Prompt at a Time,” authored by Aldous Huxley as part of the satirical series “Dystopian AI for Product Managers.”")](https://substackcdn.com/image/fetch/$s_!pzP7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F789c92a1-caf4-4a8d-9a54-07cac2534ef3_2480x3508.png)

The future is sluggish—not because the AI is slow, but because we stopped thinking.

---

How to Avoid Becoming the Prompt Sloth
--------------------------------------

There’s using AI to go faster—and then there’s letting it spoon-feed your roadmap. If your strategy reads like a dump of autocomplete suggestions, you’re not leading. You’re the sticky note clinging to a Jira board, praying motion gets mistaken for insight.

Here’s how to stop that slide:

* **Start with your own brain.** If you can’t sketch the outline before prompting, you’re not accelerating work—you’re outsourcing thought.
* **Socratify the damn thing.** Use chain-of-thought. Dig past surface-level output. Keep asking. Follow the logic. One-shot prompts make one-dimensional thinkers.
* **Prompt for pushback, not praise.** Ask the model where your strategy breaks, not how to make it prettier.
* **Kickstart, don’t replace collaboration.** Use templates (JTBD, OST, positioning) to get conversations started—not to skip your team.
* **Rewrite what matters.** Strategic, public-facing, or high-risk work needs your voice. If it doesn’t make you sweat, it won’t make them care.
* **Keep Calm and Focus on the Problem Space.** AI wants to build. You need to think. It outputs codes by default—you frame outcomes.

### TL;DR

AI tools make it trivial to bypass the very assignments that build foundational skills. The risk isn’t that AI is too smart—it’s that we’ll stop bothering to be. Put another way…

> *“Technological progress has merely provided us with more efficient means for going backwards.”* — Aldous Huxley, 1956, “[Adonis and the Alphabet](https://archive.org/details/in.ernet.dli.2015.127899/page/n171/mode/2up)”

Check Yourself Before You Wreck
-------------------------------

The machines aren’t stealing your job. They’re waiting for you to give it away.

**Aldous Huxley didn’t warn us about censorship—he warned us about comfort.** That we’d trade curiosity for convenience. Depth for dopamine. Thinking for tapping.

If you want to stay sharp, start here:

> • Can you explain the problem without reading the prompt history?
>
> • Would you put your name on this idea without the AI draft?
>
> • Did you *think*, or did you just *query*?

If the answer makes you squirm, good. That’s your brain waking up again.

**The future won’t be won by the fastest prompt. It’ll be won by the clearest thought.** Don’t let the tool think for you. Make it think *with* you.

Because if you don’t check yourself… Well, you know the rest.

---

### Additional Reading

[![](https://substackcdn.com/image/fetch/$s_!T5OZ!,w_56,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F488b0226-5e6c-447a-b644-4c20a1c648cf_500x500.png)Purplemind

🧠 Why "AI Productivity Hacks" Are Making You Dumber

🤯 The Uncomfortable Truth Everyone's Ignoring…

Read more

9 months ago · 2 likes · 2 comments · Mike Thomson](https://ceators.substack.com/p/why-ai-productivity-hacks-are-making?utm_source=substack&utm_campaign=post_embed&utm_medium=web)

---

### **Want to stay human in the loop?**

Start by leaving a thoughtful comment—something that didn’t come from a chatbot.

[Leave a comment](https://deanpeters.substack.com/p/intellectual-atrophy-with-generative-ai/comments)

Then subscribe if you're not afraid to think without autocomplete.

Subscribe