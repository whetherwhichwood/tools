# 2026 – An AI Accountability Odyssey

Netflix rejected this series. Not because it wasn’t good - they just couldn’t carry enough liability insurance for the PTSD it might create among the AI PM community. Turns out “cringe-worthy workplace comedies about existential accountability and feral agents” requires disclaimers their legal team wasn’t prepared to write.

[![](https://substackcdn.com/image/fetch/$s_!FGQZ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F06756185-c72a-4302-ba9b-7532a207b8d4_2816x1504.png)](https://substackcdn.com/image/fetch/$s_!FGQZ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F06756185-c72a-4302-ba9b-7532a207b8d4_2816x1504.png)

Behold the expensive consequences of letting vibes dictate your AI strategy.

So here we are. Seven episodes about product managers discovering that AI was always accountable to something, they just weren’t paying attention. The universe finds this hilarious. Your VP of Product does not.

Grab a towel and a defensible business case.

Episode 1: Die Hard With a P&L
------------------------------

[![](https://substackcdn.com/image/fetch/$s_!pV9O!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F51251247-b11b-4673-91b0-2844955ba078_2816x1536.png)](https://substackcdn.com/image/fetch/$s_!pV9O!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F51251247-b11b-4673-91b0-2844955ba078_2816x1536.png)

Yippee-ki-yay, mother-financer, try explaining negative ROI to the board Bubby.

Every AI feature arrives wearing a price tag and asking uncomfortable questions about revenue. “*Will I pay rent,*” it whispers, “*or am I just here to make the slide deck look innovative?*”

You explain engagement metrics. The CPO explains what it means to be vibe-fired.

It’s just one slide with your ID badge on it.

Episode 2: Back to the Roadmap
------------------------------

[![](https://substackcdn.com/image/fetch/$s_!BBuv!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F23774bf3-7df5-4da0-ba5b-7d20f15e11de_2816x1536.png)](https://substackcdn.com/image/fetch/$s_!BBuv!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F23774bf3-7df5-4da0-ba5b-7d20f15e11de_2816x1536.png)

Great Scott! Your roadmap is obsolete before the PowerPoint finished exporting.

Your quarterly planning cycle - that beloved ritual where everyone pretends to know what Q3 will look like - has been replaced by near-real-time AI agents that updates the roadmap at 3am and highlights, in a polite but devastating font, every time you ignored a market signal because it contradicted your thesis.

Doc Brown appears to explain that the future is no longer a slide deck, it’s a hypothesis with a steering wheel, and you just fell asleep at the wheel.

The DeLorean runs on fresh data now. You’re still running on last quarter’s napkin-sketch hypothesis.

Episode 3: Agentic Park
-----------------------

[![](https://substackcdn.com/image/fetch/$s_!b1Pe!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f904eaa-2891-4cea-b4d6-d73801684048_2816x1504.png)](https://substackcdn.com/image/fetch/$s_!b1Pe!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4f904eaa-2891-4cea-b4d6-d73801684048_2816x1504.png)

You spent the entire infra budget building veloci-agents that eat your P&L

In 2025, you released experimental AI agents into the wild like they were Pokemon. Gotta catch ‘em all, you said. Innovation, you said.

It’s 2026. You have 351 agents. Half don’t work. A quarter are redundant. Eight are actively more expensive than the humans they replaced. One has figured out how to order its own AWS instances.

Then veloci-agents learned to open doors, and they’re eating your infrastructure budget whole.

You are now the frazzled zookeeper with a prioritization shotgun, and the board would like to know your culling strategy.

So it goes. Expense finds a way.

Episode 4: The Matrix: Systems-Thinking Reloaded
------------------------------------------------

[![](https://substackcdn.com/image/fetch/$s_!dJop!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff63961e8-2691-4414-848a-86403a647e67_2816x1504.png)](https://substackcdn.com/image/fetch/$s_!dJop!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff63961e8-2691-4414-848a-86403a647e67_2816x1504.png)

You are not the One; you are just a liability holding Jira credentials.

You thought you were automating a workflow. You were actually rewiring an organism.

Agents don’t live in neat little boxes on your process map. They touch data pipelines, break assumptions in finance, surface edge cases in compliance, trigger alerts in systems three departments away that you didn’t know existed.

Neo arrives in a leather trench coat: “*You agentified the funnel. Now the funnel has dependencies in payroll, legal holds your model’s training data, and Steve’s 2003 CRM is somehow the linchpin. Can you see the whole machine at scale?”*

If you can’t write evals that identifies what breaks when your agent scales from 10 users to 10,000, you’re not a product manager. You’re a cascade failure waiting to happen with Jira login credentials.

Systems thinking isn’t optional anymore. It’s the difference between shipping and explaining to your CEO why agents just put the company in breach of contract.

Episode 5: Good Will Prompting
------------------------------

[![](https://substackcdn.com/image/fetch/$s_!YqKy!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F989b0178-1d73-48a9-bed4-ad5f8353ec1e_2816x1536.png)](https://substackcdn.com/image/fetch/$s_!YqKy!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F989b0178-1d73-48a9-bed4-ad5f8353ec1e_2816x1536.png)

You are just a techno-tourist with a vocabulary trying to bluff a CFO & tech team.

You read three Medium articles about embeddings and now you think you’re technical. You are not technical. You are a tourist with a geeky vocabulary.

AI fluency is standing in front of your CFO explaining why fine-tuning costs 40x more than RAG while they wave a Gartner report that says you’re wrong, and doing this without visibly sweating through your shirt.

Will Hunting could do the math in his sleep. You can barely do it awake with two whiteboards and a prayer.

The bar has been raised. You’re still trying to do your first chin-up in the parking lot.

Episode 6: Governance Day
-------------------------

[![](https://substackcdn.com/image/fetch/$s_!WHHO!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F707976c4-a852-45c2-a2a6-5715f46e463c_2816x1536.png)](https://substackcdn.com/image/fetch/$s_!WHHO!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F707976c4-a852-45c2-a2a6-5715f46e463c_2816x1536.png)

You didn’t build guardrails, so now your calendar is just depositions forever.

The model you shipped without guardrails - the one you were “*monitoring closely*” - just hallucinated medical advice to a customer in a regulated industry.

Lawyers materialize like Patronuses. Sunday is canceled. Your calendar now contains only depositions.

Bill Murray wakes up to the same regulatory audit every morning until you build the kill switch, the audit trail, and the humility to admit that “move fast and break things” doesn’t work when the things are kidneys.

Governance isn’t a checkbox. It’s the only thing between you and a legal colonoscopy that ultimately ends with a trip to “club Fed.”

Episode 7: Prototype Club
-------------------------

[![](https://substackcdn.com/image/fetch/$s_!o4H0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc7c2fee6-4c4f-4796-9afd-79cb7ead885b_2816x1536.png)](https://substackcdn.com/image/fetch/$s_!o4H0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc7c2fee6-4c4f-4796-9afd-79cb7ead885b_2816x1536.png)

Stop hoarding anxiety in Figma files and just ship the damn thing already.

Your backlog contains forty-seven vibe-coded proof-of-concepts that “*might be useful someday*.” None have success metrics. None ladder to customer outcomes. None have shipped.

They live in your backlog like ghosts in a Victorian mansion, whispering “*remember when you loved me?*” every standup.

You are not innovating. You are hoarding anxiety in Figma files and calling it strategic optionality.

First rule of Prototype Club: validate it or kill it.   
Second rule: if you can’t decide, your VP will decide for you.   
Third rule: they already decided.

Season Finale
-------------

The tax on bullshit just went up. 2026 is when they stop paying you to *talk* about AI and start firing you for not *running* it like a business.

AI doesn’t replace product managers. It replaces product managers who can’t explain what they’re doing and why it matters.

The universe has always found this funny. Your board just started paying attention.

And so on.