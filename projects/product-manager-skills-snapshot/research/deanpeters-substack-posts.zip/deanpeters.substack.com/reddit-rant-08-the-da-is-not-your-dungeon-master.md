# Reddit Rant 08: The DA Is Not Your Dungeon Master

What I wanted to say on Reddit, but couldn’t. A no-holds-barred take on why data gatekeeping is killing product momentum.

[![A searing orange circle frames the scene: on one side, a wide-eyed Product Manager clutches a scroll labeled “Hypothesis” and a crumpled “Roadmap”, clearly wondering if this is a status update or a side quest. On the other side, a grinning wizard—played by none other than the Reddit mascot—holds aloft a glowing d20 die, casting SQL spells from a terminal that reads SELECT * FROM wisdom. It's playful. It's absurd. It's painfully rea](https://substackcdn.com/image/fetch/$s_!Myvb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc68615d8-6a05-4624-8aef-483e1a4409c0_3072x2048.png "A searing orange circle frames the scene: on one side, a wide-eyed Product Manager clutches a scroll labeled “Hypothesis” and a crumpled “Roadmap”, clearly wondering if this is a status update or a side quest. On the other side, a grinning wizard—played by none other than the Reddit mascot—holds aloft a glowing d20 die, casting SQL spells from a terminal that reads SELECT * FROM wisdom. It's playful. It's absurd. It's painfully rea")](https://substackcdn.com/image/fetch/$s_!Myvb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc68615d8-6a05-4624-8aef-483e1a4409c0_3072x2048.png)

This badge commemorates the moment every product leader realizes: you’re not here to pass a data gauntlet—you’re here to make *bets* that move the business forward.

I’ve been slumming around Reddit lately. Lurking in the shadows of [r/ProductManagement](https://www.reddit.com/r/ProductManagement/), dodging the “*should I use Scrum or Kanban*” debates, when I stumbled on a post that lit my inner Lewis Black on fire. I didn’t yell. I didn’t throw a chair. I did something far worse: I gave actual, heartfelt advice. And for that rare act of PM righteousness, I’m awarding myself this badge: **Reddit Rant 08: The DA Is Not Your Dungeon Master.** Because when getting access to data starts to feel like prepping for a D&D campaign, it’s time to rethink who holds the roadmap.

The Question
------------

[![The poster is wrestling with how to explore problems without being blocked by gatekeeping data practices, unsure how to be curious when every question demands a fully-formed hypothesis.](https://substackcdn.com/image/fetch/$s_!PfSl!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F676d66a0-222d-4ab7-83c8-8405563652b2_1234x796.png "The poster is wrestling with how to explore problems without being blocked by gatekeeping data practices, unsure how to be curious when every question demands a fully-formed hypothesis.")](https://www.reddit.com/r/ProductManagement/comments/1l0li10/recently_started_as_a_pm_how_is_your_relationship/?utm_source=share&utm_medium=web3x&utm_name=web3xcss&utm_term=1&utm_content=share_button)

Why do I feel like I need a permission slip to explore problems?

### Without copying my Reddit reply word for word...

A new PM asked how we handle data.  
What I heard was:

> *"Why do I feel like I need a library hall pass, a minor in statistics, and a character reference from the CFO just to explore a problem?"*

Here’s what I told them — and what I’d tell you, here in the safety of Substack, free from Reddit restraint, where I can finally say what I *meant* without clutching my pearls or formatting for karma.

---

#### 🧭 Data is a tool. People are the operating system

First, let’s set the record straight.

**Yes, Your Relationship With Data** ***Matters*** **— But Not More Than Your Relationships With People!**

You can have dashboards that sparkle like a Gartner Magic Quadrant... and still ship total junk if you’re not collaborating.

Your job as a PM is to **deliver so much value to the customer** that the business can’t help but profit.

Not because you wrote a flawless hypothesis.  
Because you had the guts to *ask the dumb question,* pull your DA into the fog of uncertainty, and focus everyone on outcomes, not vanity metrics and pixel-perfect funnels.

If you're treating data like gospel and humans like blockers, you’re not doing product work. You’re doing analytics cosplay.

---

#### 🧪 We Work in Bets — Not Absolutes

You weren’t hired to win the Nobel Prize in Hypothesis Formation.  
You were hired to **make informed bets before the business sets itself on fire trying to** ***"optimize engagement."***

Your job is to collect *just enough data* to confidently say:

* **Pivot** – Not quite. Adjust course.
* **Punt** – Not now, maybe later, likely never.
* **Pause** – Nobody move. Let’s rethink this.
* **Pursue** – It’s real. Let’s go.

But if you can’t even *explore* an idea until you’ve submitted a dissertation, you’re not in a product team — You’re in a **bureaucracy wrapped in a spreadsheet stuffed inside a compliance manual.**

---

#### 🧃 It's a Partnership not a Patriarchy! Work as a team.

You’re not doing discovery.  
You’re doing **free labor for the BI team**, disguised as *"strategic alignment."*

This isn’t about rigor. It’s about control.  
And that, friends, is **organizational debt** — the kind that compounds interest every time a good idea dies at the altar of *“data readiness.”*

If your DA won’t run a query without a six-point hypothesis and references in APA format, congrats — you’ve been reassigned to *"Product Management: The Support Role"* and demoted to *"Data Delivery Boy."*

Here’s what a **healthy DA/PM partnership** actually looks like:

* You sketch **lightweight experiments** together.
* You agree on what data will actually **reduce uncertainty.**
* You **instrument the signals** that matter across users, segments, markets, and revenue levers.

And yes, that means **the two of you working together** to solicit data instrumentation and experimentation tools like **Amplitude**, **Pendo**, **Split.io**, **LaunchDarkly**.  
Not praying to the Query Dieties and hoping someone approves your access request before Q4.

---

#### 💸 You Want Leverage? Learn to Speak the Language of the Business

Analytics are the cover charge.  
**Revenue is the setlist.**

Want a real seat at the table? Want some executive buy-in behind you? Start speaking in **profit** not pie charts.

Don’t just memorize product metrics — internalize the ones that keep the business breathing:

* **CAC** – What it costs to get someone in the door.
* **LTV** – What they’re worth once they’re inside.
* **ARR** – What keeps the lights on.
* **BEP** – How long before we stop losing money.
* **Churn** – The silent killer of dreams and decks.

Want to stop justifying your existence?  
Don’t show the execs a funnel. Show them a bet, a return, and a reason.

---

#### 🔚 Final Word: You’re Not Here to Write SQL — You’re Here to Ship Clarity

You are not here to **request permission to think.**  
You are not here to **audition for access to the truth.**

You are here to collaboratively **ask better questions, test faster, and steer the team toward clarity before the market eats your lunch.**

When discovery requires a hypothesis and a blood oath, it’s not discovery — it’s theater — not teamwork.

So the next time someone tells you *“your hypothesis isn’t strong enough,”* smile, nod, and say:

> *"If perfection is the enemy of delivered,   
> then 100% certitude is the beast that eats runway."*

Then get back to doing the real work.  
The messy, meaningful, gloriously ambiguous work of building what matters.  
Get busy on the value delivery search & rescue work that’ll keep the light on!

---

And it’s for this reason I’m awarding myself the ‘**Reddit Rant 08: The DA Is Not Your Dungeon Master**’ badge.

[![**Badge Meaning:** This badge captures the all-too-familiar experience of being a product manager blocked by data gatekeeping. The wizard-like Reddit mascot represents the Data Analyst wielding arcane authority over access to insights, while the overwhelmed PM clutches a “HYPOTHESIS” like it’s a ticket to get in the room. The d20 die floating overhead mocks the illusion of rigor — as if data discovery were a game of chance where only the worthy (and fully cited) get answers.  Earning this badge means you've lived the pain of needing permission to be curious — and chose to speak up anyway.](https://substackcdn.com/image/fetch/$s_!5dlq!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7006fac6-45b5-49ad-8f3a-dcbe83c1faba_1024x1024.png "**Badge Meaning:** This badge captures the all-too-familiar experience of being a product manager blocked by data gatekeeping. The wizard-like Reddit mascot represents the Data Analyst wielding arcane authority over access to insights, while the overwhelmed PM clutches a “HYPOTHESIS” like it’s a ticket to get in the room. The d20 die floating overhead mocks the illusion of rigor — as if data discovery were a game of chance where only the worthy (and fully cited) get answers.  Earning this badge means you've lived the pain of needing permission to be curious — and chose to speak up anyway.")](https://substackcdn.com/image/fetch/$s_!5dlq!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F7006fac6-45b5-49ad-8f3a-dcbe83c1faba_1024x1024.png)

The badge you win when you realize it’s not about the SQL, it’s the people.

Want this on a mug, a tote bag, or printed on your next 404 page? Let’s talk.

Otherwise, here's the link to **[The Original Reddit Post](https://www.reddit.com/r/ProductManagement/comments/1l0li10/recently_started_as_a_pm_how_is_your_relationship/?utm_source=share&utm_medium=web3x&utm_name=web3xcss&utm_term=1&utm_content=share_button)**. Just remember: we were friends *before* you hit that downvote button.

---

Share this post — because somewhere out there, a PM is one query rejection away from snapping.

[Share](https://deanpeters.substack.com/p/reddit-rant-08-the-da-is-not-your-dungeon-master?utm_source=substack&utm_medium=email&utm_content=share&action=share)

---

Drop a comment below — wisdom earns badges, and snark might just earn you a legend.

[Leave a comment](https://deanpeters.substack.com/p/reddit-rant-08-the-da-is-not-your-dungeon-master/comments)