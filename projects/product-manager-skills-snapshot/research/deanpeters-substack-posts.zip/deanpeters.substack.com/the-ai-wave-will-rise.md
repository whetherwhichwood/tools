# The AI Wave Will Rise

Imagine: **Hokusai’s The Great Wave off Kanagawa**, but instead of fishing boats, the wave crashes over a fleet of LinkedIn profiles. The froth? Resumes, standups, and hastily abandoned Trello boards. The boats? Clueless managers armed with emergency ChatGPT prompts. The mountain in the background? Not Mount Fuji, but the looming AI-powered job market, cool and impassive.

[![](https://substackcdn.com/image/fetch/$s_!Yd_2!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F47515ccb-4a3b-4118-98f0-3d133b0b58a7_3072x2048.png)](https://substackcdn.com/image/fetch/$s_!Yd_2!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F47515ccb-4a3b-4118-98f0-3d133b0b58a7_3072x2048.png)

Waves rise. Intangibles remain. Embrace humanness.

This isn’t just a wave—it’s a tidal reset. Not gradual erosion, but the digital equivalent of a meteor impact on entry-level knowledge work. As [Anthoropic’s Dario Amodei warns](https://www.axios.com/2025/05/28/ai-jobs-white-collar-unemployment-anthropic), the AI wave will come, upending white-collar roles faster than we can brace for. The question isn’t whether it’s coming. It’s how we, as product people, will respond.

> *"When the great way prevails, chariots are abandoned; when wisdom rules, cleverness is forgotten.*  
> *Yet in chaos, the sage returns to the root: stillness, where all waves arise and subside."* — *Zhuangzi, Inner Chapters*

### Thriving in the Chaos

Let us quiet the noise of panic with calm clarity. Shareholders demand more with less. Boards tighten budgets, freeze hiring, and push AI faster, as seen at [Shopify](https://www.linkedin.com/pulse/use-ai-step-aside-10-takeaways-from-shopifys-everyone-dean-peters-1xuwe/?trackingId=r10x07gGQtCMMvN0EXrnLA%3D%3D), [Duolingo](https://www.theverge.com/news/657594/duolingo-ai-first-replace-contract-workers), and beyond. But **those who hold to the human intangibles**—qualities AI cannot yet touch—will not just survive, but thrive.

#### For **Product Leaders** (VPs, Directors, Heads of Product):

* **Narrative**: Speak your purpose like the brush that writes the path. Machines form words, but only humans shape meaning.
* **Negotiation**: More than leverage—it’s a dance of insight. Friction becomes flow when patience meets perspective.
* **Navigation**: Where AI sees maps, humans sense motion. The master adapts, vision steady amid shifting tides.
* **Nurturing**: Grow your team like bamboo—rooted deep, bending in storms, resilient in drought.
* **Networking**: Connection transcends code. Trust is built over time, tea, and quiet moments. Not through algorithms.

> *"The highest type of ruler is one of whose existence the people are barely aware. When his task is accomplished and his work done, the people all say, 'We did it ourselves.'"* — Laozi, Tao Te Ching

#### For **Product Managers, POs, and ICs**:

* **Story-listening**: Hear the need beneath the feature request. Speak to that, not just the spec.
* **Synthesis**: From scattered feedback, discern the shape. Use empathy and experiences to guide you.
* **Socialization**: Pass ideas like tea among peers. Quiet influence scales better than broadcast.
* **Sensing**: Note the pause, the hesitation, the shift in tone. Read the room, not just the report.
* **Stewardship**: Tend the team and product like a garden. Integrity is your topsoil.
* **Skepticism**: Ask what’s missing. Interrogate the obvious. AI may echo, but truth is often whispered.

> *"A wise man adapts himself to circumstances, as water shapes itself to the vessel that contains it."* — I Ching, Hexagram 58

---

[![](https://substackcdn.com/image/fetch/$s_!6apn!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff5c4d666-ef15-47cc-93ad-ca10e67ccbf0_3072x2048.png)](https://substackcdn.com/image/fetch/$s_!6apn!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ff5c4d666-ef15-47cc-93ad-ca10e67ccbf0_3072x2048.png)

Teach by listening. Guide by presence. Serve through stillness.

### Calm in the Chaos

As waves crash and the fog of automation thickens, remember: it’s not tools or backlog that define you. It’s the intangibles: quiet decisions, subtle moves, human presence no AI can yet mimic.

* **Product Vision**: Show the horizon where real needs meet purpose. Influence rides on clarity.
* **Practice Intention**: Listen deeply. See what others skim. Stay in the room with the real problem.
* **Pivot Adaptively**: Be water, not stone. Shift with grace. Rest with purpose.
* **Promote Humility**: Share credit. Own missteps. Ask the hard questions even when the answers hurt.
* **Pursue Thoughtfulness**: Let reflection cut through noise. Journal your drift. Don’t outsource understanding.
* **Preserve Simplicity**: Strip to essence. Hold restraint. Insight lives beneath the noise.

Because some days, product management *is* group therapy—with better Post-its.

> *"Thirty spokes share one hub: the wheel’s use lies in the space where nothing exists.*  
> *Mold clay to make a vessel: its essence dwells in the hollow.*  
> *Profit comes from what is there; usefulness from what is not."*  
> — Laozi, Tao Te Ching (Ch. 11)

---

### Acting on the Chaos

[Share](https://open.substack.com/pub/deanpeters/p/the-ai-wave-will-rise?r=3jxqq&utm_campaign=post&utm_medium=web&showWelcomeOnShare=false) this. Subscribe. Offer a [comment](https://deanpeters.substack.com/p/the-ai-wave-will-rise/comments).

We thrive not alone, but together—by sharing insight, by telling stories, by paddling hard in the same direction.

Whispers in the storm. Clarity rides each ripple. Subscribe. Stay human.

Subscribe