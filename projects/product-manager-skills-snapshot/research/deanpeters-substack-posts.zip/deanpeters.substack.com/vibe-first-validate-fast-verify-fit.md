# Vibe First, Validate Fast, Verify Fit

Welcome to product discovery in the era of **vibe coding**—AI-assisted prototyping that looks real but may not be—**agentic AI tools**, and **stakeholder theater**—where the *wrong* prototype costs more than the *wrong* roadmap.

[![You don't need to scale it yet. But you do need to stop guessing.](https://substackcdn.com/image/fetch/$s_!jzeB!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe8f91e26-d59e-4fb0-800b-0fce3201b515_6199x4491.png "You don't need to scale it yet. But you do need to stop guessing.")](https://substackcdn.com/image/fetch/$s_!jzeB!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe8f91e26-d59e-4fb0-800b-0fce3201b515_6199x4491.png)

You don't need to scale it yet. But you do need to stop guessing.

"The most expensive way to test your idea is to build production-quality software." ~ Jeff Patton, [Dual Track Development](https://jpattonassociates.com/dual-track-development/)

Every prototype tells a story. Some whisper feasibility. Some scream, “LOOK AT THIS FIGMA!” Others lie … beautifully, confidently, and often. And your execs believe them. As a product manager, you don’t need to scale yet … but you do need to stop guessing what’s worth building.

Let's fix that. But first, let's reset what we even mean by **"prototype"** in the year 2026 (*that's not a typo, peeps*).

🔍 Reset: The Proof-of-Life Probe
--------------------------------

Back in 2015, I was stuck in **feature hostage negotiations** with execs who couldn't tell a prototype from a production build. So I invented a new kind of artifact:

### **The PoL Probe — Proof of Life**

* Lightweight
* Disposable
* Narrow in scope
* Brutally honest
* Tiny & Focused

Think of them as reconnaissance missions. Not MVPs. ***Never MVPS!***. These *tiny acts of discovery* (TADs) exist to **de-risk** decisions … not justify the latest idea bellowed by the HiPPO or swoop-n-pooped by a vibe coding Seagull Manager.

🧠 Choose Wisely (and Cheaply)
-----------------------------

Not every problem is a nail in need of a hammer. Meaning, just because vibe code makes it *look* real doesn't mean it *is* real. And not everything deserves to be vibe-coded.

So, before you hand over dev hours like Halloween candy, ask:

> **What risk are we trying to de-risk?**
>
> And what's the *cheapest, fastest* way to hear the harshest truth?

🍦 The Flavors of Prototypes (Now with AI Toppings)
--------------------------------------------------

### **1. Feasibility Checks**

*Can we even build this?*  
1–2 day spike-and-delete tests. Think: GenAI prompt chains, LMMs Evals, data integrity sweeps, third-party API sniff tests, or evaluating tool fit. This is about surfacing technical risk—not building to impress.

### **2. Task-Focused Tests**

*Can users complete this one job without friction?*  
Validate the make-or-break moments: a field label, a decision point, a drop-off. Tools like [Optimal Workshop](https://www.optimalworkshop.com/) and [UsabilityHub](https://usabilityhub.com/) make this dead simple.

### **3. Narrative Prototypes**

*Does this workflow earn a 'hell yes'?*  
Think Loom walkthroughs, explainer videos, or slideware storyboards. It's not "build vs buy." It's "tell vs test." Tell the story, then see who buys in.   
Text-to-video tools like [Sora](https://sora.chatgpt.com/explore?help=), [Synthesia](https://www.synthesia.io/), and [Veo3](https://gemini.google/overview/video-generation/) let you create fast, low-effort narratives—without writing code or crafting clickable prototypes.

### **4. Synthetic Data Simulations**

*Can we model this without burning prod?*  
Use tools like [Synthea](https://synthea.mitre.org/) to simulate users. Leverage systems like [DataStax LangFlow](https://www.datastax.com/products/langflow) to test prompt logic, edge cases, or surface unknowns. It's like a wind tunnel—only cheaper than a postmortem.

### **5. Vibe-Coded PoL Probes** *(fka "Hybrid Prototypes")*

*Will this Frankensoft survive contact with users?*  
ChatGPT prompts wired through Canvas screens, deployed with a dash of Replit and Airtable? Boom: fake frontend, semi-plausible backend, and user feedback in 48 hours. This isn’t product—it’s **just enough illusion** to catch real signals. If they use it, great. If they ghost it? Even better—you just dodged a six-month roadmap detour. Just don’t confuse momentum with maturity.

*“The biggest risk is building something nobody wants. That’s why we need to validate our assumptions before we invest in building the full solution.”  
~ Melissa Perri, [Escaping the Build Trap](https://amzn.to/4ksLJJ7)*

🧪 Rule of Thumb
---------------

> **Use the cheapest prototype that tells the harshest truth.**  
> If it *doesn't sting*, it's probably just theater.

[![Use the right tool for the job. Use the right size test for your hypothesis](https://substackcdn.com/image/fetch/$s_!u-BS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8a1f3ae6-82d6-4926-96c8-1d508fea693c_6175x3100.png "Use the right tool for the job. Use the right size test for your hypothesis")](https://substackcdn.com/image/fetch/$s_!u-BS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8a1f3ae6-82d6-4926-96c8-1d508fea693c_6175x3100.png)

Use the right tool for the job. Use the right size test for your hypothesis

---

🙌 Hat Tip to a Prototype OG
---------------------------

This post owes a debt to Marty Cagan's 2014 blog post *[Flavors of Prototypes](https://www.svpg.com/flavors-of-prototypes/)* and Chapter 43 of his book *[Inspired: How to Create Tech Products Customers Love](https://amzn.to/4kvvHhH)*.

While his examples may be dated in today's world of generative assistants and cheap prototyping tools …

... his message is still relevant …

… we need **intentional proof-of-life validations**, not prototype theater.

🎯 Your Turn
-----------

What's your go-to PoL probe when you need to **gut-check risk before devs throw laptops**?

Drop your favorite flavor—or your biggest fail—in the comments.

Let's validate smarter. Prototype cleaner. And dodge the next swoop-and-poop.

---

[Leave a comment](https://deanpeters.substack.com/p/vibe-first-validate-fast-verify-fit/comments)