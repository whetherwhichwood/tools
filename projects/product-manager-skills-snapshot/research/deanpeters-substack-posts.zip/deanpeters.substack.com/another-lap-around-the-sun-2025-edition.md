# Another Lap Around the Sun, 2025 Edition

[![](https://substackcdn.com/image/fetch/$s_!dlY0!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa17036d9-eaa3-4c50-bc11-a54b83f81e0c_3231x1564.png)](https://substackcdn.com/image/fetch/$s_!dlY0!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fa17036d9-eaa3-4c50-bc11-a54b83f81e0c_3231x1564.png)

This past year brought me joy not measured in miles, but in moments—watching lightbulbs go off for the **next great generation of product peeps**. Over 2,000 directly impacted, with downstream ripple effects still splashing out into the wild, like rogue Post-it notes on a whiteboard in a wind tunnel.

[![](https://substackcdn.com/image/fetch/$s_!7ACO!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffcc06aa6-63a7-46d0-8fa7-cf1980adb1c9_4000x2252.jpeg)](https://substackcdn.com/image/fetch/$s_!7ACO!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Ffcc06aa6-63a7-46d0-8fa7-cf1980adb1c9_4000x2252.jpeg)

With all those travel miles and smiles, and even the MS Teams virtual sessions, it felt only right to mark the moment with another parody—this one for me and my fellow [Productside Principal Consultants and Trainers](https://productside.com/our_team/deanpeters/) in product management:

🎶 *To the tune of “I’ve Been Everywhere”* (with apologies to Johnny Cash and anyone with a strict rhyme schema):

> I’ve taught in Heidelberg, Frankfurt,  
> Riyadh on a long work spurt,  
> Al Khobar, Doha heat,  
> Milan with espresso beat,  
> Schaffhausen’s watchful tick,  
> Zurich — clean and *real* slick,  
> Montreux near a jazz refrain,  
> London drizzle, Derby train.  
> NYC for subway miles,  
> Atlanta's charming Southern smiles,  
> Lizard Lick — not just a name,  
> Where roadside quirks outshine the fame.
>
> I’ve dodged roadmap roadkill,  
> Herded HiPPOs against their will,  
> Tamed RHiNOs with fake demand,  
> Fought Frankensoft no one planned.  
> Helped PMs escape SAFe® traps,  
> Cut feature bloat with just one slap,  
> Sent the ladder down with flair—  
> Transforming lives **everywhere, man**. 🎯

[![](https://substackcdn.com/image/fetch/$s_!SqTb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F17c708cc-6505-4a95-b759-9a96c3679999_3392x1908.jpeg)](https://substackcdn.com/image/fetch/$s_!SqTb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F17c708cc-6505-4a95-b759-9a96c3679999_3392x1908.jpeg)

And if you’re wondering, *"Just how far would Dean go to complete his mission?"*

### To the Ends of the Earth

And maybe even a bit past Lizard Lick, NC—yes, it’s real, and conveniently located on the way to some real-deal Eastern-style BBQ (the way God intended). But I digress…

… the real story? It's not just the ladder.

[![](https://substackcdn.com/image/fetch/$s_!0Ttb!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F832757f6-26e6-4dd3-a11d-bddb55fe249d_3392x1564.jpeg)](https://substackcdn.com/image/fetch/$s_!0Ttb!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F832757f6-26e6-4dd3-a11d-bddb55fe249d_3392x1564.jpeg)

### It's all about the elevator

For the past three years, my mission has been simple … and to quote Christopher Lochhead from recent [Category Pirates](https://open.substack.com/pub/categorypirates) podcast: ***“… send the damn thing back down to the next generation.”***

Because none of this—none of *me*—happened in a vacuum. Every product I shipped, every class I taught, every mess I helped un-muddle was built on the generosity of brilliant mentors, fearless coaches, and teachers who refused to gatekeep wisdom.

[![](https://substackcdn.com/image/fetch/$s_!Yeoc!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F62a2a6cd-2d20-42b8-b818-cf53469b6e0d_3392x1564.jpeg)](https://substackcdn.com/image/fetch/$s_!Yeoc!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F62a2a6cd-2d20-42b8-b818-cf53469b6e0d_3392x1564.jpeg)

### It's all about giving back

So my job for the next 365 is simple: **keep paying it forward**. Keep blessing others with the lessons that I was lucky enough to collect—one messy, magical product journey at a time.

I hope my flavor of PM delight—equal parts clarity, storytelling, and “*did-he-actually-just-say-that*” sass—continues to resonate.

[![](https://substackcdn.com/image/fetch/$s_!RPSz!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcc1b8a92-f08e-41bb-9a65-7c0adbc7bfda_4000x3000.jpeg)](https://substackcdn.com/image/fetch/$s_!RPSz!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcc1b8a92-f08e-41bb-9a65-7c0adbc7bfda_4000x3000.jpeg)

### It's all about leaving something behind

This year, I’m adding Substack to the mix. Because it’s time to put more of this stuff out there, in my own weird and wacky voice. So long after I’ve gone fully analog, you can still hear me echo:

> ***“Sure, product management is hard… but it doesn’t have to suck.”***

[![](https://substackcdn.com/image/fetch/$s_!nSK_!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe7c58480-a83b-4d9a-9cc3-f736befbdd8a_4000x2252.jpeg)](https://substackcdn.com/image/fetch/$s_!nSK_!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe7c58480-a83b-4d9a-9cc3-f736befbdd8a_4000x2252.jpeg)

So yes, another candle, another lap.  
But I don’t count years anymore.

I count ladders lowered. Ropes extended. Laughs shared.  
And lives lifted—better than we found them.

Here’s to the next lap—less Terminal C, more transformational clarity. 🛫✨📦

Want to Keep Up?
----------------

Join me on my journey and …

Subscribe

[Leave a comment](https://deanpeters.substack.com/p/another-lap-around-the-sun-2025-edition/comments)