# The Unspoken State of PM as of mid-2025

AI didn’t take your job—it multiplied it, split it into five roles, and asked you to do them all on 60% headcount and zero clarity. If you’re feeling productive, confused, and vaguely replaceable, welcome to product management in mid-2025 and …

[![PMs in 2025 are expected to stay calm, collaborative, and composed—even as the tools, roles, and expectations around them ignite in complexity. This image reflects the quiet absurdity of pretending everything’s fine in the face of constant change.](https://substackcdn.com/image/fetch/$s_!6gga!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3fb6d269-4965-40e0-b91b-3ddec8d9726d_4186x2102.png "PMs in 2025 are expected to stay calm, collaborative, and composed—even as the tools, roles, and expectations around them ignite in complexity. This image reflects the quiet absurdity of pretending everything’s fine in the face of constant change.")](https://substackcdn.com/image/fetch/$s_!6gga!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3fb6d269-4965-40e0-b91b-3ddec8d9726d_4186x2102.png)

The PM job market is bouncing back. Your sanity? Less so.

Let’s Give Lenny His Well-Deserved, Data-Driven Bouquet
-------------------------------------------------------

Once again, [Lenny Rachitsky](https://open.substack.com/users/1849774-lenny-rachitsky?utm_source=mentions) gave us a sharp, data-backed snapshot of where the product hiring world is heading. A few highlights worth carving into your career whiteboard:

* **Open PM roles are up 53.6% from 2023’s trough** — You may resume light LinkedIn lurking.
* **AI PM roles are exploding** — 688 and counting. That’s not a trend, it’s a full-blown hiring category.
* **Layoffs are slowing**, which is good, while **remote roles are quietly vanishing**, which is... less good.
* **The Bay Area remains the center of the product universe** — RDU: you're trying. Bless you.

For the full picture (and possibly your next role), start here:  
👉 [Lenny’s 2025 Product Market Breakdown](https://www.lennysnewsletter.com/p/state-of-the-product-job-market-in?r=3jxqq&utm_campaign=post&utm_medium=web&showWelcomeOnShare=false)

Meanwhile, in the Group Therapy Circle...
-----------------------------------------

Yes, yes, yes, I know, feels like I'm '**coat-tailing**' a bit on Lenny's awesome lists, but actually this ‘**unauthorized version**’ is simply inspired by him, rather than a parody or cheap tag along post in hopes of pimping up my Substack subcriptions.

Instead, as your trusted ***product management group therapist***and***unofficial zookeeper** of PM dysfunction*, I don’t just read the trends—I triage the trauma as I teach and consult. I hear the confessions usually only whispered in **Kanban Confessionals** between retros and the meltdowns muffled by Slack status updates.

So, without naming names (*or tagging anyone on LinkedIn*), here’s a sharper, snarkier, more reality-adjacent snapshot of PM life in mid-2025 that came to my warped mind as I read Lenny's post … with clickable receipts.

---

### 1. **The AI PM Role Is Now the Swiss Army Knife of Desperation**

You’re not a product manager anymore. You’re a:

* Prompt engineer
* Trust & safety specialist
* Token cost negotiator
* “Why is this model weird?” explainer

And somehow, still expected to deliver weekly demo-worthy progress.

> Related:
>
> * Wired: [How Business Leaders Should Navigate AI in 2025](https://www.wired.com/sponsored/story/how-business-leaders-should-navigate-ai-in-2025/)
> * The Future of Prosumer: [The Rise of “AI Native” Workflows](https://www.youtube.com/watch?v=HkOJy8rMlMw)
> * [A Smokejumper’s Survival Guide to AI Product Management](https://deanpeters.substack.com/p/a-smokejumpers-survival-guide-to?r=3jxqq)

---

### 2. **Platform PMs Are Still the Middle Children of Product**

You were promised architectural influence and long-term leverage.  
What you got was “*Can we ship this endpoint by next Tuesday?*”  
Also, there’s now a Notion page titled **“Platform Backlog (Archived).”**

> Further Reading:
>
> * [ProductPlan’s 2025 PM State of the Industry](https://www.productplan.com/2025-state-of-product-management-report/)
> * a16z: [From Prompt to Product: The Rise of AI-Powered Web App Builders](https://a16z.com/ai-web-app-builders/)
> * Platform thinking in the age of Generative AI: [A practical guide for Product Managers](https://www.mindtheproduct.com/platform-thinking-in-the-age-of-generative-ai-a-practical-guide-for-pms/), Mind the Product

---

### 3. **Intellectual Atrophy Is the Hidden Cost of AI**

The layoffs may have slowed, but something subtler—and more insidious—is underway: our collective product brain is going soft.

What used to be strategic work is now mostly hitting “Regenerate” until it sounds right.

> “As soon as the AI model is good enough, everyone tends to fall asleep at the wheel.”  
> — Ethan Mollick, [MIT Sloan](https://mitsloan.mit.edu/ideas-made-to-matter/how-to-tap-ais-potential-while-avoiding-its-pitfalls-workplace), July 2024
>
> * [Swiss study links AI use to erosion in critical thinking](https://phys.org/news/2025-01-ai-linked-eroding-critical-skills.html)
> * [My own breakdown: Intellectual Atrophy with Generative AI](https://deanpeters.substack.com/p/intellectual-atrophy-with-generative-ai)

---

### 4. **When the Prototype Becomes the Pitch Deck**

Welcome to the era of Vibe Coding. Where one-person teams use AI to spin up slick prototypes that look like finished products but behave like audition reels for chaos.

It’s fast. It’s fun. It’s dangerous. And you’re expected to think like a machine learning engineer, move like a rapid prototyper, and explain it all like a seasoned PM—with none of the power, resources, or time to actually validate it.

Because now, leadership sees Figma click-throughs and GPT-laced demo flows and says: “Ship it!” before anyone’s validated the problem, run a usability test, or checked the data dependencies hiding under the hood.

The burden falls back on product teams to:

* Visually validate faster, without mistaking polish for proof
* Translate vibes into evidence
* Set clearer expectations between artifact and asset

> * [Jakob Nielsen](https://open.substack.com/users/103695927-jakob-nielsen?utm_source=mentions): [Vibe Coding and Vibe Design](https://open.substack.com/pub/jakobnielsenphd/p/vibe-coding-vibe-design?r=3jxqq&utm_campaign=post&utm_medium=web&showWelcomeOnShare=false)
> * SHRM: [Shadow AI Is on the Rise](https://www.shrm.org/topics-tools/flagships/ai-hi/shadow-ai-on-the-rise) (If they haven’t written this yet, they will.)
> * [Dig like an Arms Merchant, Deal like a Peacemaker](https://deanpeters.substack.com/p/dig-like-an-arms-merchant-deal-like) — on using AI to explore, not explode.

---

### 5. **Agentic Anxiety Is the New Burnout**

You're not worried AI will replace you.  
You're worried leadership will *ask you to become it.*

“Be more agentic,” they say—while giving you the autonomy of a Roomba and the accountability of a CTO.

> * HBR: [What Is Agentic AI, and How Will It Change Work?](https://hbr.org/2024/12/what-is-agentic-ai-and-how-will-it-change-work)
> * Marty Cagan: [Team Autonomy and AI](https://www.svpg.com/team-autonomy-and-ai/)
> * [Agentic AI – Product Management Friend or Foe?](https://www.youtube.com/watch?v=M2RLxsmmYDA&t=9s&ab_channel=Productside)

---

### 6. **AI-First Culture Is the New “Move Fast and Break Things”**

In case you missed the memo (and the Medium post), CEOs everywhere are declaring AI the new cultural cornerstone:

* Shopify’s CEO: “AI is our new language.”
* Every other CEO: “Same. But with less headcount.”

> * [Shopify’s AI-first manifesto](https://www.shopify.com/enterprise/shopify-ai-product-strategy)
> * [Financial Times: Pressure to go all-in on AI](https://www.ft.com/content/3e862e23-6e2c-4670-a68c-e204379fe01f)
> * [The AI gap in executive leadership teams](https://www.fastcompany.com/91313134/the-ai-gap-in-executive-leadership-teams)
> * [Anil Dash: AI-first is the new RTO](https://www.anildash.com/2025/04/19/ai-first-is-the-new-return-to-office/)

---

### 7. **We’re Still Confusing Tool Mastery With Product Leadership**

Yes, your stack is optimized.  
Yes, you have AI copilots and an atomic design system.  
And still, you shipped three things no one uses and one thing Legal had to pull.

> * Productside: [AI and Product Managers: What We Can Learn From Iron Man](https://productside.com/ai-and-product-managers-what-we-can-learn-from-iron-man/)
> * Productside: [Outputs vs. Outcomes](https://productside.com/product-management-monday-outcomes-vs-outputs/)
> * Webinar: [Getting Real Product Management ‘Sh!t’ Done With AI - Revisited](https://www.youtube.com/watch?v=SSfZciLGmww&ab_channel=Productside)

---

[![A satirical snapshot of modern product manager survival roles in 2025, showing how AI, prototyping pressure, cognitive load, and invisible infrastructure strain have splintered PMs into distinct coping archetypes.](https://substackcdn.com/image/fetch/$s_!53LU!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9c335930-7fc9-4cb0-b21e-b0aac8b1cdc8_3072x1828.png "A satirical snapshot of modern product manager survival roles in 2025, showing how AI, prototyping pressure, cognitive load, and invisible infrastructure strain have splintered PMs into distinct coping archetypes.")](https://substackcdn.com/image/fetch/$s_!53LU!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9c335930-7fc9-4cb0-b21e-b0aac8b1cdc8_3072x1828.png)

Meet the 2025 PM lineup. These aren’t personas—they’re survival responses.

---

Closing Thoughts (Before You Spiral into the Slack Abyss)
---------------------------------------------------------

If Lenny gave us the *company-wide broadcast*, this is the *backchannel DMs*.  
Yes, the market is bouncing back.  
No, your calendar isn’t.  
Yes, AI is changing everything.  
No, it still can’t write your strategy for you. (Yet.)

In 2025, you are:

* **A prototype illusionist** — conjuring product-shaped smoke from AI tools, then explaining why it's not real (yet) *(Fake it 'til your execs believe it.)*
* **A prompt conjurer** — shaping chaos into GPT-powered clarvoiance.
* **A metrics apologist** — defending dashboards built on vibes
* **A budget whisperer** — stretching cents into strategy briefs
* And, still, **the designated adult** in every stakeholder meeting — because someone has to clean up the digital glitter

**Good luck. Ship smart. Take breaks. And for the love of everything, stop saying yes to “quick syncs.”**

---

Call(s) to Action
-----------------

Subscribe

Tired of feeling like the last sane person in a roadmap planning meeting?  
Join the conversation. Share your war stories. Forward this to your favorite overwhelmed PM.

[Share](https://deanpeters.substack.com/p/the-unspoken-state-of-pm-as-of-mid-2025?utm_source=substack&utm_medium=email&utm_content=share&action=share)

And if you’ve got your own 2025 PM survival tactic or therapy trick—drop it in the comments. We’ll trade notes. Or just scream into the void together.

[Leave a comment](https://deanpeters.substack.com/p/the-unspoken-state-of-pm-as-of-mid-2025/comments)