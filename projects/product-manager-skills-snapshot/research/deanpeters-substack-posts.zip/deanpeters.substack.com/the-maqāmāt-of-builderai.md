# The Maqāmāt of Builder.ai

*A poetic, cautionary tale of Builder.ai’s collapse—told in maqāma form by a hakāwatī. Product lessons wrapped in satire, smoke, and sesame wisdom.*

[![Banner Image: The Hakawati’s Café – The Frame Tale In a café of smoke and screens, a tale of silicon and sorrow begins— for those who pitch the story before they know it often sell shadows, not substance](https://substackcdn.com/image/fetch/$s_!h4Ti!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcd1531a3-39c5-48c4-833c-666a6a7be201_1536x1024.png "Banner Image: The Hakawati’s Café – The Frame Tale In a café of smoke and screens, a tale of silicon and sorrow begins— for those who pitch the story before they know it often sell shadows, not substance")](https://substackcdn.com/image/fetch/$s_!h4Ti!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fcd1531a3-39c5-48c4-833c-666a6a7be201_1536x1024.png)

Every silence kept becomes a story someone else will tell.

> *This cautionary fable, humbly relayed by Dean Peters—an aged product manager and hopeful ḥakāwatī—tells the tale of a fictional Ḥazim al-Ḩasrah, a characterization whose silence, Maqāma by Maqāma, act by act, raised the cost of failure until both he and Builder.ai collapsed beneath the compounded debt.*

---

### Maqāma I: The Scroll Arrives

> *Hazim held his tongue when the floorboards moaned—so the rot made a home beneath his feet.*

[![Maqāma I: The Scroll Arrives A hand extends a scroll heavy with whispers of promises unfulfilled— be warned: dreams without systems crumble like sandcastles against the tide.](https://substackcdn.com/image/fetch/$s_!NqkS!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faccd0b51-3245-4be4-a4e3-0bbce3ea2475_1536x1024.png "Maqāma I: The Scroll Arrives A hand extends a scroll heavy with whispers of promises unfulfilled— be warned: dreams without systems crumble like sandcastles against the tide.")](https://substackcdn.com/image/fetch/$s_!NqkS!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faccd0b51-3245-4be4-a4e3-0bbce3ea2475_1536x1024.png)

Silence in doubt builds the wall that truth cannot breach.

**This tale is not mine alone.**  
It arrived folded in failure, stitched with brittle thread—  
a diary of despair from my companion,  
**Ḥazim al-Ḩasrah**, steadfast man of sorrows,  
his name a wind that moans through dreams abandoned.

**He gave it to me beneath the weary awning**  
of a roadside café—not of sprint reviews or spreadsheets,  
but of sesame smoke and cardamom whispers,  
where occasional sermons rise with the steam.

> *Ḥazim looked down, shame folding into his lap — as a man who had heard the floorboards moan, but whose silence laid the foundation of his failure.*

**A kind of qaṣīdah café,**  
where storyboards give way to satire,  
and ROI is recorded in regret.

*"Tell them,"* he said, voice thick as tahini, tear-lined but sure.  
*"Tell them what we built. What we broke. What broke us in return."*

**So I opened his pages, heard his heart's confession,**  
and now, dear listener, I recount  
this song of silicon and sorrow.

---

### Maqāma II: Mirage in the Marketplace

> *Hazim nodded through the pitch as fig-sweet lies took root—until truth could no longer grow there.*

[![Maqāma II: Mirage in the Marketplace Illusions dance in golden scrolls, while tired hands type beneath unseen strings— beware the shimmering mirage, for even fools can wear the robes of wisdom.](https://substackcdn.com/image/fetch/$s_!Oi2u!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6cc97dc5-db11-4f78-aa68-3d9db02de44e_1536x1024.png "Maqāma II: Mirage in the Marketplace Illusions dance in golden scrolls, while tired hands type beneath unseen strings— beware the shimmering mirage, for even fools can wear the robes of wisdom.")](https://substackcdn.com/image/fetch/$s_!Oi2u!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F6cc97dc5-db11-4f78-aa68-3d9db02de44e_1536x1024.png)

What dazzles investors may drown the builders.

**They called it Builder.ai—a name like an incantation.**  
A whisper riding the wind between Riyadh and Redwood.  
An app-in-an-hour oracle, blessed by giants:  
Microsoft. SoftBank. Qatar's golden coffers.  
Each invoked like saints at the altar of valuation.

*"No engineers needed,"* came the proclamation.  
*"Imagine it—and lo, it shall ship."*

**Ḥazim arrived as Principal Product Manager,**  
seeking substance, finding only shimmer.  
What he found was not product, but ***al-bayrīt***—  
fool's gold, glittering and worthless.

**Oh, the decks that danced before him!**  
Each slide so slick it could sell sand to the drowning,  
fig-scented promises perfumed in pixel and pitch,  
their colors bleeding promises across glass screens.  
Vision boards vast as the ***Rub' al-Khālī***—  
mirages that vanished with every closer scroll.

**Ḥazim asked for systems architecture.**  
They handed him TED Talk alliteration.  
He sought product-to-market fit.  
They served fortune-cookie OKRs, hollow and sweet.

**And beneath the spectacle:**  
Not models. Not machines.  
But men with weary fingers and bloodshot stares—  
elbows flying, keyboard ***bābājīs*** in Bangladesh,  
typing with the fury of ten thousand sprint points,  
their screens glowing like prayer candles in the dark.  
Smoke rising from Slack channels,  
conjured by the man behind the curtain—  
this Oz built of code and conjecture, not emeralds.

---

### Maqāma III: Invoices and Illusions

> *Hazim let the coin-spin dazzle his doubt—and woke up etched into the grift he didn’t stop.*

[![Maqāma III: Invoices and Illusions Dancers draped in digital brocade exchange invoices beneath a sky of question marks— but know this: wealth conjured in circles collapses when called to account.](https://substackcdn.com/image/fetch/$s_!IlgA!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F46530610-dadc-4f90-886f-5cff1a496d30_1536x1024.png "Maqāma III: Invoices and Illusions Dancers draped in digital brocade exchange invoices beneath a sky of question marks— but know this: wealth conjured in circles collapses when called to account.")](https://substackcdn.com/image/fetch/$s_!IlgA!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F46530610-dadc-4f90-886f-5cff1a496d30_1536x1024.png)

**Revenue spun from fiction always comes unraveled.**

**The mirage had merchants, and the merchants had mirrors.**  
Builder.ai did not dance in deceit alone.

**It waltzed, invoice in hand,**  
with a fellow illusionist—**VerSe**.  
A duet of round-trips, a circle of billing:  
*"You invoice me, I invoke you, and thus gold appears."*  
Not in coffers, but in the pupils  
of those who fund dreams with other people's gold.

**Ḥazim, still loyal as a desert guide,**  
watched the numbers swell like sandstorms,  
dust devils of dollars spinning across dashboards:  
$220 million forecast, bold as brass.  
$55 million reality, if you shook the books  
hard enough to hear the truth rattle like dice.

**The growth galloped across dashboards.**  
The customers?  
They got login screens that wouldn't login,  
and locked-out dreams gathering digital dust.

**He whispered warnings in standups,**  
voice small but certain.  
They answered in unison:  
*"Focus on outcomes, not obstacles."*

**So he did focus, and found:**  
the outcome was illusion itself—  
selling sand to a drowning man,  
one grain at a time.

---

### Maqāma IV: The Curtain Collapses

> *Hazim waited for the perfect words—then watched fifteen hundred fall through the silence he authored.*

[![Maqāma IV: The Curtain Collapses A tangled web of wires unravels as the tower crumbles into silence— learn from this: when illusions fall, only those who built with truth remain.](https://substackcdn.com/image/fetch/$s_!XEDR!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbb3d9ede-e9f4-4589-b372-dbe1db1f07ba_1536x1024.png "Maqāma IV: The Curtain Collapses A tangled web of wires unravels as the tower crumbles into silence— learn from this: when illusions fall, only those who built with truth remain.")](https://substackcdn.com/image/fetch/$s_!XEDR!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fbb3d9ede-e9f4-4589-b372-dbe1db1f07ba_1536x1024.png)

Blind trust collapses with the false tower it upholds.

**The curtain fluttered once, then fell with a whisper.**  
The conjurer vanished like morning mist.  
The company crumbled like ancient walls,  
leaving only dust and disappointed angels.

**One thousand five hundred souls,**  
unplugged in a single dusk,  
their notifications silenced forever.  
Thousands of clients discovered  
their apps and ambitions  
sealed in digital amber,  
behind shuttered servers that would never wake.

**Builder.ai became Builder.ai-n't—**  
a fable wrapped in funding rounds,  
a case study in hubris  
for future product managers to ponder.

**Ḥazim left with nothing but his notebook,**  
and the taste of tahini turned bitter  
on his tongue.

---

### Maqāma V: Cousins and Consequences

> *Now Hazim stirs garlic and skewers shwarma by hand, haunted by the code he never questioned, the crash he helped curate.*

[![Maqāma V: Cousins and Consequences In the scent of shawarma, the past’s illusions are replaced by today’s fire and bread— heed this: what feeds the soul is made slow and real, not fast and false.](https://substackcdn.com/image/fetch/$s_!fXuP!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1322350b-d370-4214-9014-98bbe8c679de_1536x1024.png "Maqāma V: Cousins and Consequences In the scent of shawarma, the past’s illusions are replaced by today’s fire and bread— heed this: what feeds the soul is made slow and real, not fast and false.")](https://substackcdn.com/image/fetch/$s_!fXuP!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F1322350b-d370-4214-9014-98bbe8c679de_1536x1024.png)

The reality of hot shawarma heals faster than the falsehood of cold slide decks.

**And now?**

I serve shawarma, not strategy.  
Sustenance, not software.

**My days unfold inside our food truck,**  
beside Ḥazim and his cousin,  
**Fāḍhil al-Khusrān**—  
the man of many losses,  
whose jajik sauce redeems all failures.

**We call it Ship It & Dip It.**

**We forecast not churn, but hunger.**  
We A/B test not the hummus recipe.  
We deploy not on Fridays,  
but every day that stomachs growl.

**And yet...**

Sometimes, while the falafel fries and pops,  
oil crackling like code compiling,  
Ḥazim and I still dream in algorithms:  
AI to optimize the queue,  
a chatbot for custom sides,  
pita personalization via prompts,  
a large language model for large lunch orders.

**Until—**

**Yia Yia Maria**  
raps the window sharp and sudden:

> *"Extra garlic! No AI! No algorithms!  
> And make it snappy, habibi!"*

**And just like that, we return:**  
from pitch deck to pita bread,  
from Builder to built-to-order,  
from product backlog to baklava,  
from artificial intelligence  
to actual ingredients.

---

### The Final Scroll

> *We, like Hazim, need not lie to build a lie—we need only stay quiet while the tower leans.*

[![The Final Scroll: Lessons for Product Minds The tale ends where wisdom and mirage meet; ask the question, serve the bread— remember: one more question could save you from building tomorrow’s regret.](https://substackcdn.com/image/fetch/$s_!C_9x!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F94cd9aff-e051-4288-ae7b-2132b1b162dc_1024x1536.png "The Final Scroll: Lessons for Product Minds The tale ends where wisdom and mirage meet; ask the question, serve the bread— remember: one more question could save you from building tomorrow’s regret.")](https://substackcdn.com/image/fetch/$s_!C_9x!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F94cd9aff-e051-4288-ae7b-2132b1b162dc_1024x1536.png)

If you see the mirage and stay quiet, you help sell sand to the drowning.

1. **Ḥazim al-Ḩasrah's Arrival** – Trust is earned with architecture, not acronyms.
2. **The Mirage of AI** – If the magic can't be demoed, it's probably delegation.
3. **The Market of Mirrors** – Revenue without reality is just rotating fiction.
4. **The Collapse** – Always ask: Who owns the IP when the lights go out?
5. **Cousins & Consequences** – Build slow, serve hot, and beware the man selling sand to a drowning man.

---

### End of scroll.

Pass the pickled turnips.  
And maybe, just maybe—  
ask your next AI vendor  
one more question  
than feels comfortable.

***Wallahu a'lam.***  
*God knows best.*

---

For those whose soul craves stories where product folly meets poetic justice — and where every lesson is served with extra garlic.

Subscribe