# Timeboxes Are Not Evil

If you think timeboxes are the enemy of great product work, you've misunderstood both timeboxes and great product work. Read on as I explain how and why.

[![Derived Parody of Dean Peters narrowly escaping a Hyperscrumdamentalist riot, as inspired by the generative artwork of Shawn Wallack from his 04Jun25 LinkedIn post.](https://substackcdn.com/image/fetch/$s_!2DTf!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F315b57d8-01ac-4c1f-9d1c-f07ddf334676_3072x2048.png "Derived Parody of Dean Peters narrowly escaping a Hyperscrumdamentalist riot, as inspired by the generative artwork of Shawn Wallack from his 04Jun25 LinkedIn post.")](https://substackcdn.com/image/fetch/$s_!2DTf!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F315b57d8-01ac-4c1f-9d1c-f07ddf334676_3072x2048.png)

Derived Parody of Dean Peters narrowly escaping a Hyperscrumdamentalist riot, as inspired by the generative artwork of Shawn Wallack

**First, a bit of background on me …**

**… and my relationship with constraints.**

When I was a child, I fussed over constraints. Then I studied music composition under [Otto Henry](https://library.ecu.edu/specialcollections/2024/02/09/otto-henry-a-pioneer-in-20th-century-experimental-music/), coached in opera performance with [Janet Bookspan](https://www.artsjournal.com/dewey21c/2008/09/remembering_janet_bookspan.html), mentored by [Edmond Casarella](https://en.wikipedia.org/wiki/Edmond_Casarella), taught stagecraft by [Edgar R. Loessin](https://news.ecu.edu/2011/04/27/founder-of-ecu-theatre-dead-at-83/), plugged into telecom via [Frank DaCruz](https://www.columbia.edu/~fdc/), and honed my software engineering skills by learning real-time programming from members of the [ANSI C committee](https://en.wikipedia.org/wiki/ANSI_C). Many other coaches, mentors, and teachers were similarly foundational in my journey as a product manager.

**I say this not as a point of pedigree**, but rather pedagogy, as at some point, every single one of them reminded me that:

* **Constraints aren't barriers.**
* **They're the scaffolding of creative innovation.**

So, when agile coaches and product peeps fuss about timeboxes, I bristle. When they pin allegorical 9-point theses to the Internet wall, I respond with receipts. The following is my rebuttal—built not on vibes, but on decades, and in some cases centuries, of wisdom on the topic.

---

🧠 **"False Deadlines?"**
------------------------

*"Sprints create artificial urgency."*

**No. They create intentional urgency via clarity, focus, and a ticking clock.**

Urgency without stakes is panic.

Urgency with framing is creative constraint.

**For Example:**

> • **[Toy Story 2](https://www.wired.com/2009/05/ff-pixar/)** — Pixar had 9 months to rebuild the terrible original film from scratch. Instead of asking for more time, they fixed the timebox and ruthlessly cut scope, forcing focus on story and character.
>
> • **[MacPaint](https://www.folklore.org/StoryView.py?project=Macintosh&story=Busy_Being_Born.txt)** — Bill Atkinson built the revolutionary painting program in 4 months with 32KB memory constraints. Tight deadlines and technical limits forced elegant solutions that became the foundation for decades of graphics software.
>
> • **[Parkinson's Law](https://en.wikipedia.org/wiki/Parkinson%27s_law)** — Work expands to fill available time. Give a team 6 months for a 2-week project, and they'll make it take 6 months.
>
> • **[Yerkes-Dodson Law](https://www.linkedin.com/pulse/how-time-constraints-can-boost-innovation-some-extent-colin-harvey-u1juc)** — Performance peaks under moderate stress. Too little pressure breeds complacency; too much creates paralysis.

*"To achieve great things, two things are needed: a plan, and not quite enough time."*  
~ **[Leonard Bernstein](https://www.linearity.io/blog/creativity-quotes/)**

─── ⋆⋅☆⋅⋆ ──

💥 **"Broken Flow?"**
--------------------

*"Sprints break deep work."*

**Sustained flow isn't fragile; it's built by constraint and rhythm.**

The best flow systems use boundaries to create focus, not chaos:

> • **[Shape Up](https://basecamp.com/shapeup)** — Basecamp's 6-week cycles give teams enough time for meaningful work while preventing projects from dragging on indefinitely. Fixed time and flexible scope protects deep work while maintaining momentum.
>
> • **[Lean UX](https://www.oreilly.com/library/view/lean-ux/9781449311657/)** — Work-in-progress limits force teams to finish what they start before taking on new tasks, eliminating context switching and creating sustained attention for complex problems.
>
> • **[Kanban WIP Limits](https://kanbanzone.com/2022/theory-of-constraints/)** — Limiting how many tasks can be "in progress" forces collaboration on blockers and creates natural flow states.
>
> • **[Vena Contracta](https://en.wikipedia.org/wiki/Vena_contracta)** — In fluid dynamics, constraining flow through a narrow opening increases velocity. Same principle applies to teams: narrowing focus accelerates progress.

*"Nothing is more paralyzing than the idea of limitless possibilities."*  
~ **[Austin Kleon](https://en.wikipedia.org/wiki/Steal_Like_an_Artist)**

⌞ ° • • ° ⌟

🎯 **"Arbitrary Timeboxing?"**
-----------------------------

*"Complex work doesn't fit neat 2-week chunks."*

**Exactly. That's the point—timeboxes carve messy chaos into clear commitments.**

Complex work becomes manageable when we accept that completion isn't the only measure of progress:

> • **[Shape Up](https://uxcam.com/blog/shape-up-methodology/)** — By fixing time and making scope flexible, teams can tackle ambitious problems without perfectionism paralysis. Can't finish everything? Cut scope, not quality.
>
> • **[RAD (Rapid Application Development)](https://distantjob.com/blog/rad-model-advantages-and-disadvantages/)** — 60-90 day timeboxes create both creative pressure and protective boundaries, freeing teams to try bold approaches while forcing decisive trade-offs.
>
> • **[Hackathons](https://www.hackerearth.com/blog/hackathons/why-hackathons-are-the-best-way-to-innovate/)** — 24-48 hour constraints strip away everything nonessential, often achieving breakthrough simplicity that takes full-time teams months to reach.
>
> • **[Vertical Slicing](https://www.humanizingwork.com/the-humanizing-work-guide-to-splitting-user-stories/)** — Instead of building horizontally, teams deliver thin slices of complete functionality that fit within sprint timeboxes and deliver real user value.

*"The more a person limits himself, the more resourceful he becomes."*  
~ **[Søren Kierkegaard](https://robertrodriguezjr.com/2019/12/18/the-benefits-of-creative-constraints/)**

✨━・━・━✨

📉 **"Hollow Goals?"**
---------------------

*"Velocity is a nonsense number."*

**Velocity isn't gospel; it's a mirror, a diagnostic tool on a dashboard.**

The problem isn't measurement; it's measuring the wrong things or misinterpreting what we measure.

The problem isn’t measuring velocity; it’s making the sole indicator for radiating team value delivery.

> • **[Value Radiators](https://www.scrum.org/resources/blog/financial-aspects-agile-product-management)** — When product teams monitor **both velocity and monetary impact**, they create a direct line of sight between their work and the organization’s bottom line. *(emphasis mine)*
>
> • **[Definition of Done](https://www.scrum.org/resources/blog/magic-power-enabling-constraints)** — Without clear completion criteria, "*velocity*" becomes meaningless. DoD constraints force honest measurement by defining what "done" actually means.
>
> • **[Sprint Backlog WIP Constraints](https://www.excella.com/insights/effective-use-of-constraints-scrum-vs-kanban)** — Teams that pull too many items into a sprint create chaos. Limiting the sprint backlog forces realistic commitments and prevents the "*90% done*" trap.
>
> • **[XP + TDD](https://agilemania.com/advantages-of-extreme-programming)** — Test-driven development constrains how you write code but ensures speed doesn't come at quality's expense through red-green-refactor cycles.
>
> • **[Principle of Least Action](http://www.roboticsproceedings.org/rss20/p109.pdf)** — In physics, systems naturally evolve along paths that minimize energy expenditure. Teams under time pressure instinctively find the most efficient solutions.

*"The enemy of art is the absence of limitations."*  
~ **[Orson Welles](https://www.goodreads.com/quotes/2350-the-absence-of-limitations-is-the-enemy-of-art)**

[![A more recent image of Dean Peters teaching product managers the theory of constraints with visualizations of vena contract & story splitting](https://substackcdn.com/image/fetch/$s_!oPoA!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec46544f-2d9e-4f8d-a2fd-40d57bd4aced_3072x2048.png "A more recent image of Dean Peters teaching product managers the theory of constraints with visualizations of vena contract & story splitting")](https://substackcdn.com/image/fetch/$s_!oPoA!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fec46544f-2d9e-4f8d-a2fd-40d57bd4aced_3072x2048.png)

A more recent image of Dean Peters teaching product managers the theory of constraints, accompanied by visualizations of story splitting, as inspired by someone who’s rehabbed more than one scrum team by introducing constraints.

🔬 **"Bad for Innovation?"**
---------------------------

*"Sprints limit discovery."*

**Wrong. Constraints funnel creativity into concentrated bursts of brilliance.**

Some of tech’s greatest innovations emerged from working within tight boundaries, not despite them:

> • **[Dropbox MVP](https://techcrunch.com/2011/10/19/dropbox-minimal-viable-product/)** — Drew Houston created a 3-minute video showing file sync instead of building a full sync engine. This constraint validated the core value proposition and attracted 75,000 signups overnight.
>
> • **[Slack's launch](https://slack.engineering/how-slack-decided-what-features-to-launch-with/)** — Stewart Butterfield's team launched with just core messaging features, **deliberately leaving out** advanced functionality to nail the fundamental experience first.
>
> • **[Tesla's Tent](https://www.tesla.com/blog/tesla-tent)** — When Tesla hit production bottlenecks, space and time constraints forced radical process innovation that ultimately helped them scale manufacturing.
>
> • **[M-Pesa](https://www.cgap.org/blog/m-pesa-10-years-mobile-money-transfers-kenya)** — Kenya's mobile money revolution happened because infrastructure constraints were so severe that innovators created a text-message-based payment system that leapfrogged traditional banking.

History is equally replete with several instances of great innovation emerging out of great constraints.

*"Constraints drive innovation and force focus."*  
~ **[DHH, Basecamp](https://www.creatosaurus.io/apps/quotes/topics/constraint-quotes)**

.・。.・゜✭・.・✫・゜・。.

🎭 **"Just Process Theater?"**
-----------------------------

*"Sprints become performance."*

**The issue isn’t the ritual, but rather when we stop asking what the performance is for.**

The ritual has value only when it serves the work, not the other way around.

The rituals has value when we look at it as a form factor — read constraint — in how we might collaborate on a creative topic.

> • **[Retrospectives](https://www.scrum.org/resources/what-is-a-sprint-retrospective)** — The 90-minute timebox forces teams to focus on actionable improvements rather than endless discussion, identifying 1-2 specific experiments for the next sprint.
>
> • **[Standups](https://www.scrum.org/resources/blog/scrum-anti-patterns-daily-scrum)** — The 15-minute timebox creates urgency around coordination and obstacle removal, not status reports.
>
> • **[Shape Up rituals](https://uxcam.com/blog/shape-up-methodology/)** — Basecamp's betting table and cool-down periods are constrained by design: six weeks to build, two weeks to breathe and bet on the next cycle.

*"The more constraints one imposes, the more one frees oneself."  
~ **[Igor Stravinsky](https://www.musicbed.com/articles/filmmaking/writing/exploring-the-power-of-creative-constraints/)***

・・・・☆・・・・☆ ・・・・

🔄 **"Less Responsive?"**
------------------------

*"Sprints delay pivoting."*

**Only if we worship the calendar more than the signal.**

Smart teams use timeboxes as containers for learning, not straitjackets against change:

> • **[Kanban](https://tameflow.com/blog/2012-10-28/kanban-improved-via-theory-of-constraints/)** — Flow-based systems respond to change by adjusting WIP limits and priorities in real-time. The constraint is capacity, not calendar.
>
> • **[Lean Startup](https://leanstartup.co/)** — Build-measure-learn cycles are timeboxed to be as short as possible while still generating valid data, accelerating the feedback loop.
>
> • **[Tiny Stories](https://hashrocket.com/blog/posts/big-reasons-to-write-small-user-stories)** — Sprint-sized chunks mean you're never more than two weeks away from pivoting. Large stories lock teams into long commitments; small stories preserve optionality.

Want more on this? Read Eli Goldratt’s “[The Goal](https://amzn.to/4mOf5Dj),” or at least familiarize yourself with “[The Phoenix Project.](https://amzn.to/43L1kg3)”

*"Great things are done by a series of small things brought together."  
~ **[Vincent van Gogh](https://www.linearity.io/blog/creativity-quotes/)***

---

🧾 **The Real Truth**
--------------------

**Sprints don't fail**. **Teams do.**  
Timeboxes don't stifle creativity. They **distill** it like strong coffee.  
Flow isn't freedom, it's **constraint, well-applied and craft-aware.**

Leadership understands this:

*"Frugality drives innovation, just like other constraints do."*  
~ **[Jeff Bezos](https://www.azquotes.com/quote/1582854)**

*"The secret to productivity is not managing your time but managing your focus."*  
~ **[Luke Seavers](https://www.goodreads.com/work/quotes/88307204-time-blocking-your-method-to-supercharge-productivity-reach-your-goal)**

*"We need to first be limited in order to become limitless."*  
~ **[Phil Hansen](https://blog.ted.com/can-limitations-make-you-more-creative-a-qa-with-artist-phil-hansen/)**

∻

**✍ Epilogue**
--------------

#### So why this post, this topic, and why now?

Because amidst all the hot takes on sprints from [fussy 9-point theses](https://www.linkedin.com/posts/shawnwallack_lets-talk-about-sprints-grab-your-pitchforks-activity-7335801411231752192-pL5G?utm_source=share&utm_medium=member_desktop&rcm=ACoAAADEu00BWMZwO7QA8ZEorayAxr4F_LdrMrs) and manifesto rants — to [reasonable rebuttals](https://www.linkedin.com/feed/update/urn:li:activity:7335801411231752192?commentUrn=urn%3Ali%3Acomment%3A%28activity%3A7335801411231752192%2C7335926892459376640%29&dashCommentUrn=urn%3Ali%3Afsd_comment%3A%287335926892459376640%2Curn%3Ali%3Aactivity%3A7335801411231752192%29) by Agile Stalwarts such as Stefan Wolpers' — I made the mistake of agreeing in public. That earned me a **[digital mugging](https://www.linkedin.com/feed/update/urn:li:activity:7335801411231752192?commentUrn=urn%3Ali%3Acomment%3A%28activity%3A7335801411231752192%2C7335926892459376640%29&replyUrn=urn%3Ali%3Acomment%3A%28activity%3A7335801411231752192%2C7335983936772210690%29&dashCommentUrn=urn%3Ali%3Afsd_comment%3A%287335926892459376640%2Curn%3Ali%3Aactivity%3A7335801411231752192%29&dashReplyUrn=urn%3Ali%3Afsd_comment%3A%287335983936772210690%2Curn%3Ali%3Aactivity%3A7335801411231752192%29)** in the comments and a few inferences about being a [Hyperscrumdamentalist](https://medium.com/deanondelivery/you-might-be-a-hyperscrumdamentalist-if-b90be353b42b).

[![Screenshot of Stefan Wolpers’ reply to a 9-point thesis on the evils of timeboxes.](https://substackcdn.com/image/fetch/$s_!liBK!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F925a7656-eebe-43a9-ac51-679225375e2f_1624x1248.png "Screenshot of Stefan Wolpers’ reply to a 9-point thesis on the evils of timeboxes.")](https://substackcdn.com/image/fetch/$s_!liBK!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F925a7656-eebe-43a9-ac51-679225375e2f_1624x1248.png)

Stefan Wolpers’ reply to a 9-point thesis on the evils of timeboxes.

The whole kerfuffle reminded me why these debates keep flaring up: we’re not just arguing over frameworks. **We’re reacting to pain.** All of us. On both sides of the ideological aisle. The process pain. The delivery dread. The unacknowledged dysfunction often blamed on ritual.

That in mind. This post is not a defense of Scrum, nor a crusade for timeboxes. It’s a case for constraints. Not as cages, but as crucibles. As focus engines. As feedback machines.

**It’s also a reminder that if something on the schedule hurts, we shouldn't ban the calendar. We should check the system.**

Because the right constraint, well-applied, doesn’t stifle creativity.  
It **distills** it.

Put a bit more bluntly:

* Constraints historically have driven innovation through clarity
* Timeboxes are not theology … they’re simply tested.
* **Stefan was right!**

And rather than reply with a rant,   
I opted to bring receipts instead.  
See you in the next retro.

Subscribe