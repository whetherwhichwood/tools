# Day 14 - Your CFO Ain't Buying It

AI product managers who ship flashy demos without validated economic levers aren’t bold; they’re expensive tourists with a prayer and a very suspect roadmap.

[![](https://substackcdn.com/image/fetch/$s_!r5cT!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fae172fc6-e99b-4ab0-8a2d-c4ae8b84566e_2754x1536.png)](https://substackcdn.com/image/fetch/$s_!r5cT!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fae172fc6-e99b-4ab0-8a2d-c4ae8b84566e_2754x1536.png)

The projection appears on the screen.

The room gets quiet. Not the polite quiet of people paying attention. The other quiet. The quiet that falls over a room full of executives who have collectively survived fifteen “transformational initiatives” by practicing the ancient corporate martial art known as **not funding things.**

Up comes the hockey stick.

A beautiful curve. Elegant. Confident. Rising like it has personally been blessed by the ghost of Moore’s Law.

Lower left. Upper right.

No friction.  
No competitors.  
No customers behaving like customers.  
No budgets behaving like budgets.

Just a line marching heroically toward a future where the spreadsheet has decided everyone will be rich.

To the AI product manager who built it, this looks like evidence.

To the CFO, it looks like a smell. The smell of numbers that were reverse-engineered to support a conclusion the team emotionally committed to six weeks ago. The CFO has a question, and it isn’t about the model or the latency. The question is about the lever.

What business model lever does this move? Measured how? Against what baseline? Over what timeframe? Boardrooms reward evidence, not beautifully formatted hope. Finance exists to translate AI dreams into accountable economic terms. If the prototype impresses the engineers in the hallway, the business case is what moves the money in the boardroom.

[![](https://substackcdn.com/image/fetch/$s_!YSRj!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc28a8011-c93d-4a45-8092-d3016724afbf_2752x1536.png)](https://substackcdn.com/image/fetch/$s_!YSRj!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc28a8011-c93d-4a45-8092-d3016724afbf_2752x1536.png)

WTH (What the Hockey-stick) Is Going On Here
--------------------------------------------

A hockey-stick projection in a stakeholder meeting is the corporate equivalent of firing a flare gun indoors. Everyone knows what it means. Nobody wants to say it out loud.

Because the hockey stick is rarely a forecast. It is a tell. It’s a signal that the presenter has not yet made the connection between their agentic vision of the future and the small but important detail that the organization funding it would like to remain solvent. AI creates lift when it moves a lever the business already understands.

**A bureaucracy wrapped in a spreadsheet stuffed inside a strategy deck nobody read is not a business case.** It is advocacy wearing financial formatting.

[![](https://substackcdn.com/image/fetch/$s_!ZDmc!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F70b48544-7c22-4046-adbb-48576da4f157_5504x3072.png)](https://substackcdn.com/image/fetch/$s_!ZDmc!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F70b48544-7c22-4046-adbb-48576da4f157_5504x3072.png)

The Levers That Survive the Room
--------------------------------

Executive reviews are not idea discussions. They are economic conversations.

There are two families of levers that survive an executive review. Pick the one you are actually moving.

### Business Model Levers: The Economics

* **Revenue grows** when AI changes measurable customer behavior. Not “potential monetization.” Actual conversion deltas in a pilot.
* **Market share shifts** when buyers switch competitive preferences. Show the displacement logic.
* **Lifetime value rises** when products become harder to replace. Indispensable products don’t need a “vibe” check; they show up in the retention data.

### Operational Model Levers: The Machine

* **Productivity improves** when AI removes friction from workflows. But beware the “efficiency” trap. Taco Bell and McDonald’s deployed voice AI to drive-thrus to hit speed-of-service KPIs. It sounded like a win until the AI started adding bacon to ice cream and happily accepting orders for 18,000 cups of water. Instead of scaling productivity, they scaled a bottleneck. **Productivity without a denominator—and a human guardrail—is just vibes with a dashboard.**
* **Cost savings** emerge when AI reduces labor spend, vendor expense, or error correction. This is the only lever the CFO understands instinctively because cost is legible. If your AI reduces manual verification time from four hours to six minutes in a two-week pilot, say that. That is a budget story, not a feature story.
* **Safety and compliance protection** prevents disasters executives already fear. It’s less glamorous than revenue until the regulator arrives.

Pick one lever. Maybe two. The PM claiming six levers at once is just firing a confetti cannon into a spreadsheet. The room knows it.

[![](https://substackcdn.com/image/fetch/$s_!vTwg!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe579b059-714a-4953-bc80-cd654814294c_5504x2532.png)](https://substackcdn.com/image/fetch/$s_!vTwg!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fe579b059-714a-4953-bc80-cd654814294c_5504x2532.png)

Evidence Over Theater
---------------------

When funding AI product initiatives, strategy dies when assumptions masquerade as results. Evidence travels farther than optimism inside organizations, yet many teams still prefer the “Confidence Theater” of a polished demo over the messy reality of a validated experiment.

### The Separate Legal Entity Hallucination

In 2024, Air Canada learned that theater is expensive when a judge is the one watching the performance.

The airline deployed a chatbot to handle inquiries. When a passenger asked about bereavement fares, the chatbot hallucinated a discount policy that didn’t exist. The customer followed the bot’s instructions, booked the flight, and then—rightfully—asked for the refund the bot promised.

Air Canada’s defense was a work of absurdist fiction: they argued the chatbot was a “separate legal entity” and that the airline shouldn’t be held liable for its “promises.” It was a bold attempt to treat an LLM like a rogue contractor instead of a product.

The court wasn’t amused. They ruled that the company is responsible for everything its agent says. This is the death of AI Theater. If you ship an agent without validating it against real policy, you aren’t innovating. You’re just outsourcing your legal liability to a statistical parrot.

**Numbers beat adjectives every single time.**

[![](https://substackcdn.com/image/fetch/$s_!LmF7!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc290d4bf-083b-4e83-ba9c-d01c8ac18618_5504x3072.png)](https://substackcdn.com/image/fetch/$s_!LmF7!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc290d4bf-083b-4e83-ba9c-d01c8ac18618_5504x3072.png)

The One-Pager That Survives the Meeting
---------------------------------------

There is a document that works in the CFO meeting. It contains five things on one page.

1. **The hypothesis:** Hypothesis first, experiment second, funding third.
2. **The lever:** Which specific business or operational mechanism are you pulling?
3. **The experiment:** What did you test, for how long, and with what real telemetry?
4. **The result:** What happened? With numbers. Not adjectives.
5. **The recommendation:** Pivot. Punt. Pursue. Pause. Pick one like an adult.

This requires running the experiment *before* walking into the room. Building feels like progress; testing feels like homework. But when the CFO asks one sharp question, the homework is the only thing that keeps the papier-mâché cathedral from catching fire.

**If you cannot explain the lever in one sentence, you do not have a strategy. You have a hobby with a budget.**

[![](https://substackcdn.com/image/fetch/$s_!69hR!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faca1f53b-a87e-4205-86dd-f46588f646b0_5504x3072.png)](https://substackcdn.com/image/fetch/$s_!69hR!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Faca1f53b-a87e-4205-86dd-f46588f646b0_5504x3072.png)

Coming Up
---------

**Day 15:** The series closes. The arc from fluency to strategy.

**The Final Reveal:** The one decision that separates the PMs who lead AI from the ones who spend the next two years catching up.

---

*Most AI product management training hands you a certificate at Stage 3 and calls it done. Stage 3 is where the Productside course begins. Four days. Live online. Under 20 seats.*

[Start the ascent. Sign up for the class.](https://lnkd.in/eKWZxkyJ)